﻿//JavaScript
//--------------------------------------------------
var CMD	= "RemapEditor.exe";
var tmpFile	= "RemapEditor.tmp";

function layerRemap(lyr,cmp)
{
	this.layer		= lyr;
	this.enabled	= false;
	this.cellCount	= 0;
	this.frameCount	= 0;
	this.frameRate	= 24;
	this.timeRemapEnabled = false;
	this.remapKey	= new Array;
	
	this.get = function()
	{
		this.enabled = false;
		if ( this.layer == null ) return;
		this.frameRate = this.layer.source.frameRate;
		this.cellCount	= this.layer.source.duration * this.layer.source.frameRate;
		this.frameCount	= cmp.duration * cmp.frameRate;
		
		//remap
		this.timeRemapEnabled = this.layer.timeRemapEnabled;
		this.remapKey	= new Array;
		var empty = this.layer.source.duration;
		var remap =  this.layer.timeRemap;
		if ( (this.layer.timeRemapEnabled == true)&&(remap.numKeys>0) ){
			//opacity
			var opa = this.layer.property("Opacity");
			if (opa.numKeys >0) {
				for ( var i=1; i<=opa.numKeys; i++){
					if ( opa.keyValue(i) !=100) {
						remap.setValueAtTime(opa.keyTime(i), empty)
					}
				}
			}
			var effect_str	= "エフェクト";
			var effectName = "ブラインド";
			var pName = "変換終了";
			
			if ( app.language == Language.ENGLISH){
				effect_str	= "Effects";
				effectName = "Venetian Blinds";
				pName = "ransition Completion";
			}
			var fxg = this.layer.property(effect_str);
			if (fxg !=null) {
				var fx = fxg.property(effectName);
				if (fx !=null) {
					var bld = fx.property(pName);
					if ( (bld !=null) &&(bld.numKeys>0) ){
						for ( var i=1; i<=bld.numKeys; i++){
							if ( bld.keyValue(i) !=0) {
								remap.setValueAtTime(bld.keyTime(i), empty)
							}
						}
						
					}
				}
			}
			for ( var i=1; i<=remap.numKeys; i++){
				var o = new Object;
				o.frame = remap.keyTime(i) * this.frameRate;
				var n = Math.round( remap.keyValue(i) * this.frameRate) +1;
				if (n> this.cellCount){
					o.num = 0;
				}else{
					o.num = n;
				}
				this.remapKey.push(o);
			}
		}
		
		this.enabled = true;
	}
	this.save = function()
	{
		if (this.enabled == false) return;
		var f = new File(tmpFile);
		f.open("w");

		f.writeln("*params");
		f.writeln("cellCount = " + this.cellCount);
		f.writeln("frameCount = " + this.frameCount);
		f.writeln("frameRate = " + this.frameRate);
		f.writeln("timeRemapEnabled = " + this.timeRemapEnabled);
		f.writeln("remapCount = " + this.remapKey.length);
		
		if (this.remapKey.length>0) {
			f.writeln("*remap");
			for ( var i=0; i<this.remapKey.length; i++){
				f.writeln(this.remapKey[i].frame + "\t" + this.remapKey[i].num);
			}
		}
		f.close();
	}
	
	this.get();
}
//--------------------------------------------------

function remapEditor(t)
{
	this.scriptName = "RemapEditor";
	this.palette	= t;
	this.current	= Folder.current;
	
	this.btnGo	= null;
	//-----------------------------
	this.getRemap	= function()
	{
		var selectedLayers = null;
		var activeComp = app.project.activeItem;
		if ( (activeComp!=null)&&(activeComp instanceof CompItem) ) {
			selectedLayers = activeComp.selectedLayers;
			if ( (selectedLayers == null) || (selectedLayers.length !=1) ) {
				alert("レイヤを一つだけ選択してください！");
				return 
			}
		}else{
			alert("レイヤを選択してください！");
			return 
		}
		var rp = new layerRemap(selectedLayers[0],activeComp);
		
		var bak = Folder.current;
		Folder.current = this.current;
		rp.save();
		var lines = system.callSystem(CMD +" \"" + tmpFile+"\"");
		if (lines != ""){
			//先頭が//JavaScriptなら、スクリプトとして実行する。
			if (lines.indexOf("//JavaScript") == 0) {
				eval(lines);
			}else{
				alert("クリップボードに有効なJavaScriptコードが有りません！");
			}
		}
		Folder.current = bak;

	}
	//-----------------------------
	//メニューパレットの作成
	this.run = function()
	{
		//ボタンの作成
		this.btnGo = this.palette.add("button",[5,5,105,30],this.scriptName);
		this.btnGo.current = this.current;
		this.btnGo.onClick = this.getRemap;
	}
}

var re = new remapEditor(this);
re.run();
