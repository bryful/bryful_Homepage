﻿//*****************************************************************************
//-----------------------------------------------------------------------------
(function (me)
{
	var err = false;
	function errMes()
	{
		var s = "すみません。以下の設定がオフになっています。\r\n\r\n";
		s +=  "「環境設定：一般設定：スクリプトによるファイルへの書き込みとネットワークへのアクセスを許可」\r\n";
		s += "\r\n";
		s += "このスクリプトを使う為にはオンにする必要が有ります。\r\n";
		alert(s);
	}
	/////////////////////////////////////////////////////////////////////////////////////////////
	if ( app.preferences.getPrefAsLong("Main Pref Section", "Pref_SCRIPTING_FILE_NETWORK_SECURITY") != 1){
		err = true;
		errMes();
	}
	String.prototype.trim = function(){
		if (this=="" ) return ""
		else return this.replace(/[\r\n]+$|^\s+|\s+$/g, "");
	}

	function getFileNameWithoutExt(s)
	{
		var ret = s;
		var idx = ret.lastIndexOf(".");
		if ( idx>=0){
			ret = ret.substring(0,idx);
		}
		return ret;
	}
	function getScriptName()
	{
		var ary = $.fileName.split("/");
		return File.decode( getFileNameWithoutExt(ary[ary.length-1]));
	}
	function getScriptPath()
	{
		var s = $.fileName;
		return s.substring(0,s.lastIndexOf("/"));
	}

	var palette			= null;
	var scriptPath		= getScriptPath();
	var scriptName		= getScriptName();
	var btnExec			= null;
	//var	CMD				= "AE_Clipboard.exe";
	var	MAC_CMD				= "pbpaste";
	var	WIN_CMD				= "AE_Clipboard.exe";
	
	
	var is_os_win = ($.os.indexOf("Windows")>=0);
	function exec()
	{
		if (err==true) {
			errMes();
			return;
		}
		var CMD = "";
		
		//現在のカレントを退避
		var bak = Folder.current;
		if (is_os_win){
			CMD = WIN_CMD;
			//スクリプトファイルのあるフォルダへ移動
			Folder.current = new Folder(scriptPath);
		}else{
			CMD = MAC_CMD;
		}
		var lines = "";
		try{
			lines = system.callSystem(CMD);
			lines = lines.trim();
		}catch(e){
			alert(e.toString(),scriptName);
		}
		if ( lines == ""){
			alert("クリップボードから獲得失敗",scriptName);
		}
		try{
			eval(lines);
		}catch(e){
			alert("eval error！\r\n\r\n" + e.toString() +"\r\n----------------------------\r\n" + lines, scriptName);
		}
		
		if (is_os_win){
			//カレントをもとに戻す。
			Folder.current = bak;
		}
	}
	function buildPalette()
	{
		palette = ( me instanceof Panel) ? me : new Window("palette", scriptName, [ 0,0,130,40]);
		btnExec = palette.add("button",     [5,  5,5+120, 30],"クリップボード実行");
		btnExec.onClick = exec;
	};

	buildPalette();
	if ( ( me instanceof Panel) == false){
		palette.center();
		palette.show();
	}


})(this);
