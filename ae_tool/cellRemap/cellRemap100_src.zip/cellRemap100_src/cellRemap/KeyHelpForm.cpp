﻿#include "KeyHelpForm.h"

KeyHelpForm::KeyHelpForm(QWidget *parent) :
    QTextBrowser(parent)
{
}

KeyHelpForm::~KeyHelpForm()
{
}
