﻿#ifndef TSDATADEF_H
#define TSDATADEF_H

/*
	コンソールモードのときは下の行をコメントアウトする
*/
//#define CONSOLE_MODE

#endif // TSDATADEF_H
