﻿// prototypeUno.jsxを最初に実行して置いてください。

(function ()
{
	
	var fld = Folder.selectDialog("カットフォルダを選択");
	if ( fld == null) {
		return;
	}
	//gl.exeはパスの通った場所か、このスクリプトと同じ場所においてください。
	//gl.defはデフォルト状態のものです。
	var s = system.callSystem("gl.exe /j \"" + fld.fullName+"\"");
	if ( s!=""){
		var o = eval(s);
		if ( (o != undefined)&&( o instanceof Array)){
			var ftgFld = app.project.rootFolder.folder("フッテージ");
			o.interate(function(t)
				{
					var f = new File(t.path);
					var im = new ImportOptions(f);
					if ( t.isSequence==true) im.sequence = true;
					try { 						var ftg = app.project.importFile(im);
						if ( t.subFolder ==""){
							ftg.parentFolder = ftgFld;
						}else{
							ftg.parentFolder = ftgFld.folder(t.subFolder);
						}					} catch (error) {						alert(error.toString() + im.file.fsName);					}
				}
			);
		}
	}
	
})();
