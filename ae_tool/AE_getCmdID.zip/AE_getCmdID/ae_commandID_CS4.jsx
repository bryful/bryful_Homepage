﻿app.cmdMenu = new Object;
//--------------------------------------------
app.cmdMenu.Help = new Object;
app.cmdMenu.Help.AboutAfterEffects = function(){ app.executeCommand(256);}	//ヘルプ:After Effectsについて...
//--------------------------------------------
app.cmdMenu.File = new Object;
app.cmdMenu.File.AddFootagetoComp = function(){ app.executeCommand(2005);}	//ファイル(F):コンポジションにフッテージを追加
app.cmdMenu.File.AdobeDynamicLink = function(){ app.executeCommand(2552);}	//ファイル(F):Adobe Dynamic Link
app.cmdMenu.File.BrowseTemplateProjects = function(){ app.executeCommand(3692);}	//ファイル(F):プロジェクトテンプレートを参照...
app.cmdMenu.File.Browse = function(){ app.executeCommand(3689);}	//ファイル(F):Bridge で参照...
app.cmdMenu.File.CloseProject = function(){ app.executeCommand(3154);}	//ファイル(F):プロジェクトを閉じる(J)
app.cmdMenu.File.Close = function(){ app.executeCommand(4);}	//ファイル(F):閉じる(C)
app.cmdMenu.File.CollectFiles = function(){ app.executeCommand(2482);}	//ファイル(F):ファイルを収集...
app.cmdMenu.File.ConsolidateAllFootage = function(){ app.executeCommand(2107);}	//ファイル(F):すべてのフッテージを統合(D)
app.cmdMenu.File.CreateProxy = function(){ app.executeCommand(2777);}	//ファイル(F):プロキシ作成
app.cmdMenu.File.Export = function(){ app.executeCommand(2494);}	//ファイル(F):書き出し(M)
app.cmdMenu.File.Find = function(){ app.executeCommand(2607);}	//ファイル(F):検索
app.cmdMenu.File.ImportRecentFootage = function(){ app.executeCommand(2283);}	//ファイル(F):最近のフッテージを読み込む
app.cmdMenu.File.Import = function(){ app.executeCommand(2105);}	//ファイル(F):読み込み(I)
app.cmdMenu.File.IncrementandSave = function(){ app.executeCommand(3088);}	//ファイル(F):番号をつけて保存
app.cmdMenu.File.InterpretFootage = function(){ app.executeCommand(2102);}	//ファイル(F):フッテージを変換(G)
app.cmdMenu.File.NewCompfromSelection = function(){ app.executeCommand(2796);}	//ファイル(F):複数アイテムから新規コンポジション...
app.cmdMenu.File.New = function(){ app.executeCommand(2264);}	//ファイル(F):新規(N)
app.cmdMenu.File.OpenProject = function(){ app.executeCommand(3);}	//ファイル(F):プロジェクトを開く(O)...
app.cmdMenu.File.OpenRecentProjects = function(){ app.executeCommand(2284);}	//ファイル(F):最近のプロジェクトを開く
app.cmdMenu.File.PageSetup = function(){ app.executeCommand(8);}	//ファイル(F):ページ設定...
app.cmdMenu.File.Print = function(){ app.executeCommand(9);}	//ファイル(F):プリント...
app.cmdMenu.File.ProjectSettings = function(){ app.executeCommand(2611);}	//ファイル(F):プロジェクト設定(P)...
app.cmdMenu.File.Quit = function(){ app.executeCommand(1);}	//ファイル(F):終了(Q)
app.cmdMenu.File.ReduceProject = function(){ app.executeCommand(2735);}	//ファイル(F):プロジェクトの整理
app.cmdMenu.File.ReloadFootage = function(){ app.executeCommand(2257);}	//ファイル(F):フッテージを再読み込み(L)
app.cmdMenu.File.RemoveUnusedFootage = function(){ app.executeCommand(2109);}	//ファイル(F):未使用のフッテージを削除(U)
app.cmdMenu.File.ReplaceFootage = function(){ app.executeCommand(2237);}	//ファイル(F):フッテージの置き換え(E)
app.cmdMenu.File.RevealinBridge = function(){ app.executeCommand(3690);}	//ファイル(F):Bridge で表示
app.cmdMenu.File.RevealinExplorer = function(){ app.executeCommand(2562);}	//ファイル(F):Finderで表示{{*MSWindows*}}エクスプローラで表示
app.cmdMenu.File.RevealinFinder = function(){ app.executeCommand(2562);}	//ファイル(F):Finderで表示
app.cmdMenu.File.Revert = function(){ app.executeCommand(7);}	//ファイル(F):復帰(R)
app.cmdMenu.File.SaveAsXML = function(){ app.executeCommand(3785);}	//ファイル(F):XML 形式でコピーを保存...
app.cmdMenu.File.SaveAs = function(){ app.executeCommand(6);}	//ファイル(F):別名で保存(V)...
app.cmdMenu.File.Save = function(){ app.executeCommand(5);}	//ファイル(F):保存(S)
app.cmdMenu.File.SaveaCopy = function(){ app.executeCommand(2166);}	//ファイル(F):コピーを保存(Y)...
app.cmdMenu.File.SetProxy = function(){ app.executeCommand(2106);}	//ファイル(F):プロキシ設定(Y)
app.cmdMenu.File.UpgradeProjectPARsToCS4 = function(){ app.executeCommand(3791);}	//ファイル(F):ピクセル縦横比を更新
app.cmdMenu.File.WatchFolder = function(){ app.executeCommand(2457);}	//ファイル(F):フォルダを監視(W)...
//--------------------------------------------
app.cmdMenu.Edit = new Object;
app.cmdMenu.Edit.Clear = function(){ app.executeCommand(21);}	//編集(E):消去(E)
app.cmdMenu.Edit.CopyExpressionOnly = function(){ app.executeCommand(53);}	//編集(E):エクスプレッションのみをコピー
app.cmdMenu.Edit.Copy = function(){ app.executeCommand(19);}	//編集(E):コピー(C)
app.cmdMenu.Edit.Cut = function(){ app.executeCommand(18);}	//編集(E):カット(T)
app.cmdMenu.Edit.DeselectAll = function(){ app.executeCommand(2004);}	//編集(E):すべてを選択解除
app.cmdMenu.Edit.Duplicate = function(){ app.executeCommand(2080);}	//編集(E):複製(D)
app.cmdMenu.Edit.EditOriginal = function(){ app.executeCommand(2142);}	//編集(E):オリジナルを編集...
app.cmdMenu.Edit.EditinAdobeAudition = function(){ app.executeCommand(3697);}	//編集(E):Adobe Audition で編集
app.cmdMenu.Edit.EditinAdobeSoundbooth = function(){ app.executeCommand(3761);}	//編集(E):Adobe Soundbooth で編集
app.cmdMenu.Edit.ExtractWorkArea = function(){ app.executeCommand(2614);}	//編集(E):ワークエリアの抽出
app.cmdMenu.Edit.History = function(){ app.executeCommand(2995);}	//編集(E):ヒストリー
app.cmdMenu.Edit.Label = function(){ app.executeCommand(2358);}	//編集(E):ラベル(L)
app.cmdMenu.Edit.LiftWorkArea = function(){ app.executeCommand(2613);}	//編集(E):ワークエリアのリフト
app.cmdMenu.Edit.Paste = function(){ app.executeCommand(20);}	//編集(E):ペースト(P)
app.cmdMenu.Edit.Preferences = function(){ app.executeCommand(2079);}	//編集(E):環境設定(F)
app.cmdMenu.Edit.Purge = function(){ app.executeCommand(2370);}	//編集(E):キャッシュの消去
app.cmdMenu.Edit.Redo = function(){ app.executeCommand(2035);}	//編集(E):やり直し(R)
app.cmdMenu.Edit.SelectAll = function(){ app.executeCommand(23);}	//編集(E):すべてを選択(A)
app.cmdMenu.Edit.SplitLayer = function(){ app.executeCommand(2158);}	//編集(E):レイヤーを分割(S)
app.cmdMenu.Edit.Templates = function(){ app.executeCommand(2265);}	//編集(E):テンプレート(M)
app.cmdMenu.Edit.Undo = function(){ app.executeCommand(16);}	//編集(E):取り消し(U)
//--------------------------------------------
app.cmdMenu.Composition = new Object;
app.cmdMenu.Composition.AddOutputModule = function(){ app.executeCommand(2154);}	//コンポジション(C):出力モジュールを追加(D)
app.cmdMenu.Composition.AddToAMERenderQueue = function(){ app.executeCommand(3800);}	//コンポジション(C):Adobe Media Encoder キューに追加
app.cmdMenu.Composition.AddtoRenderQueue = function(){ app.executeCommand(2161);}	//コンポジション(C):レンダーキューに追加(A)
app.cmdMenu.Composition.BackgroundColor = function(){ app.executeCommand(2036);}	//コンポジション(C):背景色(B)...
app.cmdMenu.Composition.CompFlowchartView = function(){ app.executeCommand(2258);}	//コンポジション(C):コンポジションフローチャート(F)
app.cmdMenu.Composition.CompositionSettings = function(){ app.executeCommand(2007);}	//コンポジション(C):コンポジション設定(T)...
app.cmdMenu.Composition.CropComptoRegionofInterest = function(){ app.executeCommand(2997);}	//コンポジション(C):コンポジションを目標範囲にクロップ(I)
app.cmdMenu.Composition.MakeMovie = function(){ app.executeCommand(2006);}	//コンポジション(C):ムービー作成(M)...
app.cmdMenu.Composition.NewComposition = function(){ app.executeCommand(2000);}	//コンポジション(C):新規コンポジション(C)...
app.cmdMenu.Composition.OpenMiniFlowPopup = function(){ app.executeCommand(3792);}	//コンポジション(C):コンポジションミニフローチャート(N)
app.cmdMenu.Composition.Prerender = function(){ app.executeCommand(2780);}	//コンポジション(C):プリレンダリング...
app.cmdMenu.Composition.Preview = function(){ app.executeCommand(2131);}	//コンポジション(C):プレビュー(P)
app.cmdMenu.Composition.SaveFrameAs = function(){ app.executeCommand(2233);}	//コンポジション(C):フレームを保存(S)
app.cmdMenu.Composition.SaveRAMPreview = function(){ app.executeCommand(2125);}	//コンポジション(C):RAMプレビューを保存(R)...
app.cmdMenu.Composition.SetPosterTime = function(){ app.executeCommand(2012);}	//コンポジション(C):サムネールのフレームを設定(E)
app.cmdMenu.Composition.TrimComptoWorkArea = function(){ app.executeCommand(2360);}	//コンポジション(C):コンポジションをワークエリアにトリム(W)
//--------------------------------------------
app.cmdMenu.Layer = new Object;
app.cmdMenu.Layer.ThreeDLayer = function(){ app.executeCommand(2541);}	//レイヤー(L):3Dレイヤー
app.cmdMenu.Layer.AddMarker = function(){ app.executeCommand(2157);}	//レイヤー(L):マーカーを追加(R)
app.cmdMenu.Layer.AdobeEncore = function(){ app.executeCommand(3082);}	//レイヤー(L):Adobe Encore
app.cmdMenu.Layer.Arrange = function(){ app.executeCommand(3798);}	//レイヤー(L):アレンジ
app.cmdMenu.Layer.Autotrace = function(){ app.executeCommand(3044);}	//レイヤー(L):オートトレース...
app.cmdMenu.Layer.BlendingMode = function(){ app.executeCommand(2162);}	//レイヤー(L):描画モード(D)
app.cmdMenu.Layer.BringForward = function(){ app.executeCommand(2018);}	//レイヤー(L):1つ前に移動(O)
app.cmdMenu.Layer.BringtoFront = function(){ app.executeCommand(2016);}	//レイヤー(L):フロントビューに移動(F)
app.cmdMenu.Layer.ConvertToEditable = function(){ app.executeCommand(3799);}	//レイヤー(L):編集可能なテキストに変換
app.cmdMenu.Layer.ConvertToLivePhotoshop3D = function(){ app.executeCommand(3797);}	//レイヤー(L):ライブ Photoshop 3D に変換
app.cmdMenu.Layer.CreateOutlines = function(){ app.executeCommand(2933);}	//レイヤー(L):テキストからマスクを作成
app.cmdMenu.Layer.CreateOutlines = function(){ app.executeCommand(3781);}	//レイヤー(L):テキストからシェイプを作成
app.cmdMenu.Layer.FrameBlending = function(){ app.executeCommand(2289);}	//レイヤー(L):フレームブレンド
app.cmdMenu.Layer.GuideLayer = function(){ app.executeCommand(3081);}	//レイヤー(L):ガイドレイヤー
app.cmdMenu.Layer.LayerSettings = function(){ app.executeCommand(2021);}	//レイヤー(L):レイヤー設定(S)...
app.cmdMenu.Layer.LayerStyles = function(){ app.executeCommand(3739);}	//レイヤー(L):レイヤースタイル
app.cmdMenu.Layer.Mask = function(){ app.executeCommand(2040);}	//レイヤー(L):マスク(M)
app.cmdMenu.Layer.MaskandShapePath = function(){ app.executeCommand(3745);}	//レイヤー(L):マスクとシェイプのパス
app.cmdMenu.Layer.New = function(){ app.executeCommand(2606);}	//レイヤー(L):新規(N)
app.cmdMenu.Layer.NextBlendingMode = function(){ app.executeCommand(2781);}	//レイヤー(L):次の描画モード
app.cmdMenu.Layer.OpenLayer = function(){ app.executeCommand(3784);}	//レイヤー(L):レイヤーを開く(O)
app.cmdMenu.Layer.OpenSourceWindow = function(){ app.executeCommand(2523);}	//レイヤー(L):レイヤーソースを開く(U)
app.cmdMenu.Layer.Precompose = function(){ app.executeCommand(2071);}	//レイヤー(L):プリコンポーズ(P)...
app.cmdMenu.Layer.PreserveTransparency = function(){ app.executeCommand(2190);}	//レイヤー(L):透明部分を保持(E)
app.cmdMenu.Layer.PreviousBlendingMode = function(){ app.executeCommand(2782);}	//レイヤー(L):前の描画モード
app.cmdMenu.Layer.Quality = function(){ app.executeCommand(2041);}	//レイヤー(L):画質(Q)
app.cmdMenu.Layer.SendBackward = function(){ app.executeCommand(2019);}	//レイヤー(L):1つ後ろに移動(B)
app.cmdMenu.Layer.SendtoBack = function(){ app.executeCommand(2017);}	//レイヤー(L):背面に移動(A)
app.cmdMenu.Layer.Switches = function(){ app.executeCommand(2053);}	//レイヤー(L):スイッチ(W)
app.cmdMenu.Layer.Time = function(){ app.executeCommand(3155);}	//レイヤー(L):時間
app.cmdMenu.Layer.TrackMatte = function(){ app.executeCommand(2269);}	//レイヤー(L):トラックマット(A)
app.cmdMenu.Layer.Transform = function(){ app.executeCommand(2020);}	//レイヤー(L):トランスフォーム(T)
//--------------------------------------------
app.cmdMenu.Effect = new Object;
app.cmdMenu.Effect.EffectControls = function(){ app.executeCommand(2163);}	//エフェクト(T):エフェクトコントロール(E)
app.cmdMenu.Effect.LastEffect = function(){ app.executeCommand(2452);}	//エフェクト(T):最後のエフェクト(L)
app.cmdMenu.Effect.RemoveAll = function(){ app.executeCommand(2072);}	//エフェクト(T):すべてを削除(R)
//--------------------------------------------
app.cmdMenu.Window = new Object;
app.cmdMenu.Window.AssignWorkspaceShortcut = function(){ app.executeCommand(3707);}	//ウィンドウ(W):ワークスペースにショートカットを割り当て
app.cmdMenu.Window.Workspace = function(){ app.executeCommand(2738);}	//ウィンドウ(W):ワークスペース(S)
//--------------------------------------------
app.cmdMenu.View = new Object;
app.cmdMenu.View.Assign3DViewShortcut = function(){ app.executeCommand(2624);}	//ビュー(V):3D ビューにショートカットを割り当て
app.cmdMenu.View.ClearGuides = function(){ app.executeCommand(2276);}	//ビュー(V):ガイドを消去
app.cmdMenu.View.GotoTime = function(){ app.executeCommand(2076);}	//ビュー(V):時間設定(G)...
app.cmdMenu.View.LockGuides = function(){ app.executeCommand(2275);}	//ビュー(V):ガイドをロック
app.cmdMenu.View.LookatAllLayers = function(){ app.executeCommand(2835);}	//ビュー(V):すべてのレイヤーを全体表示
app.cmdMenu.View.LookatSelectedLayers = function(){ app.executeCommand(2834);}	//ビュー(V):選択したレイヤーを全体表示
app.cmdMenu.View.NewViewer = function(){ app.executeCommand(2039);}	//ビュー(V):新規ビューア
app.cmdMenu.View.Reset3DView = function(){ app.executeCommand(2642);}	//ビュー(V):3D ビューをリセット
app.cmdMenu.View.Resolution = function(){ app.executeCommand(2037);}	//ビュー(V):解像度(R)
app.cmdMenu.View.ShowGrid = function(){ app.executeCommand(2277);}	//ビュー(V):グリッドを表示
app.cmdMenu.View.ShowGuides = function(){ app.executeCommand(2274);}	//ビュー(V):ガイドを表示
app.cmdMenu.View.ShowLayerControls = function(){ app.executeCommand(2435);}	//ビュー(V):レイヤーコントロールを表示
app.cmdMenu.View.ShowRulers = function(){ app.executeCommand(2280);}	//ビュー(V):定規を表示
app.cmdMenu.View.SimulateOutput = function(){ app.executeCommand(3703);}	//ビュー(V):出力をシミュレート
app.cmdMenu.View.SnaptoGrid = function(){ app.executeCommand(2278);}	//ビュー(V):グリッドへスナップ
app.cmdMenu.View.SnaptoGuides = function(){ app.executeCommand(2286);}	//ビュー(V):ガイドへスナップ
app.cmdMenu.View.Switch3DView = function(){ app.executeCommand(2625);}	//ビュー(V):3D ビューを切り替え
app.cmdMenu.View.SwitchtoLast3DView = function(){ app.executeCommand(2703);}	//ビュー(V):最後の 3D ビューに切り替え
app.cmdMenu.View.UseDisplayColorManagement = function(){ app.executeCommand(3704);}	//ビュー(V):モニタのカラーマネジメントを使用
app.cmdMenu.View.ViewOptions = function(){ app.executeCommand(2776);}	//ビュー(V):表示オプション...
app.cmdMenu.View.ZoomIn = function(){ app.executeCommand(2092);}	//ビュー(V):ズームイン
app.cmdMenu.View.ZoomOut = function(){ app.executeCommand(2093);}	//ビュー(V):ズームアウト
//--------------------------------------------
app.cmdMenu.Animation = new Object;
app.cmdMenu.Animation.AddExpression = function(){ app.executeCommand(2702);}	//アニメーション(A):エクスプレッションを追加
app.cmdMenu.Animation.AddTextSelector = function(){ app.executeCommand(3017);}	//アニメーション(A):テキストセレクタを追加
app.cmdMenu.Animation.AnimateText = function(){ app.executeCommand(3016);}	//アニメーション(A):テキストのアニメータプロパティを追加
app.cmdMenu.Animation.ApplyAnimationPreset = function(){ app.executeCommand(2450);}	//アニメーション(A):アニメーションプリセットを適用(A)...
app.cmdMenu.Animation.BrowsePresets = function(){ app.executeCommand(3691);}	//アニメーション(A):アニメーションプリセットを参照...
app.cmdMenu.Animation.KeyframeAssistant = function(){ app.executeCommand(2159);}	//アニメーション(A):キーフレーム補助(K)
app.cmdMenu.Animation.KeyframeInterpolation = function(){ app.executeCommand(2227);}	//アニメーション(A):キーフレーム補間法...
app.cmdMenu.Animation.KeyframeVelocity = function(){ app.executeCommand(2228);}	//アニメーション(A):キーフレーム速度...
app.cmdMenu.Animation.RecentAnimationPresets = function(){ app.executeCommand(2451);}	//アニメーション(A):最近のアニメーションプリセット(E)
app.cmdMenu.Animation.RemoveAllTextAnimators = function(){ app.executeCommand(3058);}	//アニメーション(A):すべてのテキストアニメータを削除
app.cmdMenu.Animation.RevealAnimatingProperties = function(){ app.executeCommand(2387);}	//アニメーション(A):アニメートされているプロパティを表示
app.cmdMenu.Animation.RevealModifiedProperties = function(){ app.executeCommand(2771);}	//アニメーション(A):変更されたプロパティを表示
app.cmdMenu.Animation.SaveAnimationPreset = function(){ app.executeCommand(3075);}	//アニメーション(A):アニメーションプリセットを保存(S)...
app.cmdMenu.Animation.SeparateDimensions = function(){ app.executeCommand(3764);}	//アニメーション(A):次元に分割
app.cmdMenu.Animation.SetKeyframe = function(){ app.executeCommand(2701);}	//アニメーション(A):キーフレームを設定
app.cmdMenu.Animation.StabilizeMotion = function(){ app.executeCommand(2569);}	//アニメーション(A):モーションをスタビライズ
app.cmdMenu.Animation.ToggleHoldKeyframe = function(){ app.executeCommand(2226);}	//アニメーション(A):停止したキーフレームの切り替え
app.cmdMenu.Animation.TrackMotion = function(){ app.executeCommand(2568);}	//アニメーション(A):モーションをトラック
app.cmdMenu.Animation.TrackthisProperty = function(){ app.executeCommand(2643);}	//アニメーション(A):このプロパティをトラック
//--------------------------------------------
app.cmdMenu.FillColor = new Object;
app.cmdMenu.FillColor.Brightness = function(){ app.executeCommand(3032);}	//塗りのカラー:輝度
app.cmdMenu.FillColor.Hue = function(){ app.executeCommand(3030);}	//塗りのカラー:色相
app.cmdMenu.FillColor.Opacity = function(){ app.executeCommand(3033);}	//塗りのカラー:不透明度
app.cmdMenu.FillColor.RGB = function(){ app.executeCommand(3029);}	//塗りのカラー:RGB
app.cmdMenu.FillColor.Saturation = function(){ app.executeCommand(3031);}	//塗りのカラー:彩度
//--------------------------------------------
app.cmdMenu.StrokeColor = new Object;
app.cmdMenu.StrokeColor.Brightness = function(){ app.executeCommand(3037);}	//線のカラー:輝度
app.cmdMenu.StrokeColor.Hue = function(){ app.executeCommand(3035);}	//線のカラー:色相
app.cmdMenu.StrokeColor.Opacity = function(){ app.executeCommand(3038);}	//線のカラー:不透明度
app.cmdMenu.StrokeColor.RGB = function(){ app.executeCommand(3034);}	//線のカラー:RGB
app.cmdMenu.StrokeColor.Saturation = function(){ app.executeCommand(3036);}	//線のカラー:彩度
//--------------------------------------------
app.cmdMenu.Time = new Object;
app.cmdMenu.Time.EnableTimeRemapping = function(){ app.executeCommand(2153);}	//時間:タイムリマップ使用可能
app.cmdMenu.Time.FreezeFrame = function(){ app.executeCommand(3695);}	//時間:フレームを固定
app.cmdMenu.Time.TimeReverseLayer = function(){ app.executeCommand(2135);}	//時間:時間反転レイヤー
app.cmdMenu.Time.TimeStretch = function(){ app.executeCommand(2024);}	//時間:時間伸縮(C)...
//--------------------------------------------
app.cmdMenu.Mask = new Object;
app.cmdMenu.Mask.HideLockedMasks = function(){ app.executeCommand(2524);}	//マスク:ロック済みマスクを隠す
app.cmdMenu.Mask.Inverted = function(){ app.executeCommand(2052);}	//マスク:反転
app.cmdMenu.Mask.LockOtherMasks = function(){ app.executeCommand(2455);}	//マスク:他のマスクをロック
app.cmdMenu.Mask.Locked = function(){ app.executeCommand(2454);}	//マスク:ロック
app.cmdMenu.Mask.MaskExpansion = function(){ app.executeCommand(2736);}	//マスク:マスクの拡張...
app.cmdMenu.Mask.MaskFeather = function(){ app.executeCommand(2069);}	//マスク:マスクの境界線のぼかし...
app.cmdMenu.Mask.MaskOpacity = function(){ app.executeCommand(2453);}	//マスク:マスクの不透明度...
app.cmdMenu.Mask.MaskShape = function(){ app.executeCommand(2068);}	//マスク:マスクシェイプ...
app.cmdMenu.Mask.Mode = function(){ app.executeCommand(2440);}	//マスク:マスクモード
app.cmdMenu.Mask.MotionBlur = function(){ app.executeCommand(2797);}	//マスク:モーションブラー
app.cmdMenu.Mask.NewMask = function(){ app.executeCommand(2367);}	//マスク:新規マスク
app.cmdMenu.Mask.RemoveAllMasks = function(){ app.executeCommand(2369);}	//マスク:すべてのマスクを削除
app.cmdMenu.Mask.RemoveMask = function(){ app.executeCommand(2368);}	//マスク:マスクを削除
app.cmdMenu.Mask.ResetMask = function(){ app.executeCommand(2448);}	//マスク:マスクをリセット
app.cmdMenu.Mask.UnlockAllMasks = function(){ app.executeCommand(2456);}	//マスク:すべてのマスクのロックを解除
//--------------------------------------------
app.cmdMenu.Quality = new Object;
app.cmdMenu.Quality.Best = function(){ app.executeCommand(2045);}	//画質:最高
app.cmdMenu.Quality.Draft = function(){ app.executeCommand(2044);}	//画質:ドラフト
app.cmdMenu.Quality.Wireframe = function(){ app.executeCommand(2042);}	//画質:ワイヤーフレーム
//--------------------------------------------
app.cmdMenu.Resolution = new Object;
app.cmdMenu.Resolution.Custom = function(){ app.executeCommand(2049);}	//解像度:カスタム...
app.cmdMenu.Resolution.Full = function(){ app.executeCommand(2048);}	//解像度:フル画質
app.cmdMenu.Resolution.Half = function(){ app.executeCommand(2047);}	//解像度:1/2画質
app.cmdMenu.Resolution.Quarter = function(){ app.executeCommand(2046);}	//解像度:1/4画質
app.cmdMenu.Resolution.Third = function(){ app.executeCommand(2081);}	//解像度:1/3画質
//--------------------------------------------
app.cmdMenu.Switches = new Object;
app.cmdMenu.Switches.AdjustmentLayer = function(){ app.executeCommand(2263);}	//スイッチ:調整レイヤー
app.cmdMenu.Switches.Audio = function(){ app.executeCommand(2056);}	//スイッチ:オーディオ
app.cmdMenu.Switches.Collapse = function(){ app.executeCommand(2160);}	//スイッチ:コラップス
app.cmdMenu.Switches.Effect = function(){ app.executeCommand(2062);}	//スイッチ:エフェクト
app.cmdMenu.Switches.HideOtherVideo = function(){ app.executeCommand(2054);}	//スイッチ:他のビデオを隠す
app.cmdMenu.Switches.Lock = function(){ app.executeCommand(2114);}	//スイッチ:ロック
app.cmdMenu.Switches.MotionBlur = function(){ app.executeCommand(2116);}	//スイッチ:モーションブラー
app.cmdMenu.Switches.ShowAllVideo = function(){ app.executeCommand(2055);}	//スイッチ:すべてのビデオの表示
app.cmdMenu.Switches.Shy = function(){ app.executeCommand(2113);}	//スイッチ:シャイ
app.cmdMenu.Switches.Solo = function(){ app.executeCommand(2566);}	//スイッチ:ソロ
app.cmdMenu.Switches.UnlockAllLayers = function(){ app.executeCommand(2244);}	//スイッチ:すべてのレイヤーのロックを解除
app.cmdMenu.Switches.Video = function(){ app.executeCommand(2059);}	//スイッチ:ビデオ
//--------------------------------------------
app.cmdMenu.Transform = new Object;
app.cmdMenu.Transform.AnchorPoint = function(){ app.executeCommand(2101);}	//トランスフォーム:^1...
app.cmdMenu.Transform.AutoOrient = function(){ app.executeCommand(2165);}	//トランスフォーム:自動方向...
app.cmdMenu.Transform.CenterInView = function(){ app.executeCommand(3819);}	//トランスフォーム:中央に配置
app.cmdMenu.Transform.FittoCompHeight = function(){ app.executeCommand(2733);}	//トランスフォーム:コンポジションの高さに合わせる
app.cmdMenu.Transform.FittoCompWidth = function(){ app.executeCommand(2732);}	//トランスフォーム:コンポジションの幅に合わせる
app.cmdMenu.Transform.FittoComp = function(){ app.executeCommand(2156);}	//トランスフォーム:コンポジションに合わせる
app.cmdMenu.Transform.FlipHorizontal = function(){ app.executeCommand(3766);}	//トランスフォーム:水平方向に反転
app.cmdMenu.Transform.FlipVertical = function(){ app.executeCommand(3767);}	//トランスフォーム:垂直方向に反転
app.cmdMenu.Transform.Opacity = function(){ app.executeCommand(2070);}	//トランスフォーム:不透明度...
app.cmdMenu.Transform.Orientation = function(){ app.executeCommand(2623);}	//トランスフォーム:方向...
app.cmdMenu.Transform.Position = function(){ app.executeCommand(2065);}	//トランスフォーム:位置...
app.cmdMenu.Transform.Reset = function(){ app.executeCommand(2605);}	//トランスフォーム:リセット(R)
app.cmdMenu.Transform.Rotation = function(){ app.executeCommand(2792);}	//トランスフォーム:回転...
app.cmdMenu.Transform.Scale = function(){ app.executeCommand(2066);}	//トランスフォーム:スケール...
//--------------------------------------------
app.cmdMenu.Resolution = new Object;
app.cmdMenu.Resolution.Custom = function(){ app.executeCommand(2049);}	//解像度 ::カスタム...
//--------------------------------------------
app.cmdMenu.Import = new Object;
app.cmdMenu.Import.File = function(){ app.executeCommand(2003);}	//読み込み:ファイル...
app.cmdMenu.Import.MultipleFiles = function(){ app.executeCommand(2236);}	//読み込み:複数ファイル...
//--------------------------------------------
app.cmdMenu.SetProxy = new Object;
app.cmdMenu.SetProxy.File = function(){ app.executeCommand(2118);}	//プロキシ設定:ファイル...
app.cmdMenu.SetProxy.None = function(){ app.executeCommand(2119);}	//プロキシ設定:なし
//--------------------------------------------
app.cmdMenu.SaveFrameAs = new Object;
app.cmdMenu.SaveFrameAs.PICT = function(){ app.executeCommand(2025);}	//フレームを保存:PICT
//--------------------------------------------
app.cmdMenu.InterpretFootage = new Object;
app.cmdMenu.InterpretFootage.ApplyInterpretation = function(){ app.executeCommand(2255);}	//フッテージを変換:変換を適用
app.cmdMenu.InterpretFootage.Main = function(){ app.executeCommand(2077);}	//フッテージを変換:メイン...
app.cmdMenu.InterpretFootage.Proxy = function(){ app.executeCommand(2103);}	//フッテージを変換:プロキシ...
app.cmdMenu.InterpretFootage.RememberInterpretation = function(){ app.executeCommand(2254);}	//フッテージを変換:変換を記憶
//--------------------------------------------
app.cmdMenu.Preferences = new Object;
app.cmdMenu.Preferences.AudioHardware = function(){ app.executeCommand(3125);}	//環境設定(P):オーディオハードウェア...
app.cmdMenu.Preferences.AudioOutputMapping = function(){ app.executeCommand(3126);}	//環境設定(P):オーディオ出力マッピング...
app.cmdMenu.Preferences.AutoSave = function(){ app.executeCommand(3122);}	//環境設定(P):自動保存...
app.cmdMenu.Preferences.DiskCaching = function(){ app.executeCommand(2439);}	//環境設定(P):メディア＆ディスクキャッシュ...
app.cmdMenu.Preferences.Display = function(){ app.executeCommand(2361);}	//環境設定(P):ディスプレイ設定(D)...
app.cmdMenu.Preferences.General = function(){ app.executeCommand(2359);}	//環境設定(P):一般設定(E)...
app.cmdMenu.Preferences.GridsGuides = function(){ app.executeCommand(2364);}	//環境設定(P):グリッド＆ガイド(G)...
app.cmdMenu.Preferences.Import = function(){ app.executeCommand(2362);}	//環境設定(P):読み込み設定(I)...
app.cmdMenu.Preferences.LabelColors = function(){ app.executeCommand(2365);}	//環境設定(P):ラベルカラー(B)...
app.cmdMenu.Preferences.LabelDefaults = function(){ app.executeCommand(2706);}	//環境設定(P):ラベル初期設定(L)...
app.cmdMenu.Preferences.MemoryMultiprocessing = function(){ app.executeCommand(3124);}	//環境設定(P):メモリ＆マルチプロセッサ...
app.cmdMenu.Preferences.Output = function(){ app.executeCommand(2363);}	//環境設定(P):出力設定(O)...
app.cmdMenu.Preferences.Previews = function(){ app.executeCommand(2705);}	//環境設定(P):プレビュー(P)...
app.cmdMenu.Preferences.UserInterfaceColors = function(){ app.executeCommand(3071);}	//環境設定(P):アピアランス...
app.cmdMenu.Preferences.VideoPreview = function(){ app.executeCommand(2704);}	//環境設定(P):ビデオプレビュー(V)...
//--------------------------------------------
app.cmdMenu.FrameBlending = new Object;
app.cmdMenu.FrameBlending.FrameMix = function(){ app.executeCommand(2291);}	//フレームブレンド:フレームミックス
app.cmdMenu.FrameBlending.Off = function(){ app.executeCommand(2290);}	//フレームブレンド:オフ
app.cmdMenu.FrameBlending.PixelMotion = function(){ app.executeCommand(2292);}	//フレームブレンド:ピクセルモーション
//--------------------------------------------
app.cmdMenu.Preview = new Object;
app.cmdMenu.Preview.AudioPreviewHereForward = function(){ app.executeCommand(2127);}	//プレビュー:オーディオプレビュー(現地点から開始)
app.cmdMenu.Preview.AudioPreviewWorkArea = function(){ app.executeCommand(2772);}	//プレビュー:オーディオプレビュー（ワークエリア）
app.cmdMenu.Preview.Audio = function(){ app.executeCommand(2434);}	//プレビュー:オーディオ
app.cmdMenu.Preview.MotionwithTrails = function(){ app.executeCommand(2252);}	//プレビュー:軌跡付きモーション
app.cmdMenu.Preview.RAMPreview = function(){ app.executeCommand(2285);}	//プレビュー:RAMプレビュー
app.cmdMenu.Preview.WireframePreview = function(){ app.executeCommand(2251);}	//プレビュー:ワイヤーフレームプレビュー
//--------------------------------------------
app.cmdMenu.Color = new Object;
app.cmdMenu.Color.Movie = function(){ app.executeCommand(2779);}	//カラー ::ムービー...
app.cmdMenu.Color.Still = function(){ app.executeCommand(2778);}	//カラー ::静止画...
//--------------------------------------------
app.cmdMenu.TimeSpan = new Object;
app.cmdMenu.TimeSpan.Custom = function(){ app.executeCommand(2155);}	//周期 ::カスタム...
//--------------------------------------------
app.cmdMenu.MaskShapePath = new Object;
app.cmdMenu.MaskShapePath.Closed = function(){ app.executeCommand(2374);}	//マスクとシェイプのパス:クローズパス
app.cmdMenu.MaskShapePath.FreeTransformPoints = function(){ app.executeCommand(2051);}	//マスクとシェイプのパス:トランスフォームボックス
app.cmdMenu.MaskShapePath.RotoBezier = function(){ app.executeCommand(3053);}	//マスクとシェイプのパス:ロトベジェ
app.cmdMenu.MaskShapePath.SetFirstVertex = function(){ app.executeCommand(2768);}	//マスクとシェイプのパス:最初の頂点を設定
//--------------------------------------------
app.cmdMenu.ReplaceFootage = new Object;
app.cmdMenu.ReplaceFootage.File = function(){ app.executeCommand(2078);}	//フッテージの置き換え:ファイル...
app.cmdMenu.ReplaceFootage.WithLayeredComp = function(){ app.executeCommand(3070);}	//フッテージの置き換え:レイヤーのあるコンポジション
//--------------------------------------------
app.cmdMenu.PurgeSubmenu = new Object;
app.cmdMenu.PurgeSubmenu.All = function(){ app.executeCommand(2373);}	//サブメニューを消去:すべて
app.cmdMenu.PurgeSubmenu.ImageCaches = function(){ app.executeCommand(2372);}	//サブメニューを消去:イメージキャッシュ
app.cmdMenu.PurgeSubmenu.Snapshot = function(){ app.executeCommand(2481);}	//サブメニューを消去:スナップショット
app.cmdMenu.PurgeSubmenu.Undo = function(){ app.executeCommand(2371);}	//サブメニューを消去:取り消し
//--------------------------------------------
app.cmdMenu.MaskMode2 = new Object;
app.cmdMenu.MaskMode2.Add = function(){ app.executeCommand(2442);}	//マスクモード 2:加算
app.cmdMenu.MaskMode2.Darken = function(){ app.executeCommand(2446);}	//マスクモード 2:暗く
app.cmdMenu.MaskMode2.Difference = function(){ app.executeCommand(2447);}	//マスクモード 2:差
app.cmdMenu.MaskMode2.Intersect = function(){ app.executeCommand(2444);}	//マスクモード 2:交差
app.cmdMenu.MaskMode2.Lighten = function(){ app.executeCommand(2445);}	//マスクモード 2:明るく
app.cmdMenu.MaskMode2.None = function(){ app.executeCommand(2441);}	//マスクモード 2:なし
app.cmdMenu.MaskMode2.Subtract = function(){ app.executeCommand(2443);}	//マスクモード 2:減算
//--------------------------------------------
app.cmdMenu.Shuttersubmenu = new Object;
app.cmdMenu.Shuttersubmenu.Shutter180Phase0 = function(){ app.executeCommand(2557);}	//シャッターサブメニュー:シャッター180フェーズ 0
app.cmdMenu.Shuttersubmenu.Shutter180Phase180 = function(){ app.executeCommand(2560);}	//シャッターサブメニュー:シャッター180フェーズ 180
app.cmdMenu.Shuttersubmenu.Shutter360Phase0 = function(){ app.executeCommand(2558);}	//シャッターサブメニュー:シャッター360フェーズ 0
app.cmdMenu.Shuttersubmenu.Shutter720Phase360 = function(){ app.executeCommand(2561);}	//シャッターサブメニュー:シャッター720フェーズ -360
app.cmdMenu.Shuttersubmenu.Shutter90Phase0 = function(){ app.executeCommand(2559);}	//シャッターサブメニュー:シャッター90フェーズ 0
//--------------------------------------------
app.cmdMenu.NewLayersubmenu = new Object;
app.cmdMenu.NewLayersubmenu.AdjustmentLayer = function(){ app.executeCommand(2279);}	//新規レイヤーサブメニュー:調整レイヤー(A)
app.cmdMenu.NewLayersubmenu.AdobePhotoshopFile = function(){ app.executeCommand(3148);}	//新規レイヤーサブメニュー:Adobe Photoshop ファイル(H)...
app.cmdMenu.NewLayersubmenu.Camera = function(){ app.executeCommand(2564);}	//新規レイヤーサブメニュー:カメラ(C)...
app.cmdMenu.NewLayersubmenu.Light = function(){ app.executeCommand(2563);}	//新規レイヤーサブメニュー:ライト(L)...
app.cmdMenu.NewLayersubmenu.NullObject = function(){ app.executeCommand(2767);}	//新規レイヤーサブメニュー:ヌルオブジェクト(N)
app.cmdMenu.NewLayersubmenu.ShapeLayer = function(){ app.executeCommand(3736);}	//新規レイヤーサブメニュー:シェイプレイヤー
app.cmdMenu.NewLayersubmenu.Solid = function(){ app.executeCommand(2038);}	//新規レイヤーサブメニュー:平面(S)...
app.cmdMenu.NewLayersubmenu.Text = function(){ app.executeCommand(2836);}	//新規レイヤーサブメニュー:テキスト(T)
//--------------------------------------------
app.cmdMenu.Remember3DView = new Object;
app.cmdMenu.Remember3DView.A = function(){ app.executeCommand(2626);}	//3Dビューを記憶:A
app.cmdMenu.Remember3DView.B = function(){ app.executeCommand(2627);}	//3Dビューを記憶:B
app.cmdMenu.Remember3DView.C = function(){ app.executeCommand(2628);}	//3Dビューを記憶:C
//--------------------------------------------
app.cmdMenu.SwitchTo3DView = new Object;
app.cmdMenu.SwitchTo3DView.ActiveCamera = function(){ app.executeCommand(2710);}	//3Dビューに切り替え:アクティブカメラ
app.cmdMenu.SwitchTo3DView.Back = function(){ app.executeCommand(2714);}	//3Dビューに切り替え:バックビュー
app.cmdMenu.SwitchTo3DView.Bottom = function(){ app.executeCommand(2716);}	//3Dビューに切り替え:ボトムビュー
app.cmdMenu.SwitchTo3DView.CustomView1 = function(){ app.executeCommand(2717);}	//3Dビューに切り替え:カスタムビュー 1
app.cmdMenu.SwitchTo3DView.CustomView2 = function(){ app.executeCommand(2718);}	//3Dビューに切り替え:カスタムビュー 2
app.cmdMenu.SwitchTo3DView.CustomView3 = function(){ app.executeCommand(2719);}	//3Dビューに切り替え:カスタムビュー 3
app.cmdMenu.SwitchTo3DView.Front = function(){ app.executeCommand(2711);}	//3Dビューに切り替え:フロントビュー
app.cmdMenu.SwitchTo3DView.Left = function(){ app.executeCommand(2712);}	//3Dビューに切り替え:レフトビュー
app.cmdMenu.SwitchTo3DView.Right = function(){ app.executeCommand(2715);}	//3Dビューに切り替え:ライトビュー
app.cmdMenu.SwitchTo3DView.Top = function(){ app.executeCommand(2713);}	//3Dビューに切り替え:トップビュー
//--------------------------------------------
app.cmdMenu.RememberWorkspace = new Object;
app.cmdMenu.RememberWorkspace.A = function(){ app.executeCommand(3708);}	//ワークスペースを記憶:A
app.cmdMenu.RememberWorkspace.B = function(){ app.executeCommand(3709);}	//ワークスペースを記憶:B
app.cmdMenu.RememberWorkspace.C = function(){ app.executeCommand(3710);}	//ワークスペースを記憶:C
//--------------------------------------------
app.cmdMenu.AdobeDynamicLink = new Object;
app.cmdMenu.AdobeDynamicLink.ImportPremiereProSequence = function(){ app.executeCommand(2554);}	//Adobe Dynamic Link:Premiere Pro シーケンスを読み込み...
app.cmdMenu.AdobeDynamicLink.NewPremiereProSequence = function(){ app.executeCommand(2553);}	//Adobe Dynamic Link:新規 Premiere Pro シーケンス...
//--------------------------------------------
app.cmdMenu.CompControls = new Object;
app.cmdMenu.CompControls.ViewOptions = function(){ app.executeCommand(2776);}	//コンポジション制御:表示オプション...
//--------------------------------------------
app.cmdMenu.MaskMotionBlur = new Object;
app.cmdMenu.MaskMotionBlur.Off = function(){ app.executeCommand(2800);}	//マスクモーションブラー:オフ
app.cmdMenu.MaskMotionBlur.On = function(){ app.executeCommand(2799);}	//マスクモーションブラー:オン
app.cmdMenu.MaskMotionBlur.SameAsLayer = function(){ app.executeCommand(2798);}	//マスクモーションブラー:レイヤーと同じ
//--------------------------------------------
app.cmdMenu.SaveFrameAs = new Object;
app.cmdMenu.SaveFrameAs.File = function(){ app.executeCommand(2104);}	//フレームを保存:ファイル...
//--------------------------------------------
app.cmdMenu.InterpretFootage = new Object;
app.cmdMenu.InterpretFootage.CreateProxy = function(){ app.executeCommand(2777);}	//フッテージを変換:プロキシ作成
//--------------------------------------------
app.cmdMenu.NewSubmenu = new Object;
app.cmdMenu.NewSubmenu.AdobePhotoshopFile = function(){ app.executeCommand(3147);}	//新規サブメニュー:Adobe Photoshop ファイル(H)...
app.cmdMenu.NewSubmenu.NewFolder = function(){ app.executeCommand(2139);}	//新規サブメニュー:新規フォルダ(F)
app.cmdMenu.NewSubmenu.NewProject = function(){ app.executeCommand(2);}	//新規サブメニュー:新規プロジェクト(P)
//--------------------------------------------
app.cmdMenu.TemplateSubmenu = new Object;
app.cmdMenu.TemplateSubmenu.OutputModule = function(){ app.executeCommand(2150);}	//テンプレートサブメニュー:出力モジュール(M)...
app.cmdMenu.TemplateSubmenu.RenderSettings = function(){ app.executeCommand(2149);}	//テンプレートサブメニュー:レンダリング設定(R)...
//--------------------------------------------
app.cmdMenu.NewTransferMode = new Object;
app.cmdMenu.NewTransferMode.Add = function(){ app.executeCommand(2170);}	//新規描画モード:加算
app.cmdMenu.NewTransferMode.AlphaAdd = function(){ app.executeCommand(2198);}	//新規描画モード:アルファ追加
app.cmdMenu.NewTransferMode.ClassicColorBurn = function(){ app.executeCommand(2177);}	//新規描画モード:焼き込みカラー（クラシック）
app.cmdMenu.NewTransferMode.ClassicColorDodge = function(){ app.executeCommand(2176);}	//新規描画モード:覆い焼きカラー（クラシック）
app.cmdMenu.NewTransferMode.ClassicDifference = function(){ app.executeCommand(2180);}	//新規描画モード:差（クラシック）
app.cmdMenu.NewTransferMode.ColorBurn = function(){ app.executeCommand(2201);}	//新規描画モード:焼き込みカラー
app.cmdMenu.NewTransferMode.ColorDodge = function(){ app.executeCommand(2200);}	//新規描画モード:覆い焼きカラー
app.cmdMenu.NewTransferMode.Color = function(){ app.executeCommand(2184);}	//新規描画モード:カラー
app.cmdMenu.NewTransferMode.DancingDissolve = function(){ app.executeCommand(2169);}	//新規描画モード:ダイナミックディザ合成
app.cmdMenu.NewTransferMode.Darken = function(){ app.executeCommand(2178);}	//新規描画モード:比較 (暗)
app.cmdMenu.NewTransferMode.DarkerColor = function(){ app.executeCommand(2209);}	//新規描画モード:カラー比較 (暗)
app.cmdMenu.NewTransferMode.Difference = function(){ app.executeCommand(2199);}	//新規描画モード:差
app.cmdMenu.NewTransferMode.Dissolve = function(){ app.executeCommand(2168);}	//新規描画モード:ディザ合成
app.cmdMenu.NewTransferMode.Exclusion = function(){ app.executeCommand(2181);}	//新規描画モード:除外
app.cmdMenu.NewTransferMode.HardLight = function(){ app.executeCommand(2175);}	//新規描画モード:ハードライト
app.cmdMenu.NewTransferMode.HardMix = function(){ app.executeCommand(2207);}	//新規描画モード:ハードミックス
app.cmdMenu.NewTransferMode.Hue = function(){ app.executeCommand(2182);}	//新規描画モード:色相
app.cmdMenu.NewTransferMode.Lighten = function(){ app.executeCommand(2179);}	//新規描画モード:比較 (明)
app.cmdMenu.NewTransferMode.LighterColor = function(){ app.executeCommand(2208);}	//新規描画モード:カラー比較 (明)
app.cmdMenu.NewTransferMode.LinearBurn = function(){ app.executeCommand(2203);}	//新規描画モード:焼き込みリニア
app.cmdMenu.NewTransferMode.LinearDodge = function(){ app.executeCommand(2202);}	//新規描画モード:覆い焼きリニア
app.cmdMenu.NewTransferMode.LinearLight = function(){ app.executeCommand(2204);}	//新規描画モード:リニアライト
app.cmdMenu.NewTransferMode.LuminescentPremul = function(){ app.executeCommand(2197);}	//新規描画モード:ルミナンスキープリマルチプライ
app.cmdMenu.NewTransferMode.Luminosity = function(){ app.executeCommand(2185);}	//新規描画モード:輝度
app.cmdMenu.NewTransferMode.Multiply = function(){ app.executeCommand(2171);}	//新規描画モード:乗算
app.cmdMenu.NewTransferMode.Normal = function(){ app.executeCommand(2167);}	//新規描画モード:通常
app.cmdMenu.NewTransferMode.Overlay = function(){ app.executeCommand(2173);}	//新規描画モード:オーバーレイ
app.cmdMenu.NewTransferMode.PinLight = function(){ app.executeCommand(2206);}	//新規描画モード:ピンライト
app.cmdMenu.NewTransferMode.Saturation = function(){ app.executeCommand(2183);}	//新規描画モード:彩度
app.cmdMenu.NewTransferMode.Screen = function(){ app.executeCommand(2172);}	//新規描画モード:スクリーン
app.cmdMenu.NewTransferMode.SilhouetteAlpha = function(){ app.executeCommand(2188);}	//新規描画モード:シルエットアルファ
app.cmdMenu.NewTransferMode.SilhouetteLuma = function(){ app.executeCommand(2189);}	//新規描画モード:シルエットルミナンスキー
app.cmdMenu.NewTransferMode.SoftLight = function(){ app.executeCommand(2174);}	//新規描画モード:ソフトライト
app.cmdMenu.NewTransferMode.StencilAlpha = function(){ app.executeCommand(2186);}	//新規描画モード:ステンシルアルファ
app.cmdMenu.NewTransferMode.StencilLuma = function(){ app.executeCommand(2187);}	//新規描画モード:ステンシルルミナンスキー
app.cmdMenu.NewTransferMode.VividLight = function(){ app.executeCommand(2205);}	//新規描画モード:ビビッドライト
//--------------------------------------------
app.cmdMenu.TrackMatte = new Object;
app.cmdMenu.TrackMatte.AlphaInvertedMatte = function(){ app.executeCommand(2193);}	//トラックマット:アルファ反転マット
app.cmdMenu.TrackMatte.AlphaMatte = function(){ app.executeCommand(2192);}	//トラックマット:アルファマット
app.cmdMenu.TrackMatte.LumaInvertedMatte = function(){ app.executeCommand(2195);}	//トラックマット:ルミナンスキー反転マット
app.cmdMenu.TrackMatte.LumaMatte = function(){ app.executeCommand(2194);}	//トラックマット:ルミナンスキーマット
app.cmdMenu.TrackMatte.NoTrackMatte = function(){ app.executeCommand(2191);}	//トラックマット:トラックマットなし
//--------------------------------------------
app.cmdMenu.Label = new Object;
app.cmdMenu.Label.None = function(){ app.executeCommand(2350);}	//ラベル:なし
app.cmdMenu.Label.SelectLabelGroup = function(){ app.executeCommand(2436);}	//ラベル:ラベルグループを選択
app.cmdMenu.Label.Set1 = function(){ app.executeCommand(2351);}	//ラベル:Unused
app.cmdMenu.Label.Set2 = function(){ app.executeCommand(2352);}	//ラベル:Unused
app.cmdMenu.Label.Set3 = function(){ app.executeCommand(2353);}	//ラベル:Unused
app.cmdMenu.Label.Set4 = function(){ app.executeCommand(2354);}	//ラベル:Unused
app.cmdMenu.Label.Set5 = function(){ app.executeCommand(2355);}	//ラベル:Unused
app.cmdMenu.Label.Set6 = function(){ app.executeCommand(2356);}	//ラベル:Unused
app.cmdMenu.Label.Set7 = function(){ app.executeCommand(2357);}	//ラベル:Unused
app.cmdMenu.Label.Set8 = function(){ app.executeCommand(3746);}	//ラベル:Unused
app.cmdMenu.Label.Set9 = function(){ app.executeCommand(3747);}	//ラベル:Unused
app.cmdMenu.Label.Set10 = function(){ app.executeCommand(3748);}	//ラベル:Unused
app.cmdMenu.Label.Set11 = function(){ app.executeCommand(3749);}	//ラベル:Unused
app.cmdMenu.Label.Set12 = function(){ app.executeCommand(3750);}	//ラベル:Unused
app.cmdMenu.Label.Set13 = function(){ app.executeCommand(3751);}	//ラベル:Unused
app.cmdMenu.Label.Set14 = function(){ app.executeCommand(3752);}	//ラベル:Unused
app.cmdMenu.Label.Set15 = function(){ app.executeCommand(3753);}	//ラベル:Unused
//--------------------------------------------
app.cmdMenu.AnimatorTLWMenu = new Object;
app.cmdMenu.AnimatorTLWMenu.Property = function(){ app.executeCommand(3016);}	//Animator TLW Menu:プロパティ
app.cmdMenu.AnimatorTLWMenu.Selector = function(){ app.executeCommand(3017);}	//Animator TLW Menu:セレクタ
