﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace ContEditorNazoh
{
	/// <summary>
	/// セーブファイルを管理するクラス
	/// </summary>
    public class ContFiles
    {
        private ContDocument _ContDocument;
        //-------------------------------------------------------------
        public ContFiles(ContDocument ci)
        {
            _ContDocument = ci;
        }
        //-------------------------------------------------------------
        /// <summary>
        /// コンテデータを保存
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
		public bool SaveToNazFile(string path)
        {
            if (_ContDocument == null) return false;
			//ヘッダ
            string data = def.NazHeader +"\n";

			//パラメータ
            data += "*Params\n";
            data += "\tLocked\t" + _ContDocument.Locked.ToString() + "\n";
            data += "\tfps\t" + _ContDocument.fps.ToString() + "\n";
			data += "\tNumberStart\t" + _ContDocument.NumberStart.ToString() + "\n";
			data += "\tPageNumberStart\t" + _ContDocument.PageNumberStart.ToString() + "\n";

			data += "\tPublicPict0Name\t" + _ContDocument.PublicPict0.name + "\n";
            data += "\tPublicPict0X\t" + _ContDocument.PublicPict0.X.ToString() + "\n";
            data += "\tPublicPict0Y\t" + _ContDocument.PublicPict0.Y.ToString() + "\n";
            data += "\tPublicPict1Name\t" + _ContDocument.PublicPict1.name + "\n";
            data += "\tPublicPict1X\t" + _ContDocument.PublicPict1.X.ToString() + "\n";
            data += "\tPublicPict1Y\t" + _ContDocument.PublicPict1.Y.ToString() + "\n";
            data += "\tPublicPict2Name\t" + _ContDocument.PublicPict2.name + "\n";
            data += "\tPublicPict2X\t" + _ContDocument.PublicPict2.X.ToString() + "\n";
            data += "\tPublicPict3Y\t" + _ContDocument.PublicPict2.Y.ToString() + "\n";

            data += "\tPartCaptions\t" + _ContDocument.GetPartCaptionLine() + "\n";
            data += "\tIsPrintPartCaption\t" + _ContDocument.IsPrintPartCaption.ToString() + "\n";

            
            data += "\tTitle\t" + _ContDocument.Title + "\n";
			data += "\tSubTitle\t" + _ContDocument.SubTitle + "\n";
			data += "\tOPUS\t" + _ContDocument.OPUS + "\n";
			data += "\tCreateUser\t" + _ContDocument.CreateUser + "\n";
			data += "\tUpdateUser\t" + _ContDocument.UpdateUser + "\n";
			data += "\tCampanyName\t" + _ContDocument.CampanyName + "\n";
			data += "\tComment\t" + _ContDocument.Comment + "\n";

            data += "\tVersion\t" + ((int)_ContDocument.Version).ToString() + "\n";
            data += "\tTargetDuration\t" + ((int)_ContDocument.TargetDuration).ToString() + "\n";

			data += "\tIsPrintTitle\t" + _ContDocument.IsPrintTitle.ToString() + "\n";
			data += "\tIsPrintSubTitle\t" + _ContDocument.IsPrintSubTitle.ToString() + "\n";
			data += "\tIsPrintOPUS\t" + _ContDocument.IsPrintOPUS.ToString() + "\n";
			data += "\tIsPrintCampany\t" + _ContDocument.IsPrintCampany.ToString() + "\n";
			data += "\tIsPrintDurationInfo\t" + _ContDocument.IsPrintDurationInfo.ToString() + "\n";

			
			data += "*ParamsEnd\n\n";

            
			//コンテデータの始まり
			data += "*data\n";
            for (int i = 0; i < _ContDocument.KomaCount; i++)
            {
                data += _ContDocument.GetKomaData(i)+"\n";
            }
            data += "\n*end\n";

			//書き込み
            StreamWriter sw = new StreamWriter(path, false, Encoding.GetEncoding("utf-8"));
            try
            {
                sw.Write(data);
            }
            catch
            {
                return false;
            }
            finally
            {
                sw.Close();
            }
            return true;
        }
        //-------------------------------------------------------------
        /// <summary>
        /// 配列からTagを探す.
		/// Tagは "*"型始まる文字列 
        /// </summary>
        /// <param name="lines">
		/// 対象の配列
		/// </param>
        /// <param name="tag">
		/// 探すTag
		/// </param>
        /// <param name="startIdx">
		/// 探し始めるインデックス値
		/// </param>
        /// <returns>
		/// 発見したインデックス値。無ければ-1
		/// </returns>
		private int FindTag(string [] lines, string tag,int startIdx)
        {
            int ret = -1;
            
			if ((lines.Length <= 0)||(tag=="")) return ret;
            if (startIdx >= lines.Length) return ret;
            if (startIdx < 0) startIdx = 0;

			string t = tag.ToLower().Trim();
			//
			if (t[0] != '*') t = "*" + t;
            for (int i = startIdx; i < lines.Length; i++)
            {
				string line = lines[i].ToLower().Trim();
				if (line != string.Empty)
				{
					string[] prm = line.Split('\t');
					if (prm[0].Trim() == t)
					{
						return i;
					}
				}
            }
            return ret;
        }
		/// <summary>
		/// 次のTagを探す。無ければ配列最後のインデックスを返す
		/// </summary>
		/// <param name="lines"></param>
		/// <param name="startIdx"></param>
		/// <returns></returns>
		private int NextTag(string[] lines, int startIdx)
		{
			int cnt = lines.Length - 1;
			if ( (cnt < 0)||(startIdx >cnt)) return cnt;

			if (startIdx < 0) startIdx = 0;

			for (int i = startIdx; i <= cnt; i++)
			{
				string line = lines[i].ToLower().Trim();
				if (line != string.Empty)
				{
					string[] prm = line.Split('\t');
					if (prm[0][0] == '*')
					{
						return i;
					}
				}
			}
			return cnt;
		}
        //-------------------------------------------------------------
        public string [] ListupNazFile(string path)
        {
            if (Directory.Exists(path) == false)
            {
                return new string[0];
            }
            else
            {
                return Directory.GetFiles(path, "*" + def.NazExt);
            }
        }
        //-------------------------------------------------------------
        /// <summary>
        /// コンテデータファイルを読み込み
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
		public bool LoadFromNazFile(string path)
        {
            if (_ContDocument == null) return false;
			//まとめて配列に読み込み
            string[] lines = File.ReadAllLines(path, Encoding.GetEncoding("utf-8"));
            int cnt = lines.Length; 
            if (cnt <= 0) return false;
            
			//ヘッダーチェック
			if (lines[0].Trim() != def.NazHeader) return false;

            //パラメータ
            int sIdx = FindTag(lines,"*Params",1);
			if ((sIdx < 0) || (sIdx >= cnt)) return false;
			sIdx++;
			int eIdx = NextTag(lines,  sIdx +1);
			if (sIdx >= eIdx) return false;

            //初期化
            _ContDocument.Locked = false;
            _ContDocument.fps = def.fps;
            _ContDocument.PublicPict0.Clear();
            _ContDocument.PublicPict1.Clear();
            _ContDocument.PublicPict2.Clear();
            _ContDocument.NumberStart = 1;
			_ContDocument.PageNumberStart = 0;
			_ContDocument.Title = "";
			_ContDocument.SubTitle = "";
			_ContDocument.OPUS = "";
			_ContDocument.CreateUser = "";
			_ContDocument.UpdateUser = "";
			_ContDocument.CampanyName = "";
			_ContDocument.Comment = "";
            _ContDocument.Version = ContVersion.First;
            _ContDocument.TargetDuration = 0;
			_ContDocument.IsPrintTitle = false;
			_ContDocument.IsPrintSubTitle = false;
			_ContDocument.IsPrintOPUS = false;
			_ContDocument.IsPrintCampany = true;
			_ContDocument.IsPrintDurationInfo = true;
            _ContDocument.IsPrintPartCaption = false;

            _ContDocument.DefaultPartCaption();
			//-------------
            for (int i = sIdx; i < eIdx; i++)
            {
                string line = lines[i].Trim();
                if (line != string.Empty)
                {
                    string[] prm = line.Split('\t');
                    if (prm.Length >= 2)
                    {
						int ii = 0;
                        prm[0] = prm[0].ToLower();
                        bool b = false;
                        float f = 0;
                                     
                        switch (prm[0])
                        {
                            case "locked":
                                b = false;
                                if (bool.TryParse(prm[1], out b))
                                {
                                    _ContDocument.Locked = b;
                                }
                                break;
                            case "fps":
                                f = def.fps;
                                if (float.TryParse(prm[1], out f))
                                {
                                    _ContDocument.fps = f;
                                }
                                break;
                            case "targetduration":
                                f = 0;
                                if (float.TryParse(prm[1], out f))
                                {
                                    _ContDocument.TargetDuration = f;
                                }
                                break;
                            case "numberstart":
                                ii = 1;
                                if (int.TryParse(prm[1], out ii))
                                {
                                    _ContDocument.NumberStart = ii;
                                }
                                break;
							case "pagestartnumber":
								ii = 1;
								if (int.TryParse(prm[1], out ii))
								{
									_ContDocument.PageNumberStart = ii;
								}
								break;
							case "publicpict0name":
								_ContDocument.PublicPict0.name = prm[1];
								break;
                            case "publicpict0X":
                                ii = 0;
                                if (int.TryParse(prm[1], out ii))
                                {
                                    _ContDocument.PublicPict0.X = ii;
                                }
                                break;
                            case "publicpict0Y":
                                ii = 0;
                                if (int.TryParse(prm[1], out ii))
                                {
                                    _ContDocument.PublicPict0.X = ii;
                                }
                                break;
                            case "publicpict1name":
                                _ContDocument.PublicPict1.name = prm[1];
                                break;
                            case "publicpict1X":
                                ii = 0;
                                if (int.TryParse(prm[1], out ii))
                                {
                                    _ContDocument.PublicPict1.X = ii;
                                }
                                break;
                            case "publicpict1Y":
                                ii = 0;
                                if (int.TryParse(prm[1], out ii))
                                {
                                    _ContDocument.PublicPict1.X = ii;
                                }
                                break;
                            case "publicpict2name":
                                _ContDocument.PublicPict2.name = prm[1];
                                break;
                            case "publicpict2X":
                                ii = 0;
                                if (int.TryParse(prm[1], out ii))
                                {
                                    _ContDocument.PublicPict2.X = ii;
                                }
                                break;
                            case "publicpict2Y":
                                ii = 0;
                                if (int.TryParse(prm[1], out ii))
                                {
                                    _ContDocument.PublicPict2.X = ii;
                                }
                                break;
                            case "partcaptions":
                                _ContDocument.PartCaptionsLine = prm[1];
                                break;
                            case "isprintpartcaption":
                                b = false;
                                if (bool.TryParse(prm[1], out b))
                                {
                                    _ContDocument.IsPrintPartCaption = b;
                                }
                                break;
                            case "title":
								_ContDocument.Title = prm[1];
								break;
							case "subtitle":
								_ContDocument.SubTitle = prm[1];
								break;
							case "opus":
								_ContDocument.OPUS = prm[1];
								break;
							case "createuser":
								_ContDocument.CreateUser = prm[1];
								break;
							case "updateuser":
								_ContDocument.UpdateUser = prm[1];
								break;
							case "campanyname":
								_ContDocument.CampanyName = prm[1];
								break;
							case "comment":
								_ContDocument.Comment = prm[1];
								break;
                            case "version":
								ii = 1;
								if (int.TryParse(prm[1], out ii))
								{
                                    if (ii >= 0)
                                    {
                                        _ContDocument.Version = (ContVersion)ii;
                                    }
                                    else
                                    {
                                        _ContDocument.Version = ContVersion.First;
                                    }
								}
                                break;
							case "isprinttitle":
								b = false;
								if (bool.TryParse(prm[1], out b) == true)
								{
									_ContDocument.IsPrintTitle = b;
								}
								break;
							case "isprintsubtitle":
								b = false;
								if (bool.TryParse(prm[1], out b) == true)
								{
									_ContDocument.IsPrintSubTitle = b;
								}
								break;
							case "isprintopus":
								b = false;
								if (bool.TryParse(prm[1], out b) == true)
								{
									_ContDocument.IsPrintOPUS = b;
								}
								break;
							case "isprintcampany":
								b = false;
								if (bool.TryParse(prm[1], out b) == true)
								{
									_ContDocument.IsPrintCampany = b;
								}
								break;
							case "isprintdurationinfo":
								b = false;
								if (bool.TryParse(prm[1], out b) == true)
								{
									_ContDocument.IsPrintDurationInfo = b;
								}
								break;
						}
 
                    }
                }
            }
            //-------------
            sIdx = FindTag(lines, "*data",eIdx);
            if ((sIdx < 0) || (sIdx >= cnt)) return false;
            sIdx++;
            List<KomaInfo> lst = new List<KomaInfo>();
            string dada = "";
            int v= sIdx;
            while (v < cnt)
            {
				sIdx = FindTag(lines, "*KomaInfo", v);
				if (sIdx < 0) break;
				sIdx++;
				eIdx = FindTag(lines, "*KomaInfoEnd", sIdx);
				if (eIdx < 0) eIdx = cnt - 1;
				v = eIdx + 1;
                if (eIdx >=sIdx)
                {
                    dada = "";
                    for (int j = sIdx; j < eIdx; j++) dada += lines[j] + "\n";
                    KomaInfo ci = new KomaInfo();
                    ci.FromText(dada);
                    lst.Add(ci);
                }
            }
            if (lst.Count == 0)
            {
                _ContDocument.Clear();
            }
            else
            {
                _ContDocument.ItemsAssign(lst);
            }
            return true;
        }
        //-------------------------------------------------------------
        /// <summary>
        /// 新たにコンテデータファイルを作成。フォルダも作成
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
		public bool CreateNazDir(string path)
        {
            if (_ContDocument == null) return false;
            if (Directory.Exists(path) == true)
            {
                return false;
            }
            else
            {
                try
                {
                    Directory.CreateDirectory(path);
                }
                catch
                {
                    return false;
                }
            }

            if (_ContDocument.SetNazDir(path) == true)
            {
                return SaveToNazFile(Path.Combine(path, _ContDocument.NazFileName));
            }
            else
            {
                return false;
            }
        }
        //-------------------------------------------------------------
        public bool OpenNazFile(string path)
        {
            if (Directory.Exists(path) == true)
            {
                return OpenNazDir(path);
            }
            else if (File.Exists(path) == false)
            {
                return false;
            }
            if (LoadFromNazFile(path) == true)
            {
                _ContDocument.SetNazDir(Path.GetDirectoryName(path));
                _ContDocument.SetNazFileName(Path.GetFileName(path));
                return true;
            }
            else
            {
                return false;
            }

        }
        //-------------------------------------------------------------
        public bool OpenNazDir(string path)
        {
            if (_ContDocument == null) return false;
            if (Directory.Exists(path) == false)
            {
                return false;
            }
            string[] lst = ListupNazFile(path);
            string p = "";
            switch (lst.Length)
            {
                case 0:
                    return false;
                    //break;
                case 1:
                    p = Path.Combine(path, lst[0]);
                    break;
                default:

                    NazFileSelectDlg dlg = new NazFileSelectDlg(NazFileSelector.Select);
                    dlg.NazFiles = lst;
                    if (dlg.ShowDialog() == DialogResult.OK)
                    {
                        p = dlg.NazFile;
                    }
                    break;
            }
            if (p == "") return false;
            if (LoadFromNazFile(p) == true)
            {
                _ContDocument.SetNazDir(path);
                _ContDocument.SetNazFileName(p);
                return true;
            }
            else
            {
                return false;
            }
        }
        //-------------------------------------------------------------
        public bool SaveNazDir()
        {
            if (_ContDocument == null) return false;
            if (Directory.Exists(_ContDocument.NazDir) == false)
            {
                return false;
            }
            string p = Path.Combine(_ContDocument.NazDir, _ContDocument.NazFileName);

            return SaveToNazFile(p);
        }
    }
}
