﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class ContDocument : Component
    {
        /// <summary>
        /// 全ページに印刷される画像の名前。未実装
        /// </summary>
        public KomaPict PublicPict0 = new KomaPict();
        public KomaPict PublicPict1 = new KomaPict();
        public KomaPict PublicPict2 = new KomaPict();

        /// <summary>
        /// CopyされたPictureName
        /// </summary>
        private string _PictureLink = "";

        /// <summary>
        /// インポート設定
        /// </summary>
        private ImportResize _importResize = ImportResize.none;

        //----------------------------------------------------------------------------------
        public void DeletePictureLink()
        {
            int idx = _SelectedIndex;
            if (idx < 0) return;
            if (_Items[idx].Pic.name != string.Empty)
            {
                _Items[idx].Pic.Clear();
                _changeFlag = true;
                OnkomaChanged(new EventArgs());
            }
        }
        //----------------------------------------------------------------------------------
        public void CopyPictureLink()
        {
            int idx = _SelectedIndex;
            if (idx < 0) return;
            if (_Items[idx].PictName != string.Empty)
            {
                _PictureLink = _Items[idx].PictName;
            }
        }
        //----------------------------------------------------------------------------------
        public bool IsPictureLink
        {
            get
            {
                string p = Path.Combine(_ImageDir, _PictureLink);
                if (File.Exists(p) == false)
                {
                    _PictureLink = "";
                }
                return (_PictureLink != string.Empty);
            }
        }
        //----------------------------------------------------------------------------------
        public void PeastPictureLink()
        {
            int idx = _SelectedIndex;
            if (idx < 0) return;
            string p = Path.Combine(_ImageDir, _PictureLink);
            if (File.Exists(p) == false)
            {
                _PictureLink = "";
                return;
            }
            if (_Items[idx].PictName != _PictureLink)
            {
                _Items[idx].Pic.Clear();
                _Items[idx].Pic.name = _PictureLink;
                _changeFlag = true;
                OnkomaChanged(new EventArgs());
            }
        }
        //----------------------------------------------------------------------------------
        public KomaPict Pic
        {
            get
            {
                int idx = _SelectedIndex;
                if ((idx < 0) || (idx >= _Items.Count))
                {
                    return null;
                }
                else
                {
                    return _Items[idx].Pic;
                }
            }
            set
            {
                int idx = _SelectedIndex;
                if ((idx < 0) || (idx >= _Items.Count))
                {
                    //
                }
                else
                {
                    _Items[idx].Pic = value;
                }
            }
        }
        public KomaPict PicSub
        {
            get
            {
                int idx = _SelectedIndex;
                if ((idx < 0) || (idx >= _Items.Count))
                {
                    return null;
                }
                else
                {
                    return _Items[idx].PicSub;
                }
            }
            set
            {
                int idx = _SelectedIndex;
                if ((idx < 0) || (idx >= _Items.Count))
                {
                    //
                }
                else
                {
                    _Items[idx].PicSub = value;
                }
            }
        }
        //----------------------------------------------------------------------------------
        public ImportResize ImportResize
        {
            get { return _importResize; }
            set { _importResize = value; }
        }
        //----------------------------------------------------------------------------------
        public void ShowImportResize()
        {
            ImportSettingDlg dlg = new ImportSettingDlg();
            dlg.ImportResize = _importResize;
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                _importResize = dlg.ImportResize;
            }
        }
        //----------------------------------------------------------------------------------
        public bool DeletePictureFile()
        {
            return DeletePictureFile(_SelectedIndex);
        }
        //----------------------------------------------------------------------------------
        public bool DeletePictureFile(int idx)
        {
            if ((idx < 0) || (idx >= _Items.Count)) return false;

            return DeletePictureFile(_Items[idx].PictName);
        }

        //----------------------------------------------------------------------------------
        public bool DeletePictureFile(string name)
        {
            if (_Locked == true) return false;

            List<int> ids = new List<int>();
            //使われているPictureを探す
            for (int i = 0; i < _Items.Count; i++)
            {
                if (_Items[i].PictName == name)
                {
                    ids.Add(i);
                }
            }
            bool b = true;
            if (ids.Count == 1)
            {
                if (MessageBox.Show("削除しますか？", "確認", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    b = true;
                }
                else
                {
                    b = false;
                }
            }
            if (ids.Count > 1)
            {
                if (MessageBox.Show("他のコマでも使用されています。削除しますか？", "確認", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    b = true;
                }
                else
                {
                    b = false;
                }
            }
            if (b == false)
            {
                return false;
            }

            //印刷用は他に移す。
            try
            {
                string p = Path.Combine(_ImageDir, name);
                string n = Path.GetDirectoryName(_ImageDir);
                n = Path.Combine(n, def.TrushFolderName);
                if (Directory.Exists(n) == false)
                {
                    Directory.CreateDirectory(n);
                }

                if (File.Exists(p) == true)
                {
                    string np = Path.Combine(n, name);
                    while (File.Exists(np) == true)
                    {
                        np += "_";
                    }
                    File.Move(p, np);
                }
                //サムネイルを消す。
                p = Path.Combine(_ThumbDir, name);
                if (File.Exists(p) == true)
                {
                    File.Delete(p);
                }
            }
            catch
            {
                MessageBox.Show("Delete Error!");
                return false;
            }
            if (ids.Count > 0)
            {
                for (int i = 0; i < ids.Count; i++)
                {
                    _Items[ids[i]].PictName = string.Empty;
                }
            }
            return true;

        }
        //-------------------------------------------------------------------------------
        /// <summary>
        /// サムネイル画像の作成
        /// </summary>
        /// <param name="bmp"></param>
        /// <returns></returns>
        public Bitmap MakeThums(Bitmap bmp)
        {
            if (bmp == null) return null;
            //サムネイルの作成
            int w = (int)Math.Round(def.PreviewScale * bmp.Width * def.DisplayDpi / bmp.HorizontalResolution);
            int h = (int)Math.Round(def.PreviewScale * bmp.Height * def.DisplayDpi / bmp.HorizontalResolution);

            if (w < 4) w = 4;
            if (h < 4) h = 4;

            Bitmap buf = new Bitmap(w, h, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
            buf.SetResolution(def.DisplayDpi, def.DisplayDpi);
            Graphics g = Graphics.FromImage(buf);
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            g.DrawImage(bmp, new Rectangle(0, 0, w, h));
            g.Dispose();

            return buf;
        }
        //-------------------------------------------------------------------------------
        /// <summary>
        /// インポートされたファイル名の一覧を作成
        /// </summary>
        /// <returns></returns>
        public string[] GetImportFiles()
        {
            if (Directory.Exists(_ImageDir) == false) return new string[0];
            string[] lst = Directory.GetFiles(_ImageDir, "*" + def.PicExt);
            //余計なパスを削除
            if (lst.Length > 0)
            {
                for (int i = 0; i < lst.Length; i++)
                {
                    lst[i] = Path.GetFileName(lst[i]);
                }
            }
            return lst;
        }
        //-------------------------------------------------------------------------------
        /// <summary>
        /// サムネイル画像を作成
        /// </summary>
        /// <param name="name">インポートされているファイルの名まえ。フルパスじゃない</param>
        /// <returns></returns>
        public ImportErr MakeThumbFile(string name)
        {
            //印刷画像の保存パス
            string fn = Path.Combine(_ImageDir, name);
            if (File.Exists(fn) == false) return ImportErr.NoneFile;

            Bitmap bmp = new Bitmap(fn);
            try
            {
                Bitmap thumb = MakeThums(bmp);
                try
                {
                    string p = Path.Combine(_ThumbDir, name);
                    thumb.Save(p, System.Drawing.Imaging.ImageFormat.Png);
                }
                catch
                {
                    return ImportErr.ThumbErr;
                }
                finally
                {
                    thumb.Dispose();
                }
            }
            catch
            {
                return ImportErr.LoadErr;
            }
            finally
            {
                bmp.Dispose();
            }

            return ImportErr.NoErr;
        }
        public void MakeThumbAll()
        {
            //まずサムネイルを全部消す。
            string[] thumbs = Directory.GetFiles(_ThumbDir, "*" + def.PicExt);
            if (thumbs.Length > 0)
            {
                try
                {
                    for (int i = 0; i < thumbs.Length; i++)
                    {
                        File.Delete(thumbs[i]);
                    }
                }
                catch
                {
                    return;
                }
            }
            string[] images = Directory.GetFiles(_ImageDir);
            if (images.Length <= 0) return;

            for (int i = 0; i < images.Length; i++)
            {
                string e = Path.GetExtension(images[i]).ToLower();
                if ((e == ".png") || (e == ".bmp") || (e == ".tif") || (e == ".jpg") || (e == ".jpeg"))
                {
                    MakeThumbFile(Path.GetFileName(images[i]));
                }

            }


        }
        //-------------------------------------------------------------------------------
        private Bitmap ImportSUb(string path)
        {
            if (File.Exists(path) == false) return null;

            //画像を読み込む
            Bitmap bmp = new Bitmap(path);
            try
            {
                int nW = 0;
                int nH = 0;
                switch (_importResize)
                {
                    case ImportResize.sz1024x576:
                        //大きさ(mm)を獲得
                        nW = (bmp.Width);
                        nH = (bmp.Height);
                        break;
                    case ImportResize.sz1280x720:
                        //大きさ(mm)を獲得
                        nW = (bmp.Width * 1024 / 1280);
                        nH = (bmp.Height * 1024 / 1280);
                        break;
                    case ImportResize.sz1440x810:
                        nW = (bmp.Width * 1024 / 1440);
                        nH = (bmp.Height * 1024 / 1440);
                        break;
                    case ImportResize.sz1920x1080:
                        nW = (bmp.Width * 1024 / 1920);
                        nH = (bmp.Height * 1024 / 1920);
                        break;
                    case ImportResize.none:
                    default:
                        //解像度を確認
                        float dd = (float)Math.Round(bmp.HorizontalResolution);
                        //96dpi以下のものは強制的に変更
                        if (dd < def.DisplayDpi) { dd = def.dpi; }
                        //大きさ(mm)を獲得
                        nW = (int)Math.Round(bmp.Width * def.dpi / dd);
                        nH = (int)Math.Round(bmp.Height * def.dpi / dd);
                        break;
                }
                //印刷解像度に変更
                Bitmap bmp2 = new Bitmap(nW, nH, bmp.PixelFormat);
                try
                {
                    bmp2.SetResolution(def.dpi, def.dpi);
                    Graphics g = Graphics.FromImage(bmp2);
                    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    g.DrawImage(bmp, new Rectangle(0, 0, nW, nH));
                    return bmp2;
                }
                catch
                {
                    return null;
                }

            }
            catch
            {
                return null;
            }
            finally
            {
                bmp.Dispose();
                bmp = null;
            }
        }
        public string ImportPicture(string path)
        {
            if (File.Exists(path) == false) return "";
            //印刷画像の名まえ
            string name = Path.GetFileNameWithoutExtension(path) + def.PicExt;

            //印刷画像の保存パス
            string fn = Path.Combine(_ImageDir, name);
            if (File.Exists(fn) == true)
            {
                MessageBox.Show("同じ名まえのファイルを既にインポートしています。");
                return name;
            }


            //画像を読み込む
            Bitmap bmp = ImportSUb(path);
            if (bmp == null)
            {
                return "";
            }
            //保存（インポート）
            try
            {
                bmp.Save(fn, System.Drawing.Imaging.ImageFormat.Png);

                //サムネイルの作成
                Bitmap thumb = MakeThums(bmp);
                try
                {
                    fn = Path.Combine(_ThumbDir, name);
                    thumb.Save(fn, System.Drawing.Imaging.ImageFormat.Png);
                }
                catch
                {
                    MessageBox.Show("サムネイル作成に失敗しました。");
                    return name;
                }
                finally
                {
                    thumb.Dispose();
                }
            }
            finally
            {
                bmp.Dispose();
            }

            return name;
        }
        //-------------------------------------------------------------------------------
        /// <summary>
        /// 画像をインポート
        /// </summary>
        /// <param name="path">画像ファイルのパス</param>
        /// <param name="idx">インポートするコマのインデックス</param>
        /// <returns>成功したらtrue</returns>
        public ImportErr ImportPicture(string path, int idx)
        {
            if ((idx < 0) || (idx >= _Items.Count)) return ImportErr.IndexErr;
            if (_Items[idx].Empty == true) return ImportErr.EmptyKoma;

            if (File.Exists(path) == false) return ImportErr.NoneFile;

            //印刷画像の名まえ
            string name = Path.GetFileNameWithoutExtension(path) + def.PicExt;

            //印刷画像の保存パス
            string fn = Path.Combine(_ImageDir, name);
            if (File.Exists(fn) == true) return ImportErr.SameFile;


            //画像を読み込む
            Bitmap bmp = ImportSUb(path);
            if (bmp == null)
            {
                return ImportErr.LoadErr;
            }
            //保存（インポート）
            try
            {
                bmp.Save(fn, System.Drawing.Imaging.ImageFormat.Png);
                _Items[idx].Pic.Clear();
                _Items[idx].Pic.name = name;

                //サムネイルの作成
                Bitmap thumb = MakeThums(bmp);
                try
                {
                    fn = Path.Combine(_ThumbDir, name);
                    thumb.Save(fn, System.Drawing.Imaging.ImageFormat.Png);
                }
                catch
                {
                    return ImportErr.ThumbErr;
                }
                finally
                {
                    thumb.Dispose();
                }
            }
            finally
            {
                bmp.Dispose();
            }

            return ImportErr.NoErr;
        }
        //----------------------------------------------------------------------------------
        public Bitmap LoadThumbFile(int idx)
        {
            if ((idx < 0) || (idx >= _Items.Count)) return null;
            if ((_Items[idx].Empty == true) || (_Items[idx].PictName == string.Empty)) return null;


            string lp = Path.Combine(_ThumbDir, _Items[idx].PictName);
            //サムネイルがない
            if (File.Exists(lp) == false)
            {
                //サムネイルを作る
                if (MakeThumbFile(_Items[idx].PictName) != ImportErr.NoErr)
                {
                    return null;
                }

            }
            try
            {
                Bitmap bmp = new Bitmap(lp);
                Bitmap buf = new Bitmap(bmp.Width, bmp.Height, bmp.PixelFormat);
                Graphics.FromImage(buf).DrawImage(bmp, 0, 0);
                bmp.Dispose();
                return buf;
            }
            catch
            {
                return null;
            }
        }
        //----------------------------------------------------------------------------------
        public Bitmap LoadPictureFile(int idx)
        {
            if ((idx < 0) || (idx >= _Items.Count)) return null;
            if ((_Items[idx].Empty == true) || (_Items[idx].PictName == string.Empty)) return null;


            string lp = Path.Combine(_ImageDir, _Items[idx].PictName);
            if (File.Exists(lp) == false)
            {
                return null;
            }
            try
            {
                Bitmap bmp = new Bitmap(lp);
                Bitmap buf = new Bitmap(bmp.Width, bmp.Height, bmp.PixelFormat);
                buf.SetResolution(bmp.HorizontalResolution, bmp.VerticalResolution);

                Graphics.FromImage(buf).DrawImage(bmp, new Rectangle(0, 0, buf.Width, buf.Height));
                bmp.Dispose();
                return buf;
            }
            catch
            {
                return null;
            }
        }
        //----------------------------------------------------------------------------------
        public Bitmap LoadPictureFile(string name)
        {
            string lp = Path.Combine(_ImageDir, name);
            if (File.Exists(lp) == false)
            {
                return null;
            }
            try
            {
                Bitmap bmp = new Bitmap(lp);
                Bitmap buf = new Bitmap(bmp.Width, bmp.Height, bmp.PixelFormat);
                buf.SetResolution(bmp.HorizontalResolution, bmp.VerticalResolution);

                Graphics.FromImage(buf).DrawImage(bmp, new Rectangle(0, 0, buf.Width, buf.Height));
                bmp.Dispose();
                return buf;
            }
            catch
            {
                return null;
            }
        }
        //----------------------------------------------------------------
        public string ImportPictureDlg()
        {
            string ret = "";
            if (_Locked == true) return ret;
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "Import Picture";
            dlg.Filter = "png|*.png|jpeg|*.jpg|all|*.*";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                ret = ImportPicture(dlg.FileName);
            }
            return ret;
        }
        //----------------------------------------------------------------

    }
}
