﻿namespace ContEditorNazoh
{
    partial class ExtInstDlg
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInst = new System.Windows.Forms.Button();
            this.btnUnInst = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnInst
            // 
            this.btnInst.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnInst.Location = new System.Drawing.Point(28, 105);
            this.btnInst.Name = "btnInst";
            this.btnInst.Size = new System.Drawing.Size(122, 46);
            this.btnInst.TabIndex = 2;
            this.btnInst.Text = "登録する";
            this.btnInst.UseVisualStyleBackColor = true;
            this.btnInst.Click += new System.EventHandler(this.btnInst_Click);
            // 
            // btnUnInst
            // 
            this.btnUnInst.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnUnInst.Location = new System.Drawing.Point(174, 106);
            this.btnUnInst.Name = "btnUnInst";
            this.btnUnInst.Size = new System.Drawing.Size(122, 46);
            this.btnUnInst.TabIndex = 3;
            this.btnUnInst.Text = "登録解除";
            this.btnUnInst.UseVisualStyleBackColor = true;
            this.btnUnInst.Click += new System.EventHandler(this.btnUnInst_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(5, 16);
            this.textBox1.Margin = new System.Windows.Forms.Padding(10);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(419, 76);
            this.textBox1.TabIndex = 4;
            this.textBox1.Text = "レジストリに、Nazoh!が作成するファイルの拡張子の登録を行います。\r\n\r\n拡張子の登録を行うと、ファイルに（ちょっと悪趣味な）オリジナルアイコンが表示されます" +
                "。";
            // 
            // btnClose
            // 
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(353, 105);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(71, 46);
            this.btnClose.TabIndex = 5;
            this.btnClose.Text = "閉じる";
            this.btnClose.UseVisualStyleBackColor = true;
            // 
            // ExtInstDlg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(443, 164);
            this.ControlBox = false;
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnUnInst);
            this.Controls.Add(this.btnInst);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ExtInstDlg";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "拡張子の登録";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInst;
        private System.Windows.Forms.Button btnUnInst;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnClose;
    }
}