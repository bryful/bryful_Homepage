﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Imaging;

namespace ContEditorNazoh
{
   
    public class ContDraw
    {
        private ContDocument _ContDocument;
        
        private int _CurrentPage = 0;
        private int _CurrentIndex = 0;

        private float _PreviewScale = def.PreviewScale;
        
        //サイズ
        private float _dpi = def.dpi;
        private float _PaperWidth = def.PaperWidth;
        private float _PaperHeight = def.PaperHeight;
        private int _PaperWidthP = 0;
        private int _PaperHeightP = 0;
        
        private float _offsetX = 0;
        private float _offsetY = 0;

        private float _KomaWidth = def.KomaWidth;
        private float _KomaHeight = def.KomaHeight;
        private int _KomaWidthP = def.KomaWidthP;
        private int _KomaHeightP = def.KomaHeightP;

		private float _TitlleHeight = def.TitleHeight;
        private float _CampanyHeight = def.CampanyHeight;
        private float _NumberWidth = def.NumberWidth;
        private float _MemoWidth = def.MemoWidth;
        private float _WordsWidth = def.WordsWidth;
        private float _SecWidth = def.SecWidth;
        private float _CaptionHeigh = def.CaptionHeigh;
		private float _FooterHeigh = def.FooterHeigh;


        private float _PageNumberLine = def.PageNumberLine;
        private float _PageNumberLeft = def.PageNumberLeft;
        private float _PageNumberWidth = def.PageNumberWidth;

        private float _MarginH = def.MarginH;
        private float _MarginMemo = def.MarginMemo;
        private float _MarginNumber = def.MarginNumber;
        private float _MarginSec = def.MarginSec;

        private float _PrintWidth = def.PrintWidth;
        private float _PrintHeight = def.PrintHeight;
        
        private int _PrintWidthP = 0;
        private int _HeightP = 0;

        private float _PenSizeS = def.PenSizeS;
        private float _PenSizeM = def.PenSizeM;
        private float _PenSizeL = def.PenSizeL;

        private float _DurationLeft = 0;
        private float _MemoLeft = 0;
        private float _WordsLeft = 0;
        private float _PicLeft = 0;
        private float _NumberLeft = 0;

		private float _TitleTop = 0;
		private float _CampanyTop = 0;
		private float _CaptionTop = 0;
		private float _KomaTop = 0;
		private float _FooterTop = 0;
		private float _FooterBottom = 0;



        private float _FontSizeText = def.FontSizeText;
        private float _FontSizeCaption = def.FontSizeCaption;
        private float _FontSizeNumber = def.FontSizeNumber;
        private float _FontSizeSec = def.FontSizeSec;
        private float _FontSizeCampany = def.FontSizeCampany;
		private float _FontSizeTitle = def.FontSizeTitle;

        private FontFamily _FontFamily = new FontFamily("MS UI Gothic");
        private KomaPict[] PreviewPics = new KomaPict[def.KomaCount];
        
        

        public event EventHandler PageChangeChanged;
        //---------------------------------------------------------------------
        public ContDraw(ContDocument ci)
        {
            _ContDocument = ci;

            for (int i = 0; i < def.KomaCount; i++)
            {
                PreviewPics[i] = new KomaPict();
            }

            InitScreen(def.PreviewScale, def.DisplayDpi);
        }
        //-----------------------------------------------------------------------------
        public ContDraw(ContDocument ci, bool IsPrint)
        {
            _ContDocument = ci;
            if (IsPrint == true)
            {
                InitScreen(1f, def.dpi);
            }
            else
            {
                InitScreen(def.PreviewScale, def.DisplayDpi);
            }
        }
        //-----------------------------------------------------------------------------
        public ContDocument ContDocument
        {
            get { return _ContDocument; }
            set 
            { 
                _ContDocument = value;
            }
        }
        //----------------------------------------------------------------
        protected virtual void OnPageChangeChangedd(EventArgs e)
        {
            if (PageChangeChanged != null)
            {
                PageChangeChanged(this, e);
            }
        }
        //---------------------------------------------------------------------
        //裏画面の初期化
        public void InitScreen(float sc,float dpi)
        {
            _PreviewScale = sc;
            _dpi = dpi;
            _PaperWidth = def.PaperWidth * _PreviewScale;
            _PaperHeight = def.PaperHeight * _PreviewScale;

            _PaperWidthP = (int)Math.Round(_PaperWidth * dpi / 25.4f);
            _PaperHeightP = (int)Math.Round(_PaperHeight * dpi / 25.4f);

            _KomaWidth = def.KomaWidth * _PreviewScale;
            _KomaHeight = def.KomaHeight * _PreviewScale;

            _KomaWidthP = (int)Math.Round(_KomaWidth * dpi / 25.4f);
            _KomaHeightP = (int)Math.Round(_KomaHeight * dpi / 25.4f);

			_TitlleHeight = def.TitleHeight * _PreviewScale; 
            _CampanyHeight = def.CampanyHeight * _PreviewScale;
            _NumberWidth = def.NumberWidth * _PreviewScale;
            _MemoWidth = def.MemoWidth * _PreviewScale;
            _WordsWidth = def.WordsWidth * _PreviewScale;
            _SecWidth = def.SecWidth * _PreviewScale;
            _CaptionHeigh = def.CaptionHeigh * _PreviewScale;
			_FooterHeigh = def.FooterHeigh * _PreviewScale;

            _MarginH = def.MarginH * _PreviewScale;
            _MarginMemo = def.MarginMemo * _PreviewScale;
            _MarginNumber = def.MarginNumber * _PreviewScale;
            _MarginSec = def.MarginSec * _PreviewScale;

            _PageNumberLine = def.PageNumberLine * _PreviewScale;

            _PageNumberLeft = def.PageNumberLeft * _PreviewScale;
            _PageNumberWidth = def.PageNumberWidth * _PreviewScale;

            _PrintWidth = def.PrintWidth * _PreviewScale;
			_PrintWidth = _NumberWidth + _KomaWidth + _MemoWidth + _WordsWidth + _SecWidth;
			_PrintHeight = _TitlleHeight + _CampanyHeight + _CaptionHeigh + (_KomaHeight * def.KomaCount) + _FooterHeigh;

            _PrintWidthP = (int)Math.Round(_PrintWidth * dpi / 25.4f);
            _HeightP = (int)Math.Round(_PrintHeight * dpi / 25.4f);

            _offsetX = (_PaperWidth - _PrintWidth)/2;
            _offsetY = (_PaperHeight - (_PrintHeight+_CampanyHeight) ) / 2;

            _PenSizeS = def.PenSizeS * _PreviewScale;
            _PenSizeM = def.PenSizeM * _PreviewScale;
            _PenSizeL = def.PenSizeL * _PreviewScale;

            _FontSizeText = def.FontSizeText * _PreviewScale;
            _FontSizeCaption = def.FontSizeCaption * _PreviewScale;
            _FontSizeNumber = def.FontSizeNumber * _PreviewScale;
            _FontSizeSec = def.FontSizeSec * _PreviewScale;
			_FontSizeTitle = def.FontSizeTitle * _PreviewScale;
			_FontSizeCampany = def.FontSizeCampany * _PreviewScale;

            //_Font = new Font(_FontFamily, _FontSizeText);

            _NumberLeft = 0;
            _PicLeft = _NumberLeft + _NumberWidth;
            _MemoLeft = _PicLeft + _KomaWidth;
            _WordsLeft = _MemoLeft + _MemoWidth;
            _DurationLeft = _WordsLeft + _WordsWidth;


			_TitleTop = 0;
			_CampanyTop = _TitleTop + _TitlleHeight;
			_CaptionTop = _CampanyTop + _CampanyHeight;
			_KomaTop = _CaptionTop + _CaptionHeigh;
			_FooterTop = _KomaTop + _KomaHeight * def.KomaCount;
			_FooterBottom = _FooterTop + _FooterHeigh;

            ClearPreviewPics();
            
        }
        //---------------------------------------------------------------------
        public void ClearPreviewPics()
        {
            for (int i = 0; i < def.KomaCount; i++)
            {
                if (PreviewPics[i] == null)
                {
                    PreviewPics[i] = new KomaPict();
                }
                else
                {
                    PreviewPics[i].Clear();
                }
            }
        }
        //****************************************************************************
        /*
         * プロパティ
         */ 
        //****************************************************************************
        public void SetPaperSize(System.Drawing.Printing.PaperSize ps)
        {
            float sc = 1f;
            float w = (ps.Width * 25.4f / 100f);
            float h = (ps.Height * 25.4f / 100f);

            if (ps.Kind == System.Drawing.Printing.PaperKind.A4)
            {
                sc = 1;
            }
            else
            {
                sc = w / def.PaperWidth;
            }

            InitScreen(sc, def.dpi);
            _PaperWidth = w;
            _PaperHeight = h;
            _offsetX = (_PaperWidth - _PrintWidth) / 2;
            _offsetY = (_PaperHeight - _PrintHeight) / 2;

        }
        //---------------------------------------------------------------------
        public float PaperWidth
        {
            get { return _PaperWidth; }
            set
            {
                _PaperWidth = value;
                _offsetX = (_PaperWidth - _PrintWidth) / 2;
            }
        }
        //------------------------------------------------------
        public float PaperHeight
        {
            get { return _PaperHeight; }
            set
            {
                _PaperHeight = value;
                _offsetY = (_PaperHeight - _PrintHeight) / 2;
            }
        }
        //---------------------------------------------------------------------
        public int PaperWidthP
        {
            get 
            {
                _PaperWidthP = (int)Math.Round(_PaperWidth * _dpi / 25.4f);
                return _PaperWidthP; 
            }
        }
        //------------------------------------------------------
        public int PaperHeightP
        {
            get 
            {
                _PaperWidthP = (int)Math.Round(_PaperWidth * _dpi / 25.4f);
                return _PaperHeightP; 
            }
        }
        //---------------------------------------------------------------------
        public float PrintWidth
        {
            get { return _PrintWidth; }
        }
        //------------------------------------------------------
        public float PrintHeight
        {
            get { return _PrintHeight; }
        }
        //---------------------------------------------------------------------
        public int PrintWidthP
        {
            get { return  (int)Math.Round(_PrintWidthP * _dpi / 25.4f); }
        }
        //------------------------------------------------------
        public int PrintHeightP
        {
            get { return (int)Math.Round(_PrintHeight * _dpi / 25.4f); }
        }
        public float OffsetX
        {
            get { return _offsetX; }
        }
        public float OffsetY
        {
            get { return _offsetY; }
        }
        //********************************************************************
        /*
         * 描画
         */ 
        //********************************************************************
        //------------------------------------------------------
        public void DrawPreviewPage(Graphics g)
        {
            if (_ContDocument == null) return;
            DrawThumPictures(g);
			//DrawTexts(g);
			
			DrawPageNumber(g);
			DrawCampanyAndTitle(g);

			Font ff = new Font(_FontFamily, _FontSizeNumber, FontStyle.Bold);
			for (int i = 0; i < def.KomaCount; i++)
			{
				DrawNumber(g, i, ff);
			}
			ff.Dispose();
			for (int i = 0; i < def.KomaCount; i++)
			{
				DrawSec(g, i);
			}

			for (int i = 0; i < def.KomaCount; i++)
			{
				DrawText(g, i);
			}
			DrawFrame(g);

		
		}
        //------------------------------------------------------
        public void DrawPrintPage(Graphics g)
        {
            if (_ContDocument == null) return;
            DrawPictures(g);
			DrawTexts(g);
            DrawFrame(g);
        }
        //--------------------------------------------------------------------------
        public void DrawFrame(Graphics g)
        {
            StringFormat fmt = new StringFormat();
            fmt.Alignment = StringAlignment.Center;
            fmt.LineAlignment = StringAlignment.Center;
            //g.PageUnit = GraphicsUnit.Millimeter;

            SolidBrush sb = new SolidBrush(Color.Black);
            Pen p = new Pen(Color.Black);

            try
            {
                //水平線を描く
                p.Width = _PenSizeM;
                float x0 = _offsetX;
                float x1 = _offsetX + _PrintWidth;
                float y0 = _offsetY + _CaptionTop;
                float y1 = 0;

                g.DrawRectangle(p, x0, y0, _PrintWidth, _KomaHeight * def.KomaCount + _CaptionHeigh); 
                p.Width = _PenSizeS;
                y0 += _CaptionHeigh;
                for (int i = 0; i < 5; i++)
                {
                    g.DrawLine(p, x0, y0, x1, y0);
                    y0 += _KomaHeight;
                }

                p.Width = _PenSizeM;
                //垂直線を描く
                x0 = _offsetX + _PicLeft;
                y0 = _offsetY + _CaptionTop;
				y1 = _offsetY + _PrintHeight - _FooterHeigh;

                p.Width = _PenSizeM;
                g.DrawLine(p, x0, y0, x0, y1);
                
                x0 += _KomaWidth;
                g.DrawLine(p, x0, y0, x0, y1);

                p.Width = _PenSizeS;
                x0 += _MemoWidth;
                p.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
                g.DrawLine(p, x0, y0, x0, y1);
                p.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;

                p.Width = _PenSizeM;
                x0 += _WordsWidth;
                g.DrawLine(p, x0, y0, x0, y1);
                
                //キャプション文字を描く
                x0 = _offsetX;
                y0 = _offsetY + 1 + _CaptionTop;
                //
                Font ff = new Font(_FontFamily, _FontSizeCaption,FontStyle.Bold);
                try
                {
                    //カット
                    RectangleF rct = new RectangleF(x0, y0, _NumberWidth, _CaptionHeigh - 1);
                    g.DrawString(_ContDocument.CaptionCut, ff, sb, rct, fmt);
                    //
                    x0 += _NumberWidth;
                    rct = new RectangleF(x0, y0, _KomaWidth, _CaptionHeigh - 1);
                    g.DrawString(_ContDocument.CaptionPicture, ff, sb, rct, fmt);
                    x0 += _KomaWidth;
                    rct = new RectangleF(x0, y0, _MemoWidth, _CaptionHeigh - 1);
                    g.DrawString(_ContDocument.CaptionMemo, ff, sb, rct, fmt);
                    x0 += _MemoWidth;
                    rct = new RectangleF(x0, y0, _WordsWidth, _CaptionHeigh - 1);
                    g.DrawString(_ContDocument.CaptionWords, ff, sb, rct, fmt);
                    x0 += _WordsWidth;
                    rct = new RectangleF(x0, y0, _SecWidth, _CaptionHeigh - 1);
                    g.DrawString(_ContDocument.CaptionSec, ff, sb, rct, fmt);
                }
                finally
                {
                    ff.Dispose();
                }
              }
            finally
            {
                sb.Dispose();
                p.Dispose();
            }

        }
        //--------------------------------------------------------------------------
        private void DrawTexts(Graphics g)
        {
            if (_ContDocument == null) return;
            g.PageUnit = GraphicsUnit.Millimeter;

			DrawPageNumber(g);
			DrawCampanyAndTitle(g);
				
            for (int i = 0; i < def.KomaCount; i++)
            {
                DrawText(g, i);
            }
			Font ff = new Font(_FontFamily, _FontSizeNumber, FontStyle.Bold);
            for (int i = 0; i < def.KomaCount; i++)
            {
                DrawNumber(g, i, ff);
            }
			ff.Dispose();

            for (int i = 0; i < def.KomaCount; i++)
            {
                DrawSec(g, i);
            }
        }
        //-------------------------------------------------------------------------
        private void DrawPageNumber(Graphics g)
        {
            
            Pen p = new Pen(Color.Black);
            
            SolidBrush sb = new SolidBrush(Color.Black);
            try
            {
                float x0 = _offsetX + _PageNumberLeft;
                float x1 = x0 + _PageNumberWidth;
                float y0 = _offsetY + _CampanyTop;
				float y1 = _offsetY + _CaptionTop - _PageNumberLine;
                p.Width = _PenSizeS;
                g.DrawLine(p, x0, y1, x1, y1);
                RectangleF rct = new RectangleF(x0, y0, _PageNumberWidth, _CampanyHeight);

                StringFormat fmt = new StringFormat();
                fmt.Alignment = StringAlignment.Center;
                fmt.LineAlignment = StringAlignment.Far;
                int pn = _CurrentPage + _ContDocument.PageNumberStart;

                string s = "";
                if (pn <= 0) { s = "000"; }
                else if (pn < 10) { s = "00" + pn.ToString(); }
                else if (pn < 100) { s = "0" + pn.ToString(); }
                else { s = pn.ToString(); }

                Font ff = new Font(_FontFamily, _FontSizeCampany,FontStyle.Bold);
                g.DrawString("No."+s, ff, sb, rct, fmt);
                ff.Dispose();
                
            }
            finally
            {
                p.Dispose();
            }
        }
        //-------------------------------------------------------------------------
        /// <summary>
        /// メモ・セリフの印刷
        /// </summary>
        /// <param name="g"></param>
        /// <param name="idx"></param>
        /// <param name="fnt"></param>
        /// <param name="fmt"></param>
        /// <param name="sb"></param>
        private void DrawText(Graphics g, int idx)
        {
 
			KomaInfo ki = _ContDocument.GetItem(_CurrentIndex + idx);
			if (ki.Empty == true) return;
			
			SolidBrush sb = new SolidBrush(Color.Black);
			Font fnt = new Font(_FontFamily, _FontSizeText);
			try
			{

				StringFormat fmt = new StringFormat();
				fmt.Alignment = StringAlignment.Near;
				fmt.LineAlignment = StringAlignment.Near;
				g.PageUnit = GraphicsUnit.Millimeter;

				float x0 = _offsetX + _MemoLeft;
				float y0 = _offsetY + _KomaTop + (_KomaHeight * idx);
				if (ki.Memo != string.Empty)
				{
					fmt.LineAlignment = StringAlignment.Near;
					RectangleF rct = new RectangleF(x0 + _MarginMemo, y0 + _MarginH, _MemoWidth - _MarginMemo * 2, _KomaHeight - _MarginH * 2);
					g.DrawString(ki.MemoStr, fnt, sb, rct, fmt);
				}
				if (ki.MemoU != string.Empty)
				{
					fmt.LineAlignment = StringAlignment.Far;
					RectangleF rct = new RectangleF(x0 + _MarginMemo, y0 + _MarginH, _MemoWidth - _MarginMemo * 2, _KomaHeight - _MarginH * 2);
					g.DrawString(ki.MemoUStr, fnt, sb, rct, fmt);
				}
				x0 = _offsetX + _WordsLeft;
				if (ki.Words != string.Empty)
				{
					fmt.LineAlignment = StringAlignment.Near;
					RectangleF rct2 = new RectangleF(x0 + _MarginMemo, y0 + _MarginH, _WordsWidth - _MarginMemo * 2, _KomaHeight - _MarginH * 2);
					g.DrawString(ki.WordsStr, fnt, sb, rct2, fmt);
				}
				if (ki.WordsU != string.Empty)
				{
					fmt.LineAlignment = StringAlignment.Far;
					RectangleF rct = new RectangleF(x0 + _MarginMemo, y0 + _MarginH, _WordsWidth - _MarginMemo * 2, _KomaHeight - _MarginH * 2);
					g.DrawString(ki.WordsUStr, fnt, sb, rct, fmt);
				}
			}
			finally
			{
				sb.Dispose();
				fnt.Dispose();
			}
		}
        //-------------------------------------------------------------------------
        private void DrawCampanyAndTitle(Graphics g)
        {
            SolidBrush sb = new SolidBrush(Color.Black);
            Pen p = new Pen(Color.Black);
            try
            {
				RectangleF rct;
				Font ff;
				StringFormat fmt = new StringFormat();

				//Campany
				string cn = _ContDocument.CampanyName;
				if ((_ContDocument.IsPrintCampany==true)&&(cn != ""))
				{
					float x0 = _offsetX + _PageNumberLeft + _PageNumberWidth;
                    float y0 = _offsetY + _CampanyTop;
					
					rct = new RectangleF(x0, y0, _PrintWidth - (_PageNumberLeft + _PageNumberWidth), _CampanyHeight);
					
					ff = new Font(_FontFamily, _FontSizeCampany, FontStyle.Bold);
					try
					{
						fmt.LineAlignment = StringAlignment.Far;
						fmt.Alignment = StringAlignment.Far;
                        g.DrawString(cn, ff, sb, rct, fmt);
					}
					finally
					{
						ff.Dispose();
					}
				}

				//
				string s = "";
				if (_ContDocument.IsPrintTitle)
				{
					s += _ContDocument.Title;
				}
				if (_ContDocument.IsPrintOPUS)
				{
					if (s != "") s += " ";
					s += _ContDocument.OPUS;
				}
				if (_ContDocument.IsPrintSubTitle)
				{
					if (s != "") s += " ";
					s += _ContDocument.SubTitle;
				}
				if (s != "")
				{
					float side = 5f * _PreviewScale;
					float xx0 = _offsetX + side;
					float yy0 = _offsetY + _TitleTop;
					rct = new RectangleF(xx0, yy0, _PrintWidth - side * 2, _TitlleHeight);
					fmt.Alignment = StringAlignment.Near;
                    fmt.LineAlignment = StringAlignment.Center;
					ff = new Font(_FontFamily, _FontSizeTitle, FontStyle.Bold);
					try
					{
						g.DrawString(s, ff, sb, rct, fmt);
					}
					finally
					{
						ff.Dispose();
					}
				}
				if (_ContDocument.IsPrintDurationInfo == true)
				{
					s = _ContDocument.DurationStr() + " / " +_ContDocument.DurationStr(_CurrentPage);
					float side2 = 5f * _PreviewScale;
					float xxx0 = _offsetX + side2;
					float yyy0 = _offsetY + _FooterTop;
					rct = new RectangleF(xxx0, yyy0, _PrintWidth - side2 * 2, _FooterHeigh);
					fmt.Alignment = StringAlignment.Far;
					ff = new Font(_FontFamily, _FontSizeSec, FontStyle.Bold);
					try
					{
						g.DrawString(s, ff, sb, rct, fmt);
					}
					finally
					{
						ff.Dispose();
					}
 
				}
			}
            finally
            {
                sb.Dispose();
                p.Dispose();
            }


        }
        //-------------------------------------------------------------------------
        private void DrawNumber(Graphics g, int idx, Font fnt)
        {
            KomaInfo ki = _ContDocument.GetItem(_CurrentIndex + idx);
            if ( (ki.Empty == true)||(ki.IsNoneNumber==true)) return;
            g.PageUnit = GraphicsUnit.Millimeter;
            StringFormat fmt = new StringFormat();
            fmt.Alignment = StringAlignment.Center;
            fmt.LineAlignment = StringAlignment.Center;

			SolidBrush sb = new SolidBrush(Color.Black);
			try
			{
				float y0 = _offsetY + _KomaTop + (_KomaHeight * idx);
				//----------------


				//矢印を描く
				if (ki.IsContinued == false)
				{
					float x0 = _offsetX + _NumberLeft;

					x0 = _offsetX + _NumberLeft;
					string num = ki.DispNumber;

					if (num != string.Empty)
					{
						float mm = _MarginH * 2;
						RectangleF rct = new RectangleF(x0 + _MarginNumber, y0 + mm, _NumberWidth - _MarginNumber * 2, _KomaHeight - mm * 2);
						g.DrawString(num, fnt, sb, rct, fmt);
						if (_ContDocument.IsPrintPartCaption == true)
						{
							fmt.Alignment = StringAlignment.Near;
							fmt.LineAlignment = StringAlignment.Near;
							Font ff = new Font(fnt.FontFamily, fnt.Size * 0.75f, FontStyle.Regular);
							g.DrawString(_ContDocument.DispPartCaption(_CurrentIndex + idx), ff, sb, rct, fmt);
							ff.Dispose();

						}
					}
					//線を引く
					if (ki.IsContinuedNext == true)
					{
						Pen p = new Pen(Color.Black);
						try
						{
							p.Width = _PenSizeS;
							float xc = x0 + _NumberWidth / 2;
							float y1 = y0 + _KomaHeight;
							g.DrawLine(p, xc, y1, xc, y1 - _KomaHeight / 4);
						}
						finally
						{
							p.Dispose();
						}
					}
				}
				else
				{
					//棒線を引く
					Pen p = new Pen(Color.Black);
					try
					{
						p.Width = _PenSizeS;
						float xc = _offsetX + _NumberLeft + _NumberWidth / 2;
						float y1 = y0 + _KomaHeight;
						g.DrawLine(p, xc, y0, xc, y1);
						if (ki.IsContinuedNext == false)
						{
							float v = _NumberWidth / 4;
							g.DrawLine(p, xc, y1, xc - v, y1 - v);
							g.DrawLine(p, xc, y1, xc + v, y1 - v);
						}
					}
					finally
					{
						p.Dispose();
					}

				}
			}
			finally
			{
				sb.Dispose();
			}
        }
        //-------------------------------------------------------------------------
        private void DrawSec(Graphics g, int idx)
        {
            KomaInfo ki = _ContDocument.GetItem(_CurrentIndex + idx);
            if ((ki.Empty == true) || (ki.IsNoneNumber == true)) return;
            g.PageUnit = GraphicsUnit.Millimeter;
            StringFormat fmt = new StringFormat();
            fmt.Alignment = StringAlignment.Center;

			SolidBrush sb = new SolidBrush(Color.Black);
			try
			{

				float y0 = _offsetY + _KomaTop + (_KomaHeight * idx);
				//----------------
				//秒数を描く
				string b = "";
				if ((ki.IsContinued == true) || (ki.IsContinuedNext == true))
				{
					b = _ContDocument.DispKomaSec(_CurrentIndex + idx);
					if (b != string.Empty)
					{
						Font f0 = new Font(_FontFamily, _FontSizeSec * 0.8f);
						try
						{
							float x0 = _offsetX + _DurationLeft;
							fmt.LineAlignment = StringAlignment.Center;
							RectangleF rctN = new RectangleF(x0 + _MarginSec, y0 + _MarginH, _SecWidth - _MarginSec * 2, _KomaHeight - _MarginH * 2);
							g.DrawString(b, f0, sb, rctN, fmt);
						}
						finally
						{
							f0.Dispose();
						}
					}
				}
				b = _ContDocument.DispCutSec(_CurrentIndex + idx);
				if (b != string.Empty)
				{
					Font f1 = new Font(_FontFamily, _FontSizeSec, FontStyle.Bold);
					try
					{
						float x0 = _offsetX + _DurationLeft;
						fmt.LineAlignment = StringAlignment.Far;
						RectangleF rctN = new RectangleF(x0 + _MarginSec, y0 + _MarginH, _SecWidth - _MarginSec * 2, _KomaHeight - _MarginH * 2);
						g.DrawString(b, f1, sb, rctN, fmt);
					}
					finally
					{
						f1.Dispose();
					}
				}
			}
			finally
			{
				sb.Dispose();
			}
        }
        //--------------------------------------------------------------------------
        /// <summary>
        /// ロードされているサムネイルを描画
        /// </summary>
        /// <param name="g"></param>
        public void DrawThumPictures(Graphics g)
        {
            if (_ContDocument == null) return;
            g.PageUnit = GraphicsUnit.Millimeter;
            float px = _offsetX + _NumberWidth;
            float py = _offsetY + _KomaTop;
            for (int i = 0; i < def.KomaCount; i++)
            {
                int idx = _CurrentIndex + i;
                KomaInfo ki = _ContDocument.GetItem(idx);
 
                //Picがあるか
                if ((ki.Empty == false) && (ki.Pic.name != string.Empty))
                {
                    //画像のロード
                    if ((PreviewPics[i].IsBitmap == false) || (PreviewPics[i].name != ki.Pic.name))
                    {
                        Bitmap buf = null;
                        buf = _ContDocument.LoadThumbFile(idx);
                        if (buf != null)
                        {
                            PreviewPics[i].bmp = buf;
                            PreviewPics[i].name = ki.Pic.name;
                        }
                        else
                        {
                            PreviewPics[i].Clear();
                        }

                     }
                    //表示位置
                    float xx = px + ki.Pic.X * _PreviewScale;
                    float yy = py + ki.Pic.Y * _PreviewScale + _KomaHeight * i;
                    if (PreviewPics[i] != null)
                    {
                        g.DrawImage(PreviewPics[i].bmp, xx, yy);
                    }
                    else
                    {
                        float xxB = px;
                        float yyB = py + _KomaHeight * i;
                        Pen p = new Pen(Color.Black);
                        p.Width = _PenSizeS;
                        try
                        {
                            float xx2 = xxB + _KomaWidth;
                            float yy2 = yyB + _KomaHeight;
                            g.DrawLine(p, xxB, yyB, xx2, yy2);
                            g.DrawLine(p, xxB, yy2, xx2, yyB);
                        }
                        finally
                        {
                            p.Dispose();
                        }
                    }
                }
                else
                {
                    PreviewPics[i].Clear();
                }

            }
        }
        //--------------------------------------------------------------------------
        public void DrawPictures(Graphics g)
        {
            if (_ContDocument == null) return;
            g.PageUnit = GraphicsUnit.Millimeter;
            float px = _offsetX + _NumberWidth;
            float py = _offsetY + _KomaTop;
            for (int i = 0; i < def.KomaCount; i++)
            {
                KomaInfo ki = _ContDocument.GetItem(_CurrentIndex + i);
                if (ki.Empty == false)
                {
                    if (ki.PictName != string.Empty)
                    {
                        Bitmap buf = _ContDocument.LoadPictureFile(_CurrentIndex + i);
                        try
                        {
                            if (buf != null)
                            {
                                float w = buf.Width * 25.4f * _PreviewScale / _dpi;
                                float h = buf.Height * 25.4f * _PreviewScale / _dpi;
                                float xx = px + ki.Pic.X * _PreviewScale;
                                float yy = py + ki.Pic.Y * _PreviewScale + (_KomaHeight * i);
                                g.DrawImage(buf, new RectangleF( xx, yy,w, h));
                            }
                        }
                        finally
                        {
                            if (buf != null)
                            {
                                buf.Dispose();
                            }
                        }
                    }
                }
            }
        }
        //--------------------------------------------------------------------------

        //--------------------------------------------------------------------------
        public int CurrentPage
        {
            get
            {
            	if (_ContDocument == null)
            	{
            		return 0;
            	}
            	else
            	{
	            	if (_CurrentPage<=0)
	            	{
	            		_CurrentPage=0;
	            		return 0;
	            	}
	            	else
	            	{
                        int p = (_ContDocument.KomaCount / def.KomaCount) -1;
                        if (_CurrentPage > p) _CurrentPage = p;
		            	return _CurrentPage;
	            	}
            	}
            }
            set
            {
                if (_ContDocument == null)
                {
                    _CurrentPage = 0;
                    _CurrentIndex = 0;
                }
                else
                {
                    int v = value;
                    if (v<=0){
                        v =0;
                    }
                    else
                    {
                        int p = (_ContDocument.KomaCount / def.KomaCount) - 1;
                        if (v > p) v = p;
                    }
                    {
                     if (_CurrentPage != v)
                        _CurrentPage = v;
                        _CurrentIndex = v * def.KomaCount;
                        OnPageChangeChangedd(new EventArgs());
                    }
                }
            }
        }
        //--------------------------------------------------------------------------
        public int PageCount
        {
            get
            {
                if (_ContDocument == null)
                {
                    return 0;
                }
                else
                {
                    return _ContDocument.PageCount;
                }
            }

        }
        //--------------------------------------------------------------------------
        public Bitmap GetPreviewPics(int idx)
        {
            if ((idx < 0) || (idx >= def.KomaCount)) return null;
            return PreviewPics[idx].bmp;
        }
        //--------------------------------------------------------------------------
        public int PreviewOffsetX
        {
            get { return (int)Math.Round((_offsetX / _PreviewScale) * _dpi / 25.4f); }
            set { _offsetX = ((float)value * 25.4f / _dpi) * _PreviewScale; }
        }
        //--------------------------------------------------------------------------
        public int PreviewOffsetY
        {
            get { return (int)Math.Round((_offsetY / _PreviewScale) * _dpi / 25.4f); }
            set { _offsetY = ((float)value * 25.4f / _dpi) * _PreviewScale; }
        }
        //--------------------------------------------------------------------------
    }
}
