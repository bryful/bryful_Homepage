﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Drawing;

namespace ContEditorNazoh
{
    public class KomaDraw : Component
    {
        private ContDocument _ContDocument;
        private Form _From;
        private int _OffsetX = 0;
        private int _OffsetY = 0;
        private Bitmap [] PreviewPics = new Bitmap[def.KomaCount];
        private string[] PicName = new string[def.KomaCount];
        public bool RefreshFlag = false;
        private bool _IsNoDraw = false;
        //***********************************************************
        public KomaDraw()
        {
            PicName[0] = "";
            PicName[1] = "";
            PicName[2] = "";
            PicName[3] = "";
            PicName[4] = "";
        }
        //***********************************************************
        /*
         * イベント
         */
        //***********************************************************
        //***********************************************************
        /*
         * プロパティ
         */
        //***********************************************************
        public ContDocument ContDocument
        {
            get { return _ContDocument; }
            set
            {
                _ContDocument = value;
                /*if (_ContDocument != null)
                {
                    _ContDocument.komaChanged += new EventHandler(contDocument_KomaChanged);
                }*/
            }
        }
        //----------------------------------------------------------------
        private void contDocument_KomaChanged(object sender, EventArgs e)
        {
            //this.Invalidate();
        }
        //--------------------------------------------------------------
        public Form Form
        {
            get { return _From; }
            set
            {
                _From = value;
                if (_From != null)
                {
                    _From.Paint += new PaintEventHandler(MainForm_Paint);
                    _From.MouseDown += new MouseEventHandler(MainForm_MouseDown);
                }
            }
        }
        //***********************************************************
        private void MainForm_Paint(object sender, PaintEventArgs e)
        {
            if (_From == null) return;
            Graphics g = e.Graphics;
            SolidBrush sb = new SolidBrush(_From.BackColor);
            Pen p = new Pen(Color.Black);
            try
            {
                g.FillRectangle(sb,new Rectangle(0,0,_From.ClientSize.Width,_From.ClientSize.Height));

                if (_ContDocument != null)
                {
                    if (RefreshFlag == true)
                    {
                        Clear();
                        RefreshFlag = false;
                    }

                    DrawThumPictures(g);
                }

                for (int i = 0; i < def.KomaCount; i++)
                {
                    Rectangle rct = new Rectangle(_OffsetX, _OffsetY + i * def.PreviewKomaHeightP, def.PreviewKomaWidthP, def.PreviewKomaHeightP);
                    g.DrawRectangle(p, rct);
                }
            }
            finally
            {
                sb.Dispose();
                p.Dispose();
            }
        }
        //***********************************************************
        private void MainForm_MouseDown(object sender, MouseEventArgs e)
        {
            if (_ContDocument != null){
                int y = (e.Y - _OffsetY) / def.PreviewKomaHeightP;
                if ((y >= 0) && (y < def.KomaCount))
                {
                    if (_ContDocument.SelectedIndex != y)
                    {
                        _ContDocument.SelectedIndex = y;
                    }
                }

            }
        }
        //***********************************************************
        public void SetOffset(int x, int y)
        {
            _OffsetX = x;
            _OffsetY = y;
        }
        //----------------
        public Point Offset
        {
            get { return new Point(_OffsetX, _OffsetY); }
            set { _OffsetX = value.X; _OffsetY = value.Y; }
        }
        //----------------
        //***********************************************************
         //--------------------------------------------------------------------------
        /// <summary>
        /// ロードされているサムネイルを描画
        /// </summary>
        /// <param name="g"></param>
        public void DrawThumPictures(Graphics g)
        {
            if (_ContDocument == null) return;
            if (_IsNoDraw == true) return;
            int index = _ContDocument.CurrentPage * def.KomaCount;
            for (int i = 0; i < def.KomaCount; i++)
            {
                KomaInfo ki = _ContDocument.GetItem(index + i);
                if (ki.Empty == false)
                {
                    string pn = ki.PictName;
                    if (pn != string.Empty)
                    {
                        if ( (PreviewPics[i] == null)||( PicName[i] != pn))
                        {
                            PicName[i] = _ContDocument.GetPictureName(index + i);
                            PreviewPics[i] = _ContDocument.LoadThumbFile(index + i);
                        }
                        int xx = _OffsetX + ki.DispOffsetX;
                        int yy = _OffsetY + ki.DispOffsetY + def.PreviewKomaHeightP * i;
                        if (PreviewPics[i] != null)
                        {
                            g.DrawImage(PreviewPics[i], xx, yy);
                        }
                        else
                        {
                            int xxB = _OffsetX;
                            int yyB = _OffsetY + def.PreviewKomaHeightP * i;
                            Rectangle rct = new Rectangle(xxB, yyB, def.PreviewKomaWidthP, def.PreviewKomaHeightP);
                            StringFormat fmt = new StringFormat();
                            fmt.Alignment = StringAlignment.Center;
                            fmt.LineAlignment = StringAlignment.Center;
                            Font ft = new Font(new FontFamily("MS UI Gothic"), 12);
                            SolidBrush sb = new SolidBrush(Color.Black);
                            try
                            {
                                g.DrawString("not found!", ft, sb, rct,fmt);
                            }
                            finally
                            {
                                ft.Dispose();
                                sb.Dispose();
                            }
                        }
                    }
                }
            }
        }
        //----------------------------------------------------------------------------------
        public void Clear()
        {
            for (int i = 0; i < def.KomaCount; i++)
            {
                if (PreviewPics[i] != null)
                {
                    PreviewPics[i].Dispose();
                    PreviewPics[i] = null;
                }
            }
        }
        //----------------------------------------------------------------------------------
        public void DisposeThumb(int idx)
        {
            int pos = idx % def.KomaCount;
            if (pos >= 0)
            {
                if (PreviewPics[pos] != null)
                {
                    PreviewPics[pos].Dispose();
                    PreviewPics[pos] = null;
                }
            }
 
        }
        //----------------------------------------------------------------------------------
        public bool IsNoDraw
        {
            get { return _IsNoDraw; }
            set
            {
                _IsNoDraw = value;
                if (_IsNoDraw == true)
                {
                    Clear();
                }
            }
        }
    }
}
