﻿namespace ContEditorNazoh
{
    partial class DurationEdit
    {
        /// <summary> 
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region コンポーネント デザイナーで生成されたコード

        /// <summary> 
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を 
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
			this.rbIsSec = new System.Windows.Forms.RadioButton();
			this.rbIsFrame = new System.Windows.Forms.RadioButton();
			this.label3 = new System.Windows.Forms.Label();
			this.tbKoma = new System.Windows.Forms.TextBox();
			this.tbSec = new System.Windows.Forms.TextBox();
			this.tbFrame = new System.Windows.Forms.TextBox();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// rbIsSec
			// 
			this.rbIsSec.AutoSize = true;
			this.rbIsSec.Checked = true;
			this.rbIsSec.Location = new System.Drawing.Point(14, 37);
			this.rbIsSec.Name = "rbIsSec";
			this.rbIsSec.Size = new System.Drawing.Size(86, 16);
			this.rbIsSec.TabIndex = 12;
			this.rbIsSec.TabStop = true;
			this.rbIsSec.Text = "秒コマで指定";
			this.rbIsSec.UseVisualStyleBackColor = true;
			this.rbIsSec.CheckedChanged += new System.EventHandler(this.rbIsSec_CheckedChanged);
			// 
			// rbIsFrame
			// 
			this.rbIsFrame.AutoSize = true;
			this.rbIsFrame.Location = new System.Drawing.Point(14, 8);
			this.rbIsFrame.Name = "rbIsFrame";
			this.rbIsFrame.Size = new System.Drawing.Size(94, 16);
			this.rbIsFrame.TabIndex = 11;
			this.rbIsFrame.Text = "フレームで指定";
			this.rbIsFrame.UseVisualStyleBackColor = true;
			this.rbIsFrame.CheckedChanged += new System.EventHandler(this.rbIsFrame_CheckedChanged);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
			this.label3.Location = new System.Drawing.Point(201, 40);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(25, 16);
			this.label3.TabIndex = 10;
			this.label3.Text = "＋";
			// 
			// tbKoma
			// 
			this.tbKoma.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
			this.tbKoma.Location = new System.Drawing.Point(232, 32);
			this.tbKoma.Name = "tbKoma";
			this.tbKoma.Size = new System.Drawing.Size(54, 23);
			this.tbKoma.TabIndex = 2;
			this.tbKoma.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_KeyPress);
			// 
			// tbSec
			// 
			this.tbSec.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
			this.tbSec.Location = new System.Drawing.Point(115, 33);
			this.tbSec.Name = "tbSec";
			this.tbSec.Size = new System.Drawing.Size(82, 23);
			this.tbSec.TabIndex = 1;
			this.tbSec.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_KeyPress);
			// 
			// tbFrame
			// 
			this.tbFrame.Enabled = false;
			this.tbFrame.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
			this.tbFrame.Location = new System.Drawing.Point(115, 3);
			this.tbFrame.Name = "tbFrame";
			this.tbFrame.Size = new System.Drawing.Size(171, 23);
			this.tbFrame.TabIndex = 0;
			this.tbFrame.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_KeyPress);
			// 
			// panel1
			// 
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.rbIsSec);
			this.panel1.Controls.Add(this.tbFrame);
			this.panel1.Controls.Add(this.rbIsFrame);
			this.panel1.Controls.Add(this.tbSec);
			this.panel1.Controls.Add(this.label3);
			this.panel1.Controls.Add(this.tbKoma);
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(300, 64);
			this.panel1.TabIndex = 13;
			// 
			// DurationEdit
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.panel1);
			this.Name = "DurationEdit";
			this.Size = new System.Drawing.Size(300, 64);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RadioButton rbIsSec;
        private System.Windows.Forms.RadioButton rbIsFrame;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbKoma;
        private System.Windows.Forms.TextBox tbSec;
        private System.Windows.Forms.TextBox tbFrame;
        private System.Windows.Forms.Panel panel1;
    }
}
