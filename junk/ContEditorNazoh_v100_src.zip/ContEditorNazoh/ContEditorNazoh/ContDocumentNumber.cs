﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class ContDocument : Component
    {
        //----------------------------------------------------------------------------------
        public void EditNumberStr()
        {
            int idx = _SelectedIndex;
            if (idx < 0) return;
            if ((_Items[idx].Empty == true) || (_Items[idx].IsNoneNumber == true) || (_Items[idx].IsContinued == true)) return;
            CutNumberDlg dlg = new CutNumberDlg();
            dlg.NumberStr = _Items[idx].NumberStr;
            switch (dlg.ShowDialog())
            {
                case DialogResult.OK:
                    if (_Items[idx].NumberStr != dlg.NumberStr)
                    {
                        _Items[idx].NumberStr = dlg.NumberStr;
                        _changeFlag = true;
                        OnkomaChanged(new EventArgs());
                    }
                    break;
                case DialogResult.Yes:
                    if (_Items[idx].NumberStr != string.Empty)
                    {
                        _Items[idx].NumberStr = string.Empty;
                        _changeFlag = true;
                        OnkomaChanged(new EventArgs());
                    }
                    break;
            }
        }
        //------------------------------------------------------------------------------------------------
        public string DispNumber(int idx)
        {
            string ret = string.Empty;
            if ((idx < 0) || (idx >= _Items.Count)) return ret;
            if ((_Items[idx].Empty == true) || (_Items[idx].IsNoneNumber == true)) return ret;
            string s = _Items[idx].NumberStr;
            if (s != string.Empty)
            {
                return s;
            }
            else
            {
                int v = _Items[idx].Number + NumberStart;
                //3桁に強制
                if (v <= 0)
                {
                    return "000";
                }
                else if (v < 10)
                {
                    return "00" + v.ToString();
                }
                else if (v < 100)
                {
                    return "0" + v.ToString();
                }
                else
                {
                    return v.ToString();
                }
            }
        }
        //-------------------------------------------------------------------------------
        public void NumberLocked()
        {
            if (MessageBox.Show("カットナンバーを固定にします。", "確認", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {

                for (int i = 0; i < _Items.Count; i++)
                {
                    if (_Items[i].Empty == false)
                        if (_Items[i].IsNoneNumber == false)
                            if (_Items[i].IsContinued == false)
                                if (_Items[i].NumberStr == string.Empty)
                                    _Items[i].NumberStr = DispNumber(i);
                }
				OnkomaChanged(new EventArgs());
            }

        }
		//-------------------------------------------------------------------------------
		public void NumberUnlocked()
		{
			if (MessageBox.Show("カットナンバーを固定を解除します。", "確認", MessageBoxButtons.OKCancel) == DialogResult.OK)
			{

				for (int i = 0; i < _Items.Count; i++)
				{
					if (_Items[i].Empty == false)
						if (_Items[i].IsNoneNumber == false)
							if (_Items[i].IsContinued == false)
									_Items[i].NumberStr = "";
				}
				OnkomaChanged(new EventArgs());
			}

		}
 
    }
}
