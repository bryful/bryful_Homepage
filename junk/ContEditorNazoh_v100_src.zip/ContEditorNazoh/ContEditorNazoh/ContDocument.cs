﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class ContDocument : Component
    {
        /// <summary>
        /// 編集の停止フラグ。
        /// </summary>
        private bool _Locked = false;
        /// <summary>
        /// 修正されたか？
        /// </summary>
		private bool _changeFlag = false;


		/// <summary>
		/// 作品タイトル
		/// </summary>
		public string Title = "";
		/// <summary>
		/// 話数
		/// </summary>
		public string OPUS = "";
		/// <summary>
		/// サブタイトル
		/// </summary>
		public string SubTitle = "";
		/// <summary>
		/// 作成者名
		/// </summary>
		public string CreateUser = "";
		/// <summary>
		/// 修正者名
		/// </summary>
		public string UpdateUser = "";
		/// <summary>
		/// 社名
		/// </summary>
		public string CampanyName = "";
		/// <summary>
		/// コメント
		/// </summary>
		public string Comment = "";

		private bool _IsPrintTitle = false;
		private bool _IsPrintSubTitle = false;
		private bool _IsPrintOPUS = false;
		private bool _IsPrintCampany = true;

		private bool _IsPrintDurationInfo = false;

        
        /// <summary>
        /// 現在アクティブなページ
        /// </summary>
        public int _CurrentPage = 0;
		/// <summary>
		/// 現在選択されているコマのインデックス
		/// </summary>
        public int _SelectedIndex = -1;
        /// <summary>
        /// フレームレート
        /// </summary>
        private float _fps = def.fps;
        /// <summary>
        /// 現在の総秒数
        /// </summary>
        private float _Duration = 0;
        /// <summary>
        /// 現在のカット数
        /// </summary>
        private int _CutCount = 0;
        /// <summary>
        /// 目標総秒数
        /// </summary>
		private float _TargtDuration = 0;
        /// <summary>
        /// 現在の平均カット秒数
        /// </summary>
        private float _ParCutSec = 0;
        /// <summary>
        /// 秒数が指定されていないカットがあるか
        /// </summary>
        private int _NoneDurationCut = 0;
        /// <summary>
        /// カットナンバーのスタート番号
        /// </summary>
        private int _NumberStart = 1;
		/// <summary>
		/// ページ番号のスタート番号
		/// </summary>
		private int _PageNumberStart = 0;

        private ContVersion _Version = ContVersion.First;
 
		////////////////////////////////////////////////////////////
        /// <summary>
        /// コンテデータの配列
        /// </summary>
        public List<KomaInfo> _Items = new List<KomaInfo>();
		////////////////////////////////////////////////////////////

        public string CaptionCut = "カット";
        public string CaptionPicture = "ピ　ク　チ　ュ　ア";
        public string CaptionMemo = "内　容";
        public string CaptionWords = "セ　リ　フ";
        public string CaptionSec = "秒数";



        
        public string[] VerCaption = new string[(int)ContVersion.Count]
        {
            "決定稿",
            "第１項",
            "第２項",
            "第３項",
            "第４項",
            "第５項",
            "第６項",
            "第７項",
            "第８項",
            "第９項",
            "第10項"
        };
        //*************************************************************************************************************
        public ContDocument()
        {
            //ワークフォルダの設定
            SetWorkDir( DefaultWorkDir);
            //パートキャプションの初期値
            DefaultPartCaption();
            InitPartDuration();
            //データの準備
            Clear();
        }
        //*************************************************************************************************************
       //------------------------------------------------------
        /// <summary>
        /// コンテデータを初期化。
        /// 必ず1ページ分確保する
        /// </summary>
        public void Clear()
        {
            _changeFlag = false;
            _Items.Clear();
            newPageAppend();
            ChkItems();
            _CurrentPage = 0;
            OnkomaChanged(new EventArgs());
        }
        //------------------------------------------------------
        /// <summary>
        ///コンテデータの配列を獲得
        /// </summary>
        /// <param name="lst"></param>
        public void ItemsAssign(List<KomaInfo> lst)
        {
            _changeFlag = false;
            _Items.Clear();
            if (lst.Count > 0)
            {
                for (int i = 0; i < lst.Count; i++)
                {
                    _Items.Add(lst[i]);
                }
            }
            ChkItems();
            _CurrentPage = 0;
            OnkomaChanged(new EventArgs());
        }
        //------------------------------------------------------
        /// <summary>
        /// コンテデータからトップカットを獲得する。
        /// </summary>
        /// <returns>
        /// トップカットのインデックス。
        /// </returns>
        private int FindTopCut()
        {
            for (int i = 0; i < _Items.Count; i++)
            {
                if ((_Items[i].Empty == false) && (_Items[i].IsNoneNumber == false))
                {
                    return i;
                }
            }
            return 0;
        }
        //------------------------------------------------------
       /// <summary>
       /// 選択されている位置にカットを挿入
       /// </summary>
		
        public void InsertCut()
        {
			int idx = _SelectedIndex;
            if (idx < 0) return;
            if (_Items[idx].Empty == true) return;

			int v = idx;
			if (_Items[idx].IsContinued == true)
			{
				if (idx > 0)
				{
					//次のカットを探す
					for (int i = idx - 1; i >= 0; i--)
					{
						if ((_Items[i].IsContinued == false))
						{
							v = i;
							break;
						}
					}
				}
			}

            KomaInfo ki = new KomaInfo();
            InsertKomaInfo(v, ki);
            ChkItems();
            _changeFlag = true;
			_SelectedIndex = v;
			CurrentPageChk();
            OnkomaChanged(new EventArgs());
        }
        //------------------------------------------------------
        /// <summary>
        /// カットにコマを挿入
        /// </summary>
		public void InsertContinued()
        {
			int idx = _SelectedIndex;
            if ( idx < 0) return;
            if (_Items[idx].Empty == true) return;

			KomaInfo ki = new KomaInfo();

			if (_Items[idx].IsContinued == false)
			{
				_Items[idx].IsContinued = true;
				ki.IsContinued = false;
			}
			else
			{
				ki.IsContinued = true;
			}

            InsertKomaInfo(idx, ki);
            ChkItems();
            OnkomaChanged(new EventArgs());
        }
        //------------------------------------------------------
        /// <summary>
        /// 番号なしのコマを挿入
        /// </summary>
		public void InsertNoneNumber()
        {
            int idx = _SelectedIndex;
            if (idx < 0) return;
            if (_Items[idx].Empty == true) return;

            KomaInfo ki = new KomaInfo();
            ki.IsNoneNumber = true;
            InsertKomaInfo(idx, ki);
            ChkItems();
            _changeFlag = true;
            OnkomaChanged(new EventArgs());
        }
 		//------------------------------------------------------
		private void CurrentPageChk()
        {
            if (_SelectedIndex < 0) return;
            int sp = _SelectedIndex / def.KomaCount;
            if (_CurrentPage != sp)
            {
                _CurrentPage = sp;
            }
        }
        //------------------------------------------------------
        /// <summary>
        /// アイテム数がページに合うように末尾にコマを挿入する
        /// </summary>
        private void ChkItemCount()
        {
			//末尾のEmptyを削除
			int cnt = _Items.Count-1;
			if (cnt > def.KomaCount)
			{
				for (int i=cnt; i>=def.KomaCount;i--)
				{
					if (_Items[i].Empty == false)
					{
						break;
					}
					else
					{
						_Items.RemoveAt(i);
					}
				}
			}
            if (_Items.Count > 0)
            {
                _Items[_Items.Count - 1].IsPartEnd = false;
            }
            //足りないコマ数を数える
            int pc =  _Items.Count % def.KomaCount;
            if ( pc != 0)
            {
                pc = def.KomaCount - pc;
                for (int i = 0; i < pc; i++)
                {
                    KomaInfo ki = new KomaInfo();
                    //ki.IsNoneNumber = true;
                    ki.Empty = true;
                    _Items.Add(ki);
                }
            }
        }
        //------------------------------------------------------
        /// <summary>
        /// 改ページ設定されたコマのインデックスを探す
        /// </summary>
        /// <param name="st">開始インデックス</param>
        /// <returns></returns>
        private int FindPageBreak(int st)
        {
            int ret = -1;
            int cnt = _Items.Count;
            if ( cnt <= st) return ret;
            for (int i = st; i < cnt; i++)
            {
                if (_Items[i].IsPageBreak == true)
                {
                    ret = i;
					break;
                }
            }
            return ret;
        }
 		//------------------------------------------------------
		/// <summary>
		/// 指定されたインデックスからあとでページ頭となるこまを捜す。Emptyは無視する
		/// </summary>
		/// <param name="st"></param>
		/// <returns></returns>
        private int FindPageStart(int st)
		{
			int ret = -1;
			int cnt = _Items.Count;
			if (cnt <= st) return ret;
			for (int i = st; i < cnt; i++)
			{
				if (_Items[i].Empty == false)
				{
					return i;
				}
			}
			return ret;
		}
       //------------------------------------------------------
        /// <summary>
        /// 改行ページの処理
        /// </summary>
        public void ChkPageBreak()
        {
            //とりあえずEmptyを消す。
            int cnt = _Items.Count -1;
            for (int i = cnt; i >= 0; i--)
            {
                if (_Items[i].Empty == true)
                {
                    _Items.RemoveAt(i);
                }
            }
            _Items[_Items.Count - 1].IsPartEnd = false;

            //トップページの処理
            int idx = FindPageBreak(0);
            while (idx >= 0)
            {
				int nowPage = idx / def.KomaCount;
                int pc = (idx % def.KomaCount);

				//もともと一番下なら処理しない
				if ( pc != (def.KomaCount-1))
                {
					int tIdx = idx+1; 
					int nextPageIndex = (nowPage + 1) * def.KomaCount;
					//次のコマを探す。Emptyなコマは無視する
					int nxt = FindPageStart(tIdx);
					if (nxt > nextPageIndex)
					{
						RemoveKomaInfo(tIdx, nxt - nextPageIndex);
					}
					else
					{
						InsertKomaInfo(tIdx,(nextPageIndex-nxt), true, false);
					}
                }
				idx = FindPageBreak(idx+1);
            }
         }
        //------------------------------------------------------
        /// <summary>
        /// カットごとの秒数を計算
        /// </summary>
        private void ChkDuration()
        {

            _NoneDurationCut = 0;
            _PartCount = 0;
            InitPartDuration();
            if (_Items.Count <= 0) return;
            //秒数の計算
            float v = 0;
            float all = 0;
            int cnt = 0;
            int pp = 0;

            int pcnt = 0;
            float pDr = 0f;
            //必ず最後のコマをPartEndにする
            for (int i = _Items.Count - 1; i >= 0; i--)
            {
                if (_Items[i].Empty == false)
                {
                    _Items[i].IsPartEnd = true;
                    break;
                }
                
            }
            for (int i = 0; i < _Items.Count; i++)
            {
                if ((_Items[i].Empty == true) || (_Items[i].IsNoneNumber == true))
                {
                    _Items[i].Duration = 0;
                    _Items[i].DurationTotal = all;
                }
                else
                {
                    pDr += _Items[i].Duration;

                    all += _Items[i].Duration;
                    v += _Items[i].Duration;
                    _Items[i].DurationCutAdd = v;
                    _Items[i].DurationTotal = all;
                    if (_Items[i].IsContinuedNext == false)
                    {
                        if (v == 0) _NoneDurationCut++;
                        v = 0;
                        cnt++;
                        pcnt++;

                    }
                }

                _Items[i].PartNumber = pp;
                if (_Items[i].Empty == false)
                {
                    if (_Items[i].IsPartEnd == true)
                    {
                        _PartCutCount[pp] = pcnt;
                        pcnt = 0;
                        _PartDuration[pp] = pDr;
                        pDr = 0f;
                        pp++;
                    }
                }
            }
            _Duration = all;
            _CutCount = cnt;
             
            _PartCount = pp;
			if (cnt == 0)
			{
				_ParCutSec = 0;
			}
			else
			{
				_ParCutSec = all / cnt;
			}

        }
		//------------------------------------------------------
		/// <summary>
		/// 継続コマの確認。
		/// </summary>
        public void ChkIsContinued()
		{
			int cnt= _Items.Count;
			if (cnt <= 0) return;
			_Items[0].IsContinued = false;
			for (int i = 0; i < cnt; i++)
			{
				if (_Items[i].IsContinued == true)
				{
					if (i > 0)
					{
						if (_Items[i - 1].Empty == true) _Items[i].IsContinued = false;
						if (_Items[i - 1].IsNoneNumber == true) _Items[i].IsContinued = false;
					}
				}
			}
			cnt--;
			for (int i = 0; i < cnt; i++)
			{
				//カットの分け目
				if (i < cnt)
				{
					if (_Items[i].IsNoneNumber == true)
					{
						_Items[i].IsContinuedNext = false;
					}
					else
					{
						_Items[i].IsContinuedNext = _Items[i + 1].IsContinued;
					}
				}
				else
				{
					_Items[i].IsContinuedNext = false;
				}
			}
     	}
		//------------------------------------------------------
		/// <summary>
		/// 自動カット番号割り振り
		/// </summary>
        public void ChkNumber()
		{
			int cnt = _Items.Count;
			if (cnt <= 0) return;
            int cn = 0;
			int TopCut = FindTopCut();
			for (int i = 0; i <cnt; i++)
			{
				if (i < TopCut)
				{
					_Items[i].Number = -1;
				}
				else
				{
					if ((_Items[i].IsContinued == true) || (_Items[i].IsNoneNumber == true) || (_Items[i].Empty == true))
					{
						_Items[i].Number = -1;
					}
					else
					{
						_Items[i].Number = cn;
						cn++;
					}
				}

			}
            _CutCount = cn;
		}
        //------------------------------------------------------
        private bool ChkTailItem()
        {
            int cnt = _Items.Count - 1;
            if ( cnt <=def.KomaCount-1 ) return false;
            int idx = cnt;
            //入力されたコマを後ろから探す。
            for (int i = cnt; i >= def.KomaCount; i--)
            {
                if (_Items[i].KomaEnabled == true)
                {
                    idx = i;
                    break;
                }
            }
            if (idx == cnt) return false;
            int pct = idx / def.KomaCount;
            int pcm = _Items.Count / def.KomaCount;
            if (pcm > (pct + 1))
            {
                int t = (pct + 1) * def.KomaCount;
                for (int i = cnt; i >= t; i--)
                {
                    _Items.RemoveAt(i);
                }
                return true;
            }
            else
            {
                return false;
            }

        }
        //------------------------------------------------------
        /// <summary>
        /// コンテデータを確認して、いろいろな処理を加える。
        /// コンテデータに書き込んだ後、必ず実行する
        /// </summary>
        public void ChkItems()
        {
            if (_Items.Count == 0)
            {
                newPageAppend();
            }
            for (int i = 0; i < _Items.Count; i++)
            {
                if (i == _SelectedIndex)
                {
                    _Items[i].Tag = 1;
                }
                else
                {
                    _Items[i].Tag = 0;
                }

            }
            ChkPageBreak();//改ページの処理
            ChkItemCount();//ページ枚数の辻妻を合わせる
			
			ChkIsContinued();//継続コマの確認
			ChkNumber();//カットナンバー割り振り
            ChkDuration();//秒数計算
            int si = -1;
            for (int i = 0; i < _Items.Count; i++)
            {
                if (_Items[i].Tag == 1)
                {
                    si = i;
                    break;
                }
            }
            if (si != _SelectedIndex)
            {
                _SelectedIndex = si;
               
            }
            CurrentPageChk();
        }
        //----------------------------------------------
        public void TrimItems()
        {
            if (ChkTailItem() == true)
            {
                ChkItems();
                if (_SelectedIndex >= _Items.Count)
                {
                    _SelectedIndex = _Items.Count - 1;
                }
                OnkomaChanged(new EventArgs());
            }
        }

        //-------------------------------------------------------------------------------
        private void ChkSelected()
        {
            if (_SelectedIndex >= _Items.Count)
            {
                _SelectedIndex = - 1;
            }
        }
        //-------------------------------------------------------------------------------
        private void ChkPageBrakeEmpty(int idx, bool IsConti)
        {
            //
            if (_Items[idx].Empty == true)
            {
                if (idx > 0)
                {
                    //Emptyの頭を探す
                    int pp = -1;
                    for ( int i= idx -1; i>=0;i--)
                    {
                        if (_Items[i].Empty == false)
                        {
                            pp = i;
                            break;
                        }
                    }

                    if (pp >= 0)
                    {
                        for (int i = pp+1; i <= idx; i++)
                        {
                            if (_Items[i].Empty == true)
                            {
                                _Items[i].Empty = false;
                                if (IsConti == true)
                                {
                                    _Items[i].IsContinued = true;
                                }
                            }
                        }
                        if (_Items[pp].IsPageBreak == true)
                        {
                            _Items[pp].IsPageBreak = false;
                            _Items[idx].IsPageBreak = true;
                        }
                        if (_Items[pp].IsPartEnd == true)
                        {
                            _Items[pp].IsPartEnd = false;
                            _Items[idx].IsPartEnd = true;
                        }
                    }
                }
            }
        }
		//-------------------------------------------------------------------------------
	}

}
