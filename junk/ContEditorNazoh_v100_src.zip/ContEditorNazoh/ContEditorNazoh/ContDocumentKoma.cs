﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;
using System.Windows.Forms;


namespace ContEditorNazoh
{
    public partial class ContDocument : Component
    {
        //------------------------------------------------------
        /// <summary>
        /// 指定されたパラメータでコマを挿入。
        /// </summary>
        /// <param name="idx"></param>
        /// <param name="cnt"></param>
        /// <param name="Emp"></param>
        /// <param name="non"></param>
        /// <returns></returns>
        private bool InsertKomaInfo(int idx, int cnt, bool Emp, bool non)
        {
            if (cnt <= 0) return false;

            if (idx < _Items.Count)
            {
                if (idx < 0) idx = 0;
                for (int i = 0; i < cnt; i++)
                {
                    KomaInfo ki = new KomaInfo();
                    ki.Empty = Emp;
                    ki.IsNoneNumber = non;
                    _Items.Insert(idx, ki);
                }
            }
            else
            {
                for (int i = 0; i < cnt; i++)
                {
                    KomaInfo ki = new KomaInfo();
                    ki.Empty = Emp;
                    ki.IsNoneNumber = non;
                    _Items.Add(ki);
                }
            }
            return true;
        }
        //------------------------------------------------------
        /// <summary>
        /// 指定したKomaInfo を挿入。
        /// </summary>
        /// <param name="idx"></param>
        /// <param name="ki"></param>
        private void InsertKomaInfo(int idx, KomaInfo ki)
        {
            if (idx < _Items.Count)
            {
                if (idx < 0) idx = 0;
                _Items.Insert(idx, ki);
            }
            else
            {
                _Items.Add(ki);
            }
        }
        //------------------------------------------------------
        /// <summary>
        /// 指定されたパラメータでコマを挿入
        /// </summary>
        /// <param name="idx">挿入する位置</param>
        /// <param name="cnt">挿入する数</param>
        /// <param name="Emp">Empty設定</param>
        /// <param name="non">IsNoneNumer設定</param>
        public void InsertKoma(int idx, int cnt, bool Emp, bool non)
        {
            if (InsertKomaInfo(idx, cnt, Emp, non) == true)
            {
                ChkItems();
                _changeFlag = true;
                OnkomaChanged(new EventArgs());
            }

        }
        //------------------------------------------------------
        private bool RemoveKomaInfo(int idx, int cnt)
        {
            if ((idx < 0) || (idx >= _Items.Count) || (cnt <= 0)) return false;
            for (int i = 0; i < cnt; i++)
            {
                if (idx < _Items.Count)
                {
                    _Items.RemoveAt(idx);
                }
            }
            return true;
        }
        //------------------------------------------------------
        private void RemoveKoma(int idx, int cnt)
        {
            if (RemoveKomaInfo(idx, cnt) == true)
            {
                _changeFlag = true;
                OnkomaChanged(new EventArgs());
            }
        }
        //------------------------------------------------------
        private void SwapKoma(int idx0, int idx1)
        {
            int i0 = idx0;
            int i1 = idx1;
            int cnt = _Items.Count;
            if ((i0 < 0) || (i0 >= cnt)) return;
            if ((i1 < 0) || (i1 >= cnt)) return;
            if (i0 == i1) return;
            //全部は入れ替えない。
            string s;
            float f;
            s = _Items[i0].Memo;
            _Items[i0].Memo = _Items[i1].Memo;
            _Items[i1].Memo = s;

			s = _Items[i0].MemoU;
			_Items[i0].MemoU = _Items[i1].MemoU;
			_Items[i1].MemoU = s;

			s = _Items[i0].Words;
            _Items[i0].Words = _Items[i1].Words;
            _Items[i1].Words = s;

			s = _Items[i0].WordsU;
			_Items[i0].WordsU = _Items[i1].WordsU;
			_Items[i1].WordsU = s;

            //画像
            KomaPict kp = new KomaPict();
            kp.Assign(_Items[i0].Pic);
            _Items[i0].Pic.Assign(_Items[i1].Pic);
            _Items[i1].Pic.Assign(kp);

			kp.Assign(_Items[i0].PicSub);
			_Items[i0].PicSub.Assign(_Items[i1].PicSub);
			_Items[i1].PicSub.Assign(kp);

            f = _Items[i0].Duration;
            _Items[i0].Duration = _Items[i1].Duration;
            _Items[i1].Duration = f;

        }
        //----------------------------------------------------------------------------------
        public void KomaClear()
        {
            if (_Locked == true) return;
            if (_SelectedIndex >= 0)
            {
                bool b = false;
                if (_Items[_SelectedIndex].Memo != "")
                {
                    _Items[_SelectedIndex].Memo = "";
                    b = true;
                }
				if (_Items[_SelectedIndex].MemoU != "")
				{
					_Items[_SelectedIndex].MemoU = "";
					b = true;
				}
				if (_Items[_SelectedIndex].Words != "")
                {
                    _Items[_SelectedIndex].Words = "";
                    b = true;
                }
				if (_Items[_SelectedIndex].WordsU != "")
				{
					_Items[_SelectedIndex].WordsU = "";
					b = true;
				}
				if (_Items[_SelectedIndex].Pic.name != "")
                {
					_Items[_SelectedIndex].Pic.name = "";
                    b = true;
                }
				if (_Items[_SelectedIndex].Pic.X != 0)
				{
					_Items[_SelectedIndex].Pic.X = 0;
					b = true;
				}
				if (_Items[_SelectedIndex].Pic.Y != 0)
				{
					_Items[_SelectedIndex].Pic.Y = 0;
					b = true;
				}
				if (_Items[_SelectedIndex].PicSub.name != "")
				{
					_Items[_SelectedIndex].PicSub.name = "";
					b = true;
				}
				if (_Items[_SelectedIndex].PicSub.X != 0)
				{
					_Items[_SelectedIndex].PicSub.X = 0;
					b = true;
				}
				if (_Items[_SelectedIndex].PicSub.Y != 0)
				{
					_Items[_SelectedIndex].PicSub.Y = 0;
					b = true;
				}
				if (_Items[_SelectedIndex].Duration != 0)
                {
                    _Items[_SelectedIndex].Duration = 0;
                    b = true;
                }
                if (b == true)
                {
                    ChkItems();
                    _changeFlag = true;
                    OnkomaChanged(new EventArgs());
                }
            }
        }
        //----------------------------------------------------------------------------------
        public void KomaDelete()
        {
            if (_Locked == true) return;
            _CopyStartIndex = -1;
            int idx = _SelectedIndex;
            if (idx >= 0)
            {

                if (MessageBox.Show("このコマを削除します。", "確認", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    //ページの始まり
                    if (idx < _Items.Count - 1)
                    {
                        if ((_Items[idx].IsContinuedNext == true) && (_Items[idx].IsContinued == false))
                        {
                            _Items[idx + 1].IsContinued = false;
                            _Items[idx + 1].NumberStr = _Items[idx].NumberStr;
                        }
                    }
                    //改ページ
                    if ( (_Items[idx].IsPageBreak == true)&&(idx>0))
                    {
                        if ((_Items[idx].IsContinuedNext == false)&&(_Items[idx].IsContinued == true))
                        {
                            _Items[idx].IsPageBreak = false;
                            _Items[idx-1].IsPageBreak = true;
                        }
                    }
                    //PartEnd
                    if ((_Items[idx].IsPartEnd == true) && (idx > 0))
                    {
                        if ((_Items[idx].IsContinuedNext == false) && (_Items[idx].IsContinued == true))
                        {
                            _Items[idx].IsPartEnd = false;
                            _Items[idx - 1].IsPartEnd = true;
                        }
                    }
                    _Items.RemoveAt(idx);
                    ChkItems();
                    _changeFlag = true;
                    OnkomaChanged(new EventArgs());
                }
            }
        }
        //------------------------------------------------------
        public void KomaUpto()
        {
            if (_Locked == true) return;
            _CopyStartIndex = -1;
            int idx = _SelectedIndex;
            if (idx <= 0) return;
            if (_Items[idx].Empty == true) return;

            //前のコマを探す
            int nn = 0;
            for (int i = idx - 1; i >= 0; i--)
            {
                if (_Items[i].Empty == false)
                {
                    nn = i;
                    break;
                }
            }
            if (nn == 0)
            {
                if (_Items[nn].Empty == true) return;

            }
            SwapKoma(nn, _SelectedIndex);
            _SelectedIndex = nn;
            ChkItems();
            _changeFlag = true;
            OnkomaChanged(new EventArgs());
        }
        //------------------------------------------------------
        public void KomaDownto()
        {
            if (_Locked == true) return;
            _CopyStartIndex = -1;
            int idx = _SelectedIndex;
            if (idx < 0) return;
            if (_Items[idx].Empty == true) return;
            int cnt = _Items.Count - 1;
            if (idx >= cnt) return;

            //次のコマを探す
            int nn = cnt;
            for (int i = _SelectedIndex + 1; i <= cnt; i++)
            {
                if (_Items[i].Empty == false)
                {
                    nn = i;
                    break;
                }
            }
            if (nn == cnt)
            {
                if (_Items[nn].Empty == true) return;

            }
            SwapKoma(_SelectedIndex, nn);
            _SelectedIndex = nn;
            ChkItems();
            _changeFlag = true;
            OnkomaChanged(new EventArgs());
        }

    }
}
