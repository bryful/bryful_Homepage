﻿namespace ContEditorNazoh
{
    partial class MainForm
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.toolStrip1 = new System.Windows.Forms.ToolStrip();
			this.OpenMenu = new System.Windows.Forms.ToolStripButton();
			this.SaveBtn = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
			this.lbCurrentPage = new System.Windows.Forms.ToolStripLabel();
			this.btnTopPage = new System.Windows.Forms.ToolStripButton();
			this.btnPrevPage = new System.Windows.Forms.ToolStripButton();
			this.btnNextPage = new System.Windows.Forms.ToolStripButton();
			this.btnLastPage = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
			this.btnKomaUpto = new System.Windows.Forms.ToolStripButton();
			this.btnKomaDownto = new System.Windows.Forms.ToolStripButton();
			this.btnCutUpto = new System.Windows.Forms.ToolStripButton();
			this.btnCutDownto = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
			this.btnInputSec = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.lbPictureName = new System.Windows.Forms.ToolStripLabel();
			this.btnImport = new System.Windows.Forms.ToolStripButton();
			this.btnSelectPic = new System.Windows.Forms.ToolStripButton();
			this.btnPicOffset = new System.Windows.Forms.ToolStripButton();
			this.btnHideMemo = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
			this.btnAppendPage = new System.Windows.Forms.ToolStripButton();
			this.btnPageBreak = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
			this.lbCutCount = new System.Windows.Forms.ToolStripLabel();
			this.lbTotalSec = new System.Windows.Forms.ToolStripLabel();
			this.lbParCutSec = new System.Windows.Forms.ToolStripLabel();
			this.lbNoneDurationCut = new System.Windows.Forms.ToolStripLabel();
			this.lbTargetSec = new System.Windows.Forms.ToolStripLabel();
			this.lbCutAdd = new System.Windows.Forms.ToolStripLabel();
			this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.fileMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.nazBrowserMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.saveMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripSeparator();
			this.renameTakeMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.selectTakeMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.newTakeTMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripSeparator();
			this.pageSetupMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.printPreviewMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.printMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.savePrintToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem21 = new System.Windows.Forms.ToolStripSeparator();
			this.quitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.editMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.previewContMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripSeparator();
			this.findNoneDurationMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.LockNumberMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.unlockedNumberMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.trimPageMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem18 = new System.Windows.Forms.ToolStripSeparator();
			this.contSettingMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.pictureImportMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.extInstMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.picturMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.copyPictureLinkMenu1 = new System.Windows.Forms.ToolStripMenuItem();
			this.peastPictureLinkMenu1 = new System.Windows.Forms.ToolStripMenuItem();
			this.unlinkPictureMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
			this.importPictureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.selectPictureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.deletePictureFileMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripSeparator();
			this.makeThumbMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.remakeThumbAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.komaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.clearKomaMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.deleteKomaMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.insertKomaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.insertContinudToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.insertNoneNumberToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
			this.inputTimeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripSeparator();
			this.uptoKomaTMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.downtoKomaMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.cutMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.setCopyStartMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.copyCutMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.cutCutMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.peastCutMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripSeparator();
			this.deleteCutMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripSeparator();
			this.cutUptoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.cutDowntoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.pageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.appendPageMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.pageBreakToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
			this.topPageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.prevPageMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.nextPageMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.lastPageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
			this.partToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.partInfoMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripSeparator();
			this.editPartCaptionMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.partEndMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
			this.goPartStartToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.goPartEndToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem20 = new System.Windows.Forms.ToolStripSeparator();
			this.helpToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.PageScrol = new System.Windows.Forms.VScrollBar();
			this.KomaStatusMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.IsNoneNumberMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.isContinuedMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
			this.CopyPictureLinkMenu2 = new System.Windows.Forms.ToolStripMenuItem();
			this.peastPictureLinkMenu2 = new System.Windows.Forms.ToolStripMenuItem();
			this.incertContinedMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.insertCutMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.insertNoneNumberMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripSeparator();
			this.komaClearMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.komaDeleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.printDocument1 = new System.Drawing.Printing.PrintDocument();
			this.copyProgress1 = new ContEditorNazoh.CopyProgress();
			this.cutNumber1 = new ContEditorNazoh.CutNumber();
			this.contDocument1 = new ContEditorNazoh.ContDocument();
			this.cutSec1 = new ContEditorNazoh.CutSec();
			this.memoAndWords1 = new ContEditorNazoh.MemoAndWords();
			this.komaDraw1 = new ContEditorNazoh.KomaDraw();
			this.contPrint1 = new ContEditorNazoh.ContPrint();
			this.toolStrip1.SuspendLayout();
			this.menuStrip1.SuspendLayout();
			this.KomaStatusMenu.SuspendLayout();
			this.SuspendLayout();
			// 
			// toolStrip1
			// 
			this.toolStrip1.AutoSize = false;
			this.toolStrip1.BackColor = System.Drawing.Color.Transparent;
			this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Left;
			this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.OpenMenu,
            this.SaveBtn,
            this.toolStripSeparator4,
            this.lbCurrentPage,
            this.btnTopPage,
            this.btnPrevPage,
            this.btnNextPage,
            this.btnLastPage,
            this.toolStripSeparator2,
            this.btnKomaUpto,
            this.btnKomaDownto,
            this.btnCutUpto,
            this.btnCutDownto,
            this.toolStripSeparator6,
            this.btnInputSec,
            this.toolStripSeparator1,
            this.lbPictureName,
            this.btnImport,
            this.btnSelectPic,
            this.btnPicOffset,
            this.btnHideMemo,
            this.toolStripSeparator5,
            this.btnAppendPage,
            this.btnPageBreak,
            this.toolStripSeparator3,
            this.lbCutCount,
            this.lbTotalSec,
            this.lbParCutSec,
            this.lbNoneDurationCut,
            this.lbTargetSec,
            this.lbCutAdd,
            this.toolStripSeparator7});
			this.toolStrip1.Location = new System.Drawing.Point(0, 24);
			this.toolStrip1.Name = "toolStrip1";
			this.toolStrip1.Size = new System.Drawing.Size(107, 729);
			this.toolStrip1.TabIndex = 6;
			this.toolStrip1.Text = "toolStrip1";
			// 
			// OpenMenu
			// 
			this.OpenMenu.Image = global::ContEditorNazoh.Properties.Resources.openfolderHS;
			this.OpenMenu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.OpenMenu.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.OpenMenu.Name = "OpenMenu";
			this.OpenMenu.Size = new System.Drawing.Size(105, 20);
			this.OpenMenu.Text = "Nazブラウズ";
			this.OpenMenu.Click += new System.EventHandler(this.nazBrowserMenu_Click);
			// 
			// SaveBtn
			// 
			this.SaveBtn.Image = global::ContEditorNazoh.Properties.Resources.saveHS;
			this.SaveBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.SaveBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.SaveBtn.Name = "SaveBtn";
			this.SaveBtn.Size = new System.Drawing.Size(105, 20);
			this.SaveBtn.Text = "保存";
			this.SaveBtn.Click += new System.EventHandler(this.saveMenu_Click);
			// 
			// toolStripSeparator4
			// 
			this.toolStripSeparator4.Name = "toolStripSeparator4";
			this.toolStripSeparator4.Size = new System.Drawing.Size(105, 6);
			// 
			// lbCurrentPage
			// 
			this.lbCurrentPage.Name = "lbCurrentPage";
			this.lbCurrentPage.Size = new System.Drawing.Size(105, 12);
			this.lbCurrentPage.Text = "Now Page";
			// 
			// btnTopPage
			// 
			this.btnTopPage.Image = global::ContEditorNazoh.Properties.Resources.DataContainer_MoveFirstHS;
			this.btnTopPage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnTopPage.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnTopPage.Name = "btnTopPage";
			this.btnTopPage.Size = new System.Drawing.Size(105, 20);
			this.btnTopPage.Text = "最初のページへ";
			this.btnTopPage.Click += new System.EventHandler(this.btnTopPage_Click);
			// 
			// btnPrevPage
			// 
			this.btnPrevPage.Image = global::ContEditorNazoh.Properties.Resources.FillUpHS;
			this.btnPrevPage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnPrevPage.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnPrevPage.Name = "btnPrevPage";
			this.btnPrevPage.Size = new System.Drawing.Size(105, 20);
			this.btnPrevPage.Text = "前のページへ";
			this.btnPrevPage.Click += new System.EventHandler(this.btnPrevPage_Click);
			// 
			// btnNextPage
			// 
			this.btnNextPage.Image = global::ContEditorNazoh.Properties.Resources.FillDownHS;
			this.btnNextPage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnNextPage.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnNextPage.Name = "btnNextPage";
			this.btnNextPage.Size = new System.Drawing.Size(105, 20);
			this.btnNextPage.Text = "次のページへ";
			this.btnNextPage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnNextPage.Click += new System.EventHandler(this.btnNextPage_Click);
			// 
			// btnLastPage
			// 
			this.btnLastPage.Image = global::ContEditorNazoh.Properties.Resources.DataContainer_MoveLastHS;
			this.btnLastPage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLastPage.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnLastPage.Name = "btnLastPage";
			this.btnLastPage.Size = new System.Drawing.Size(105, 20);
			this.btnLastPage.Text = "最後のページへ";
			this.btnLastPage.Click += new System.EventHandler(this.btnLastPage_Click);
			// 
			// toolStripSeparator2
			// 
			this.toolStripSeparator2.Name = "toolStripSeparator2";
			this.toolStripSeparator2.Size = new System.Drawing.Size(105, 6);
			// 
			// btnKomaUpto
			// 
			this.btnKomaUpto.Image = global::ContEditorNazoh.Properties.Resources.DataContainer_MovePreviousHS;
			this.btnKomaUpto.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnKomaUpto.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnKomaUpto.Name = "btnKomaUpto";
			this.btnKomaUpto.Size = new System.Drawing.Size(105, 20);
			this.btnKomaUpto.Text = "コマを上へ";
			this.btnKomaUpto.Click += new System.EventHandler(this.btnKomaUpto_Click);
			// 
			// btnKomaDownto
			// 
			this.btnKomaDownto.Image = global::ContEditorNazoh.Properties.Resources.DataContainer_NewRecordHS;
			this.btnKomaDownto.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnKomaDownto.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnKomaDownto.Name = "btnKomaDownto";
			this.btnKomaDownto.Size = new System.Drawing.Size(105, 20);
			this.btnKomaDownto.Text = "コマを下へ";
			this.btnKomaDownto.Click += new System.EventHandler(this.btnKomaDownto_Click);
			// 
			// btnCutUpto
			// 
			this.btnCutUpto.Image = global::ContEditorNazoh.Properties.Resources.DoubleLeftArrowHS;
			this.btnCutUpto.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnCutUpto.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnCutUpto.Name = "btnCutUpto";
			this.btnCutUpto.Size = new System.Drawing.Size(105, 20);
			this.btnCutUpto.Text = "カットを上へ";
			this.btnCutUpto.Click += new System.EventHandler(this.btnCutUpto_Click);
			// 
			// btnCutDownto
			// 
			this.btnCutDownto.Image = global::ContEditorNazoh.Properties.Resources.DoubleRightArrowHS;
			this.btnCutDownto.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnCutDownto.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnCutDownto.Name = "btnCutDownto";
			this.btnCutDownto.Size = new System.Drawing.Size(105, 20);
			this.btnCutDownto.Text = "カットを下へ";
			this.btnCutDownto.Click += new System.EventHandler(this.btnCutDownto_Click);
			// 
			// toolStripSeparator6
			// 
			this.toolStripSeparator6.Name = "toolStripSeparator6";
			this.toolStripSeparator6.Size = new System.Drawing.Size(105, 6);
			// 
			// btnInputSec
			// 
			this.btnInputSec.Image = global::ContEditorNazoh.Properties.Resources.GetLatestVersion;
			this.btnInputSec.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnInputSec.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnInputSec.Name = "btnInputSec";
			this.btnInputSec.Size = new System.Drawing.Size(105, 20);
			this.btnInputSec.Text = "秒数";
			this.btnInputSec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnInputSec.Click += new System.EventHandler(this.cutSec1_DoubleClick);
			// 
			// toolStripSeparator1
			// 
			this.toolStripSeparator1.Name = "toolStripSeparator1";
			this.toolStripSeparator1.Size = new System.Drawing.Size(105, 6);
			// 
			// lbPictureName
			// 
			this.lbPictureName.Font = new System.Drawing.Font("MS UI Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
			this.lbPictureName.Name = "lbPictureName";
			this.lbPictureName.Size = new System.Drawing.Size(105, 11);
			this.lbPictureName.Text = "none";
			this.lbPictureName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// btnImport
			// 
			this.btnImport.Image = global::ContEditorNazoh.Properties.Resources.OpenFile;
			this.btnImport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnImport.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnImport.Name = "btnImport";
			this.btnImport.Size = new System.Drawing.Size(105, 20);
			this.btnImport.Text = "インポート";
			this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
			// 
			// btnSelectPic
			// 
			this.btnSelectPic.Image = global::ContEditorNazoh.Properties.Resources.WindowsHS;
			this.btnSelectPic.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnSelectPic.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnSelectPic.Name = "btnSelectPic";
			this.btnSelectPic.Size = new System.Drawing.Size(105, 20);
			this.btnSelectPic.Text = "選択";
			this.btnSelectPic.Click += new System.EventHandler(this.btnSelectPic_Click);
			// 
			// btnPicOffset
			// 
			this.btnPicOffset.Image = global::ContEditorNazoh.Properties.Resources.ShowRulerHS;
			this.btnPicOffset.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnPicOffset.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnPicOffset.Name = "btnPicOffset";
			this.btnPicOffset.Size = new System.Drawing.Size(105, 20);
			this.btnPicOffset.Text = "画像位置";
			this.btnPicOffset.Click += new System.EventHandler(this.btnPicOffset_Click);
			// 
			// btnHideMemo
			// 
			this.btnHideMemo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnHideMemo.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnHideMemo.Name = "btnHideMemo";
			this.btnHideMemo.Size = new System.Drawing.Size(105, 16);
			this.btnHideMemo.Text = "メモを一瞬非表示";
			this.btnHideMemo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnHideMemo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnHideMemo_MouseDown);
			this.btnHideMemo.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnHideMemo_MouseUp);
			// 
			// toolStripSeparator5
			// 
			this.toolStripSeparator5.Name = "toolStripSeparator5";
			this.toolStripSeparator5.Size = new System.Drawing.Size(105, 6);
			// 
			// btnAppendPage
			// 
			this.btnAppendPage.Image = global::ContEditorNazoh.Properties.Resources.DocumentHS;
			this.btnAppendPage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnAppendPage.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnAppendPage.Name = "btnAppendPage";
			this.btnAppendPage.Size = new System.Drawing.Size(105, 20);
			this.btnAppendPage.Text = "ページを追加";
			this.btnAppendPage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnAppendPage.Click += new System.EventHandler(this.appendPageMenu_Click);
			// 
			// btnPageBreak
			// 
			this.btnPageBreak.Image = global::ContEditorNazoh.Properties.Resources.RestartHS;
			this.btnPageBreak.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnPageBreak.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnPageBreak.Name = "btnPageBreak";
			this.btnPageBreak.Size = new System.Drawing.Size(105, 20);
			this.btnPageBreak.Text = "改ページ";
			this.btnPageBreak.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnPageBreak.Click += new System.EventHandler(this.btnPageBreak_Click);
			// 
			// toolStripSeparator3
			// 
			this.toolStripSeparator3.Name = "toolStripSeparator3";
			this.toolStripSeparator3.Size = new System.Drawing.Size(105, 6);
			// 
			// lbCutCount
			// 
			this.lbCutCount.Name = "lbCutCount";
			this.lbCutCount.Size = new System.Drawing.Size(105, 12);
			this.lbCutCount.Text = "Cut:";
			this.lbCutCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lbTotalSec
			// 
			this.lbTotalSec.Name = "lbTotalSec";
			this.lbTotalSec.Size = new System.Drawing.Size(105, 12);
			this.lbTotalSec.Text = "Total 0+0";
			this.lbTotalSec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lbParCutSec
			// 
			this.lbParCutSec.Name = "lbParCutSec";
			this.lbParCutSec.Size = new System.Drawing.Size(105, 12);
			this.lbParCutSec.Text = "ParCutSec";
			this.lbParCutSec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lbNoneDurationCut
			// 
			this.lbNoneDurationCut.Name = "lbNoneDurationCut";
			this.lbNoneDurationCut.Size = new System.Drawing.Size(105, 12);
			this.lbNoneDurationCut.Text = "NoneDuration";
			this.lbNoneDurationCut.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lbTargetSec
			// 
			this.lbTargetSec.Name = "lbTargetSec";
			this.lbTargetSec.Size = new System.Drawing.Size(105, 12);
			this.lbTargetSec.Text = "TargetSec";
			this.lbTargetSec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lbCutAdd
			// 
			this.lbCutAdd.Name = "lbCutAdd";
			this.lbCutAdd.Size = new System.Drawing.Size(105, 12);
			this.lbCutAdd.Text = "CutAdd";
			this.lbCutAdd.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// toolStripSeparator7
			// 
			this.toolStripSeparator7.Name = "toolStripSeparator7";
			this.toolStripSeparator7.Size = new System.Drawing.Size(105, 6);
			// 
			// menuStrip1
			// 
			this.menuStrip1.AutoSize = false;
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileMenu,
            this.editMenu,
            this.picturMenu,
            this.komaToolStripMenuItem,
            this.cutMenu,
            this.pageToolStripMenuItem,
            this.partToolStripMenuItem,
            this.helpToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(714, 24);
			this.menuStrip1.TabIndex = 7;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// fileMenu
			// 
			this.fileMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nazBrowserMenu,
            this.saveMenu,
            this.toolStripMenuItem10,
            this.renameTakeMenu,
            this.selectTakeMenu,
            this.newTakeTMenu,
            this.toolStripMenuItem9,
            this.pageSetupMenu,
            this.printPreviewMenu,
            this.printMenu,
            this.savePrintToolStripMenuItem,
            this.toolStripMenuItem21,
            this.quitToolStripMenuItem});
			this.fileMenu.Name = "fileMenu";
			this.fileMenu.Size = new System.Drawing.Size(51, 20);
			this.fileMenu.Text = "ファイル";
			// 
			// nazBrowserMenu
			// 
			this.nazBrowserMenu.Image = global::ContEditorNazoh.Properties.Resources.openfolderHS;
			this.nazBrowserMenu.Name = "nazBrowserMenu";
			this.nazBrowserMenu.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
			this.nazBrowserMenu.Size = new System.Drawing.Size(175, 22);
			this.nazBrowserMenu.Text = "Nazブラウズ";
			this.nazBrowserMenu.Click += new System.EventHandler(this.nazBrowserMenu_Click);
			// 
			// saveMenu
			// 
			this.saveMenu.Image = global::ContEditorNazoh.Properties.Resources.saveHS;
			this.saveMenu.Name = "saveMenu";
			this.saveMenu.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
			this.saveMenu.Size = new System.Drawing.Size(175, 22);
			this.saveMenu.Text = "保存";
			this.saveMenu.Click += new System.EventHandler(this.saveMenu_Click);
			// 
			// toolStripMenuItem10
			// 
			this.toolStripMenuItem10.Name = "toolStripMenuItem10";
			this.toolStripMenuItem10.Size = new System.Drawing.Size(172, 6);
			// 
			// renameTakeMenu
			// 
			this.renameTakeMenu.Name = "renameTakeMenu";
			this.renameTakeMenu.Size = new System.Drawing.Size(175, 22);
			this.renameTakeMenu.Text = "現在のテイク名を変更";
			this.renameTakeMenu.Click += new System.EventHandler(this.renameTakeMenu_Click);
			// 
			// selectTakeMenu
			// 
			this.selectTakeMenu.Name = "selectTakeMenu";
			this.selectTakeMenu.Size = new System.Drawing.Size(175, 22);
			this.selectTakeMenu.Text = "テイクを選択";
			this.selectTakeMenu.Click += new System.EventHandler(this.selectTakeMenu_Click);
			// 
			// newTakeTMenu
			// 
			this.newTakeTMenu.Name = "newTakeTMenu";
			this.newTakeTMenu.Size = new System.Drawing.Size(175, 22);
			this.newTakeTMenu.Text = "新しいテイクを作成";
			this.newTakeTMenu.Click += new System.EventHandler(this.newTakeTMenu_Click);
			// 
			// toolStripMenuItem9
			// 
			this.toolStripMenuItem9.Name = "toolStripMenuItem9";
			this.toolStripMenuItem9.Size = new System.Drawing.Size(172, 6);
			// 
			// pageSetupMenu
			// 
			this.pageSetupMenu.Name = "pageSetupMenu";
			this.pageSetupMenu.Size = new System.Drawing.Size(175, 22);
			this.pageSetupMenu.Text = "ページ設定";
			this.pageSetupMenu.Click += new System.EventHandler(this.pageSetupMenu_Click);
			// 
			// printPreviewMenu
			// 
			this.printPreviewMenu.Name = "printPreviewMenu";
			this.printPreviewMenu.Size = new System.Drawing.Size(175, 22);
			this.printPreviewMenu.Text = "印刷プレビュー";
			this.printPreviewMenu.Click += new System.EventHandler(this.printPreviewMenu_Click);
			// 
			// printMenu
			// 
			this.printMenu.Name = "printMenu";
			this.printMenu.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
			this.printMenu.Size = new System.Drawing.Size(175, 22);
			this.printMenu.Text = "Print";
			this.printMenu.Click += new System.EventHandler(this.printMenu_Click);
			// 
			// savePrintToolStripMenuItem
			// 
			this.savePrintToolStripMenuItem.Name = "savePrintToolStripMenuItem";
			this.savePrintToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
			this.savePrintToolStripMenuItem.Text = "印刷イメージの保存";
			this.savePrintToolStripMenuItem.Click += new System.EventHandler(this.savePrintToolStripMenuItem_Click);
			// 
			// toolStripMenuItem21
			// 
			this.toolStripMenuItem21.Name = "toolStripMenuItem21";
			this.toolStripMenuItem21.Size = new System.Drawing.Size(172, 6);
			// 
			// quitToolStripMenuItem
			// 
			this.quitToolStripMenuItem.Name = "quitToolStripMenuItem";
			this.quitToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Q)));
			this.quitToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
			this.quitToolStripMenuItem.Text = "終了";
			// 
			// editMenu
			// 
			this.editMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.previewContMenu,
            this.toolStripMenuItem8,
            this.findNoneDurationMenu,
            this.LockNumberMenu,
            this.unlockedNumberMenu,
            this.trimPageMenu,
            this.toolStripMenuItem18,
            this.contSettingMenu,
            this.pictureImportMenu,
            this.extInstMenu});
			this.editMenu.Name = "editMenu";
			this.editMenu.Size = new System.Drawing.Size(41, 20);
			this.editMenu.Text = "編集";
			// 
			// previewContMenu
			// 
			this.previewContMenu.Name = "previewContMenu";
			this.previewContMenu.ShortcutKeys = System.Windows.Forms.Keys.F1;
			this.previewContMenu.Size = new System.Drawing.Size(205, 22);
			this.previewContMenu.Text = "コンテのプレビュー";
			this.previewContMenu.Click += new System.EventHandler(this.previewContMenu_Click);
			// 
			// toolStripMenuItem8
			// 
			this.toolStripMenuItem8.Name = "toolStripMenuItem8";
			this.toolStripMenuItem8.Size = new System.Drawing.Size(202, 6);
			// 
			// findNoneDurationMenu
			// 
			this.findNoneDurationMenu.Name = "findNoneDurationMenu";
			this.findNoneDurationMenu.Size = new System.Drawing.Size(205, 22);
			this.findNoneDurationMenu.Text = "秒数が無指定なカットを探す";
			this.findNoneDurationMenu.Click += new System.EventHandler(this.findNoneDurationMenu_Click);
			// 
			// LockNumberMenu
			// 
			this.LockNumberMenu.Name = "LockNumberMenu";
			this.LockNumberMenu.Size = new System.Drawing.Size(205, 22);
			this.LockNumberMenu.Text = "カットナンバーをすべて固定";
			this.LockNumberMenu.Click += new System.EventHandler(this.cutNumberLockMenu_Click);
			// 
			// unlockedNumberMenu
			// 
			this.unlockedNumberMenu.Name = "unlockedNumberMenu";
			this.unlockedNumberMenu.Size = new System.Drawing.Size(205, 22);
			this.unlockedNumberMenu.Text = "カット番号の固定化の解除";
			this.unlockedNumberMenu.Click += new System.EventHandler(this.unlockedNumberMenu_Click);
			// 
			// trimPageMenu
			// 
			this.trimPageMenu.Name = "trimPageMenu";
			this.trimPageMenu.Size = new System.Drawing.Size(205, 22);
			this.trimPageMenu.Text = "末尾の空白ページを削除";
			this.trimPageMenu.Click += new System.EventHandler(this.trimPageMenu_Click);
			// 
			// toolStripMenuItem18
			// 
			this.toolStripMenuItem18.Name = "toolStripMenuItem18";
			this.toolStripMenuItem18.Size = new System.Drawing.Size(202, 6);
			// 
			// contSettingMenu
			// 
			this.contSettingMenu.Name = "contSettingMenu";
			this.contSettingMenu.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.K)));
			this.contSettingMenu.Size = new System.Drawing.Size(205, 22);
			this.contSettingMenu.Text = "コンテの情報";
			this.contSettingMenu.Click += new System.EventHandler(this.contSettingMenu_Click);
			// 
			// pictureImportMenu
			// 
			this.pictureImportMenu.Name = "pictureImportMenu";
			this.pictureImportMenu.Size = new System.Drawing.Size(205, 22);
			this.pictureImportMenu.Text = "画像インポート設定";
			this.pictureImportMenu.Click += new System.EventHandler(this.pictureImportMenu_Click);
			// 
			// extInstMenu
			// 
			this.extInstMenu.Name = "extInstMenu";
			this.extInstMenu.Size = new System.Drawing.Size(205, 22);
			this.extInstMenu.Text = "拡張子の登録";
			this.extInstMenu.Click += new System.EventHandler(this.extInstMenu_Click);
			// 
			// picturMenu
			// 
			this.picturMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyPictureLinkMenu1,
            this.peastPictureLinkMenu1,
            this.unlinkPictureMenu,
            this.toolStripMenuItem4,
            this.importPictureToolStripMenuItem,
            this.selectPictureToolStripMenuItem,
            this.deletePictureFileMenu,
            this.toolStripMenuItem12,
            this.makeThumbMenu,
            this.remakeThumbAllToolStripMenuItem});
			this.picturMenu.Name = "picturMenu";
			this.picturMenu.Size = new System.Drawing.Size(41, 20);
			this.picturMenu.Text = "画像";
			this.picturMenu.Click += new System.EventHandler(this.picturMenu_Click);
			// 
			// copyPictureLinkMenu1
			// 
			this.copyPictureLinkMenu1.Name = "copyPictureLinkMenu1";
			this.copyPictureLinkMenu1.Size = new System.Drawing.Size(194, 22);
			this.copyPictureLinkMenu1.Text = "画像のLinkをコピー";
			this.copyPictureLinkMenu1.Click += new System.EventHandler(this.copyPictureLink_Click);
			// 
			// peastPictureLinkMenu1
			// 
			this.peastPictureLinkMenu1.Enabled = false;
			this.peastPictureLinkMenu1.Name = "peastPictureLinkMenu1";
			this.peastPictureLinkMenu1.Size = new System.Drawing.Size(194, 22);
			this.peastPictureLinkMenu1.Text = "画像のLinkを貼り付け";
			this.peastPictureLinkMenu1.Click += new System.EventHandler(this.peastPictureLink_Click);
			// 
			// unlinkPictureMenu
			// 
			this.unlinkPictureMenu.Name = "unlinkPictureMenu";
			this.unlinkPictureMenu.Size = new System.Drawing.Size(194, 22);
			this.unlinkPictureMenu.Text = "画像のLinkを消去";
			this.unlinkPictureMenu.Click += new System.EventHandler(this.unlinkPictureMenu_Click);
			// 
			// toolStripMenuItem4
			// 
			this.toolStripMenuItem4.Name = "toolStripMenuItem4";
			this.toolStripMenuItem4.Size = new System.Drawing.Size(191, 6);
			// 
			// importPictureToolStripMenuItem
			// 
			this.importPictureToolStripMenuItem.Name = "importPictureToolStripMenuItem";
			this.importPictureToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
			this.importPictureToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
			this.importPictureToolStripMenuItem.Text = "画像をインポート";
			this.importPictureToolStripMenuItem.Click += new System.EventHandler(this.btnImport_Click);
			// 
			// selectPictureToolStripMenuItem
			// 
			this.selectPictureToolStripMenuItem.Name = "selectPictureToolStripMenuItem";
			this.selectPictureToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
						| System.Windows.Forms.Keys.S)));
			this.selectPictureToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
			this.selectPictureToolStripMenuItem.Text = "画像を選択";
			this.selectPictureToolStripMenuItem.Click += new System.EventHandler(this.btnSelectPic_Click);
			// 
			// deletePictureFileMenu
			// 
			this.deletePictureFileMenu.Name = "deletePictureFileMenu";
			this.deletePictureFileMenu.Size = new System.Drawing.Size(194, 22);
			this.deletePictureFileMenu.Text = "画像ファイルを削除";
			this.deletePictureFileMenu.Click += new System.EventHandler(this.deletePictureFileMenu_Click);
			// 
			// toolStripMenuItem12
			// 
			this.toolStripMenuItem12.Name = "toolStripMenuItem12";
			this.toolStripMenuItem12.Size = new System.Drawing.Size(191, 6);
			// 
			// makeThumbMenu
			// 
			this.makeThumbMenu.Name = "makeThumbMenu";
			this.makeThumbMenu.Size = new System.Drawing.Size(194, 22);
			this.makeThumbMenu.Text = "サムネイルを再作成";
			this.makeThumbMenu.Click += new System.EventHandler(this.makeThumbMenu_Click);
			// 
			// remakeThumbAllToolStripMenuItem
			// 
			this.remakeThumbAllToolStripMenuItem.Name = "remakeThumbAllToolStripMenuItem";
			this.remakeThumbAllToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
			this.remakeThumbAllToolStripMenuItem.Text = "サムネイルをすべて再作成";
			this.remakeThumbAllToolStripMenuItem.Click += new System.EventHandler(this.remakeThumbAllToolStripMenuItem_Click);
			// 
			// komaToolStripMenuItem
			// 
			this.komaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clearKomaMenu,
            this.deleteKomaMenu,
            this.insertKomaToolStripMenuItem,
            this.insertContinudToolStripMenuItem,
            this.insertNoneNumberToolStripMenuItem,
            this.toolStripMenuItem3,
            this.inputTimeToolStripMenuItem,
            this.toolStripMenuItem7,
            this.uptoKomaTMenu,
            this.downtoKomaMenu});
			this.komaToolStripMenuItem.Name = "komaToolStripMenuItem";
			this.komaToolStripMenuItem.Size = new System.Drawing.Size(34, 20);
			this.komaToolStripMenuItem.Text = "コマ";
			// 
			// clearKomaMenu
			// 
			this.clearKomaMenu.Name = "clearKomaMenu";
			this.clearKomaMenu.Size = new System.Drawing.Size(210, 22);
			this.clearKomaMenu.Text = "コマをクリア";
			this.clearKomaMenu.Click += new System.EventHandler(this.clearKomaMenu_Click);
			// 
			// deleteKomaMenu
			// 
			this.deleteKomaMenu.Name = "deleteKomaMenu";
			this.deleteKomaMenu.Size = new System.Drawing.Size(210, 22);
			this.deleteKomaMenu.Text = "コマを削除";
			this.deleteKomaMenu.Click += new System.EventHandler(this.deleteKomaMenu_Click);
			// 
			// insertKomaToolStripMenuItem
			// 
			this.insertKomaToolStripMenuItem.Name = "insertKomaToolStripMenuItem";
			this.insertKomaToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
			this.insertKomaToolStripMenuItem.Text = "新しいカットを挿入";
			this.insertKomaToolStripMenuItem.Click += new System.EventHandler(this.insertCutMenu_Click);
			// 
			// insertContinudToolStripMenuItem
			// 
			this.insertContinudToolStripMenuItem.Name = "insertContinudToolStripMenuItem";
			this.insertContinudToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
			this.insertContinudToolStripMenuItem.Text = "カットにコマを追加";
			this.insertContinudToolStripMenuItem.Click += new System.EventHandler(this.incertContinedMenu_Click);
			// 
			// insertNoneNumberToolStripMenuItem
			// 
			this.insertNoneNumberToolStripMenuItem.Name = "insertNoneNumberToolStripMenuItem";
			this.insertNoneNumberToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
			this.insertNoneNumberToolStripMenuItem.Text = "番号無しのコマを挿入";
			this.insertNoneNumberToolStripMenuItem.Click += new System.EventHandler(this.insertNoneNumberMenu_Click);
			// 
			// toolStripMenuItem3
			// 
			this.toolStripMenuItem3.Name = "toolStripMenuItem3";
			this.toolStripMenuItem3.Size = new System.Drawing.Size(207, 6);
			// 
			// inputTimeToolStripMenuItem
			// 
			this.inputTimeToolStripMenuItem.Name = "inputTimeToolStripMenuItem";
			this.inputTimeToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
			this.inputTimeToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
			this.inputTimeToolStripMenuItem.Text = "秒数を変更...";
			this.inputTimeToolStripMenuItem.Click += new System.EventHandler(this.cutSec1_DoubleClick);
			// 
			// toolStripMenuItem7
			// 
			this.toolStripMenuItem7.Name = "toolStripMenuItem7";
			this.toolStripMenuItem7.Size = new System.Drawing.Size(207, 6);
			// 
			// uptoKomaTMenu
			// 
			this.uptoKomaTMenu.Name = "uptoKomaTMenu";
			this.uptoKomaTMenu.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
						| System.Windows.Forms.Keys.B)));
			this.uptoKomaTMenu.Size = new System.Drawing.Size(210, 22);
			this.uptoKomaTMenu.Text = "コマを上に移動";
			this.uptoKomaTMenu.Click += new System.EventHandler(this.btnKomaUpto_Click);
			// 
			// downtoKomaMenu
			// 
			this.downtoKomaMenu.Name = "downtoKomaMenu";
			this.downtoKomaMenu.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
						| System.Windows.Forms.Keys.N)));
			this.downtoKomaMenu.Size = new System.Drawing.Size(210, 22);
			this.downtoKomaMenu.Text = "コマを下へ移動";
			this.downtoKomaMenu.Click += new System.EventHandler(this.btnKomaDownto_Click);
			// 
			// cutMenu
			// 
			this.cutMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.setCopyStartMenu,
            this.copyCutMenu,
            this.cutCutMenu,
            this.peastCutMenu,
            this.toolStripMenuItem16,
            this.deleteCutMenu,
            this.toolStripMenuItem13,
            this.cutUptoToolStripMenuItem,
            this.cutDowntoToolStripMenuItem});
			this.cutMenu.Name = "cutMenu";
			this.cutMenu.Size = new System.Drawing.Size(41, 20);
			this.cutMenu.Text = "カット";
			this.cutMenu.MouseEnter += new System.EventHandler(this.cutMenu_MouseEnter);
			// 
			// setCopyStartMenu
			// 
			this.setCopyStartMenu.Name = "setCopyStartMenu";
			this.setCopyStartMenu.Size = new System.Drawing.Size(208, 22);
			this.setCopyStartMenu.Text = "SetCopyStart";
			this.setCopyStartMenu.Click += new System.EventHandler(this.setCopyStartMenu_Click);
			// 
			// copyCutMenu
			// 
			this.copyCutMenu.Name = "copyCutMenu";
			this.copyCutMenu.Size = new System.Drawing.Size(208, 22);
			this.copyCutMenu.Text = "カットを複写";
			this.copyCutMenu.Click += new System.EventHandler(this.copyCutMenu_Click);
			// 
			// cutCutMenu
			// 
			this.cutCutMenu.Name = "cutCutMenu";
			this.cutCutMenu.Size = new System.Drawing.Size(208, 22);
			this.cutCutMenu.Text = "カットを切り取り";
			this.cutCutMenu.Click += new System.EventHandler(this.cutCutMenu_Click);
			// 
			// peastCutMenu
			// 
			this.peastCutMenu.Enabled = false;
			this.peastCutMenu.Name = "peastCutMenu";
			this.peastCutMenu.Size = new System.Drawing.Size(208, 22);
			this.peastCutMenu.Text = "カットを貼り付け";
			this.peastCutMenu.Click += new System.EventHandler(this.peastCutMenu_Click);
			// 
			// toolStripMenuItem16
			// 
			this.toolStripMenuItem16.Name = "toolStripMenuItem16";
			this.toolStripMenuItem16.Size = new System.Drawing.Size(205, 6);
			// 
			// deleteCutMenu
			// 
			this.deleteCutMenu.Name = "deleteCutMenu";
			this.deleteCutMenu.Size = new System.Drawing.Size(208, 22);
			this.deleteCutMenu.Text = "カットを削除";
			this.deleteCutMenu.Click += new System.EventHandler(this.deleteCutMenu_Click);
			// 
			// toolStripMenuItem13
			// 
			this.toolStripMenuItem13.Name = "toolStripMenuItem13";
			this.toolStripMenuItem13.Size = new System.Drawing.Size(205, 6);
			// 
			// cutUptoToolStripMenuItem
			// 
			this.cutUptoToolStripMenuItem.Name = "cutUptoToolStripMenuItem";
			this.cutUptoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Alt)
						| System.Windows.Forms.Keys.B)));
			this.cutUptoToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
			this.cutUptoToolStripMenuItem.Text = "カットを上へ移動";
			this.cutUptoToolStripMenuItem.Click += new System.EventHandler(this.btnCutUpto_Click);
			// 
			// cutDowntoToolStripMenuItem
			// 
			this.cutDowntoToolStripMenuItem.Name = "cutDowntoToolStripMenuItem";
			this.cutDowntoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Alt)
						| System.Windows.Forms.Keys.N)));
			this.cutDowntoToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
			this.cutDowntoToolStripMenuItem.Text = "カットを下へ移動";
			this.cutDowntoToolStripMenuItem.Click += new System.EventHandler(this.btnCutDownto_Click);
			// 
			// pageToolStripMenuItem
			// 
			this.pageToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.appendPageMenu,
            this.pageBreakToolStripMenuItem,
            this.toolStripMenuItem2,
            this.topPageToolStripMenuItem,
            this.prevPageMenu,
            this.nextPageMenu,
            this.lastPageToolStripMenuItem,
            this.toolStripMenuItem5});
			this.pageToolStripMenuItem.Name = "pageToolStripMenuItem";
			this.pageToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
			this.pageToolStripMenuItem.Text = "ページ";
			// 
			// appendPageMenu
			// 
			this.appendPageMenu.Name = "appendPageMenu";
			this.appendPageMenu.Size = new System.Drawing.Size(222, 22);
			this.appendPageMenu.Text = "ページを追加";
			this.appendPageMenu.Click += new System.EventHandler(this.appendPageMenu_Click);
			// 
			// pageBreakToolStripMenuItem
			// 
			this.pageBreakToolStripMenuItem.Name = "pageBreakToolStripMenuItem";
			this.pageBreakToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
			this.pageBreakToolStripMenuItem.Text = "改ページ";
			this.pageBreakToolStripMenuItem.Click += new System.EventHandler(this.btnPageBreak_Click);
			// 
			// toolStripMenuItem2
			// 
			this.toolStripMenuItem2.Name = "toolStripMenuItem2";
			this.toolStripMenuItem2.Size = new System.Drawing.Size(219, 6);
			// 
			// topPageToolStripMenuItem
			// 
			this.topPageToolStripMenuItem.Name = "topPageToolStripMenuItem";
			this.topPageToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.NumPad1)));
			this.topPageToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
			this.topPageToolStripMenuItem.Text = "最初のページへ";
			this.topPageToolStripMenuItem.Click += new System.EventHandler(this.btnTopPage_Click);
			// 
			// prevPageMenu
			// 
			this.prevPageMenu.Name = "prevPageMenu";
			this.prevPageMenu.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Up)));
			this.prevPageMenu.Size = new System.Drawing.Size(222, 22);
			this.prevPageMenu.Text = "前のページへ";
			this.prevPageMenu.Click += new System.EventHandler(this.btnPrevPage_Click);
			// 
			// nextPageMenu
			// 
			this.nextPageMenu.Name = "nextPageMenu";
			this.nextPageMenu.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Down)));
			this.nextPageMenu.Size = new System.Drawing.Size(222, 22);
			this.nextPageMenu.Text = "次のページへ";
			this.nextPageMenu.Click += new System.EventHandler(this.btnNextPage_Click);
			// 
			// lastPageToolStripMenuItem
			// 
			this.lastPageToolStripMenuItem.Name = "lastPageToolStripMenuItem";
			this.lastPageToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.NumPad0)));
			this.lastPageToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
			this.lastPageToolStripMenuItem.Text = "最後のページへ";
			this.lastPageToolStripMenuItem.Click += new System.EventHandler(this.btnLastPage_Click);
			// 
			// toolStripMenuItem5
			// 
			this.toolStripMenuItem5.Name = "toolStripMenuItem5";
			this.toolStripMenuItem5.Size = new System.Drawing.Size(219, 6);
			// 
			// partToolStripMenuItem
			// 
			this.partToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.partInfoMenu,
            this.toolStripMenuItem11,
            this.editPartCaptionMenu,
            this.partEndMenu,
            this.toolStripMenuItem6,
            this.goPartStartToolStripMenuItem,
            this.goPartEndToolStripMenuItem});
			this.partToolStripMenuItem.Name = "partToolStripMenuItem";
			this.partToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
			this.partToolStripMenuItem.Text = "パート";
			this.partToolStripMenuItem.MouseEnter += new System.EventHandler(this.partMenu_MouseEnter);
			// 
			// partInfoMenu
			// 
			this.partInfoMenu.Name = "partInfoMenu";
			this.partInfoMenu.Size = new System.Drawing.Size(171, 22);
			this.partInfoMenu.Text = "パート情報パレット";
			this.partInfoMenu.Click += new System.EventHandler(this.partInfoMenu_Click);
			// 
			// toolStripMenuItem11
			// 
			this.toolStripMenuItem11.Name = "toolStripMenuItem11";
			this.toolStripMenuItem11.Size = new System.Drawing.Size(168, 6);
			// 
			// editPartCaptionMenu
			// 
			this.editPartCaptionMenu.Name = "editPartCaptionMenu";
			this.editPartCaptionMenu.Size = new System.Drawing.Size(171, 22);
			this.editPartCaptionMenu.Text = "パート名の編集";
			this.editPartCaptionMenu.Click += new System.EventHandler(this.editPartCaptionMenu_Click);
			// 
			// partEndMenu
			// 
			this.partEndMenu.Name = "partEndMenu";
			this.partEndMenu.Size = new System.Drawing.Size(171, 22);
			this.partEndMenu.Text = "パートの終わりを設定";
			this.partEndMenu.Click += new System.EventHandler(this.partEndMenu_Click);
			// 
			// toolStripMenuItem6
			// 
			this.toolStripMenuItem6.Name = "toolStripMenuItem6";
			this.toolStripMenuItem6.Size = new System.Drawing.Size(168, 6);
			// 
			// goPartStartToolStripMenuItem
			// 
			this.goPartStartToolStripMenuItem.Name = "goPartStartToolStripMenuItem";
			this.goPartStartToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
			this.goPartStartToolStripMenuItem.Text = "パート頭へ移動";
			this.goPartStartToolStripMenuItem.Click += new System.EventHandler(this.goPartStartToolStripMenuItem_Click);
			// 
			// goPartEndToolStripMenuItem
			// 
			this.goPartEndToolStripMenuItem.Name = "goPartEndToolStripMenuItem";
			this.goPartEndToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
			this.goPartEndToolStripMenuItem.Text = "パート終わりに移動";
			this.goPartEndToolStripMenuItem.Click += new System.EventHandler(this.goPartEndToolStripMenuItem_Click);
			// 
			// helpToolStripMenuItem
			// 
			this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem,
            this.toolStripMenuItem20,
            this.helpToolStripMenuItem1});
			this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
			this.helpToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
			this.helpToolStripMenuItem.Text = "Help";
			// 
			// aboutToolStripMenuItem
			// 
			this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
			this.aboutToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
			this.aboutToolStripMenuItem.Text = "About Nazoh! ";
			this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
			// 
			// toolStripMenuItem20
			// 
			this.toolStripMenuItem20.Name = "toolStripMenuItem20";
			this.toolStripMenuItem20.Size = new System.Drawing.Size(139, 6);
			// 
			// helpToolStripMenuItem1
			// 
			this.helpToolStripMenuItem1.Enabled = false;
			this.helpToolStripMenuItem1.Name = "helpToolStripMenuItem1";
			this.helpToolStripMenuItem1.Size = new System.Drawing.Size(142, 22);
			this.helpToolStripMenuItem1.Text = "Help";
			this.helpToolStripMenuItem1.Click += new System.EventHandler(this.helpToolStripMenuItem1_Click);
			// 
			// PageScrol
			// 
			this.PageScrol.LargeChange = 1;
			this.PageScrol.Location = new System.Drawing.Point(692, 27);
			this.PageScrol.Name = "PageScrol";
			this.PageScrol.Size = new System.Drawing.Size(22, 717);
			this.PageScrol.TabIndex = 8;
			this.PageScrol.ValueChanged += new System.EventHandler(this.PageScrol_ValueChanged);
			// 
			// KomaStatusMenu
			// 
			this.KomaStatusMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.IsNoneNumberMenu,
            this.isContinuedMenu,
            this.toolStripMenuItem1,
            this.CopyPictureLinkMenu2,
            this.peastPictureLinkMenu2,
            this.incertContinedMenu,
            this.insertCutMenu,
            this.insertNoneNumberMenu,
            this.toolStripMenuItem14,
            this.komaClearMenu,
            this.komaDeleteToolStripMenuItem});
			this.KomaStatusMenu.Name = "contextMenuStrip1";
			this.KomaStatusMenu.Size = new System.Drawing.Size(191, 214);
			this.KomaStatusMenu.Opening += new System.ComponentModel.CancelEventHandler(this.KomaStatusMenu_Opening);
			// 
			// IsNoneNumberMenu
			// 
			this.IsNoneNumberMenu.Name = "IsNoneNumberMenu";
			this.IsNoneNumberMenu.Size = new System.Drawing.Size(190, 22);
			this.IsNoneNumberMenu.Text = "番号無しのコマ";
			this.IsNoneNumberMenu.Click += new System.EventHandler(this.IsNoneNumberMenu_Click);
			// 
			// isContinuedMenu
			// 
			this.isContinuedMenu.Name = "isContinuedMenu";
			this.isContinuedMenu.Size = new System.Drawing.Size(190, 22);
			this.isContinuedMenu.Text = "前と同じカット";
			this.isContinuedMenu.Click += new System.EventHandler(this.isContinuedMenu_Click);
			// 
			// toolStripMenuItem1
			// 
			this.toolStripMenuItem1.Name = "toolStripMenuItem1";
			this.toolStripMenuItem1.Size = new System.Drawing.Size(187, 6);
			// 
			// CopyPictureLinkMenu2
			// 
			this.CopyPictureLinkMenu2.Name = "CopyPictureLinkMenu2";
			this.CopyPictureLinkMenu2.Size = new System.Drawing.Size(190, 22);
			this.CopyPictureLinkMenu2.Text = "画像のLinkをコピー";
			this.CopyPictureLinkMenu2.Click += new System.EventHandler(this.copyPictureLink_Click);
			// 
			// peastPictureLinkMenu2
			// 
			this.peastPictureLinkMenu2.Enabled = false;
			this.peastPictureLinkMenu2.Name = "peastPictureLinkMenu2";
			this.peastPictureLinkMenu2.Size = new System.Drawing.Size(190, 22);
			this.peastPictureLinkMenu2.Text = "画像のLinkを貼り付け";
			this.peastPictureLinkMenu2.Click += new System.EventHandler(this.peastPictureLink_Click);
			// 
			// incertContinedMenu
			// 
			this.incertContinedMenu.Name = "incertContinedMenu";
			this.incertContinedMenu.Size = new System.Drawing.Size(190, 22);
			this.incertContinedMenu.Text = "カットにコマを追加";
			this.incertContinedMenu.Click += new System.EventHandler(this.incertContinedMenu_Click);
			// 
			// insertCutMenu
			// 
			this.insertCutMenu.Name = "insertCutMenu";
			this.insertCutMenu.Size = new System.Drawing.Size(190, 22);
			this.insertCutMenu.Text = "新しいカットを挿入";
			this.insertCutMenu.Click += new System.EventHandler(this.insertCutMenu_Click);
			// 
			// insertNoneNumberMenu
			// 
			this.insertNoneNumberMenu.Name = "insertNoneNumberMenu";
			this.insertNoneNumberMenu.Size = new System.Drawing.Size(190, 22);
			this.insertNoneNumberMenu.Text = "ナンバー無しのコマを挿入";
			this.insertNoneNumberMenu.Click += new System.EventHandler(this.insertNoneNumberMenu_Click);
			// 
			// toolStripMenuItem14
			// 
			this.toolStripMenuItem14.Name = "toolStripMenuItem14";
			this.toolStripMenuItem14.Size = new System.Drawing.Size(187, 6);
			// 
			// komaClearMenu
			// 
			this.komaClearMenu.Name = "komaClearMenu";
			this.komaClearMenu.Size = new System.Drawing.Size(190, 22);
			this.komaClearMenu.Text = "コマをクリアに";
			this.komaClearMenu.Click += new System.EventHandler(this.clearKomaMenu_Click);
			// 
			// komaDeleteToolStripMenuItem
			// 
			this.komaDeleteToolStripMenuItem.Name = "komaDeleteToolStripMenuItem";
			this.komaDeleteToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
			this.komaDeleteToolStripMenuItem.Text = "コマを削除";
			this.komaDeleteToolStripMenuItem.Click += new System.EventHandler(this.deleteKomaMenu_Click);
			// 
			// copyProgress1
			// 
			this.copyProgress1.BackColor = System.Drawing.Color.Transparent;
			this.copyProgress1.Info = "label1";
			this.copyProgress1.Location = new System.Drawing.Point(173, 361);
			this.copyProgress1.MaximumSize = new System.Drawing.Size(239, 57);
			this.copyProgress1.MaxValue = 100;
			this.copyProgress1.MinimumSize = new System.Drawing.Size(239, 57);
			this.copyProgress1.MinValue = 0;
			this.copyProgress1.Name = "copyProgress1";
			this.copyProgress1.Size = new System.Drawing.Size(239, 57);
			this.copyProgress1.TabIndex = 9;
			this.copyProgress1.Value = 0;
			this.copyProgress1.Visible = false;
			// 
			// cutNumber1
			// 
			this.cutNumber1.BackColor = System.Drawing.Color.Transparent;
			this.cutNumber1.ContDocument = this.contDocument1;
			this.cutNumber1.ContextMenuStrip = this.KomaStatusMenu;
			this.cutNumber1.Cursor = System.Windows.Forms.Cursors.Default;
			this.cutNumber1.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
			this.cutNumber1.Location = new System.Drawing.Point(110, 27);
			this.cutNumber1.MaximumSize = new System.Drawing.Size(50, 720);
			this.cutNumber1.MinimumSize = new System.Drawing.Size(50, 720);
			this.cutNumber1.Name = "cutNumber1";
			this.cutNumber1.Size = new System.Drawing.Size(50, 720);
			this.cutNumber1.TabIndex = 3;
			this.cutNumber1.Text = "cutNumber1";
			this.cutNumber1.DoubleClick += new System.EventHandler(this.cutNumber1_DoubleClick);
			// 
			// contDocument1
			// 
			this.contDocument1.CurrentPage = 0;
			this.contDocument1.fps = 24F;
			this.contDocument1.ImportResize = ContEditorNazoh.ImportResize.none;
			this.contDocument1.IsContinued = false;
			this.contDocument1.IsNoneNumber = false;
			this.contDocument1.IsPageBreak = false;
			this.contDocument1.IsPartEnd = false;
			this.contDocument1.IsPrintCampany = true;
			this.contDocument1.IsPrintDurationInfo = false;
			this.contDocument1.IsPrintOPUS = false;
			this.contDocument1.IsPrintPartCaption = false;
			this.contDocument1.IsPrintSubTitle = false;
			this.contDocument1.IsPrintTitle = false;
			this.contDocument1.Locked = false;
			this.contDocument1.NazDir = "";
			this.contDocument1.NumberStart = 1;
			this.contDocument1.PageNumberStart = 0;
			this.contDocument1.PartCaptionsLine = "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,OP,ED,アバン,予告,";
			this.contDocument1.Pic = null;
			this.contDocument1.PicSub = null;
			this.contDocument1.SelectedIndex = -1;
			this.contDocument1.TargetDuration = 0F;
			this.contDocument1.Version = ContEditorNazoh.ContVersion.First;
			this.contDocument1.SelectedIndexChanged += new System.EventHandler(this.contDocument1_SelectedIndexChanged);
			this.contDocument1.komaChanged += new System.EventHandler(this.contDocument1_komaChanged_1);
			// 
			// cutSec1
			// 
			this.cutSec1.BackColor = System.Drawing.Color.Transparent;
			this.cutSec1.ContDocument = this.contDocument1;
			this.cutSec1.ContextMenuStrip = this.KomaStatusMenu;
			this.cutSec1.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
			this.cutSec1.Location = new System.Drawing.Point(627, 27);
			this.cutSec1.MaximumSize = new System.Drawing.Size(60, 720);
			this.cutSec1.MinimumSize = new System.Drawing.Size(60, 720);
			this.cutSec1.Name = "cutSec1";
			this.cutSec1.Size = new System.Drawing.Size(60, 720);
			this.cutSec1.TabIndex = 5;
			this.cutSec1.Text = "cutSec1";
			this.cutSec1.DoubleClick += new System.EventHandler(this.cutSec1_DoubleClick);
			// 
			// memoAndWords1
			// 
			this.memoAndWords1.BackColor = System.Drawing.Color.Transparent;
			this.memoAndWords1.ContDocument = this.contDocument1;
			this.memoAndWords1.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
			this.memoAndWords1.Location = new System.Drawing.Point(424, 27);
			this.memoAndWords1.MaximumSize = new System.Drawing.Size(200, 720);
			this.memoAndWords1.MinimumSize = new System.Drawing.Size(200, 720);
			this.memoAndWords1.Name = "memoAndWords1";
			this.memoAndWords1.Size = new System.Drawing.Size(200, 720);
			this.memoAndWords1.TabIndex = 4;
			this.memoAndWords1.MemoChanged += new System.EventHandler(this.memoAndWords1_MemoChanged);
			// 
			// komaDraw1
			// 
			this.komaDraw1.ContDocument = this.contDocument1;
			this.komaDraw1.Form = this;
			this.komaDraw1.IsNoDraw = false;
			this.komaDraw1.Offset = new System.Drawing.Point(164, 27);
			// 
			// contPrint1
			// 
			this.contPrint1.ContDocument = this.contDocument1;
			this.contPrint1.CurrentPage = 0;
			// 
			// MainForm
			// 
			this.AllowDrop = true;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ClientSize = new System.Drawing.Size(714, 753);
			this.ContextMenuStrip = this.KomaStatusMenu;
			this.Controls.Add(this.copyProgress1);
			this.Controls.Add(this.toolStrip1);
			this.Controls.Add(this.menuStrip1);
			this.Controls.Add(this.cutNumber1);
			this.Controls.Add(this.PageScrol);
			this.Controls.Add(this.memoAndWords1);
			this.Controls.Add(this.cutSec1);
			this.DoubleBuffered = true;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MaximumSize = new System.Drawing.Size(720, 785);
			this.MinimumSize = new System.Drawing.Size(720, 785);
			this.Name = "MainForm";
			this.Text = "コンテエディター Nazoh!!";
			this.Deactivate += new System.EventHandler(this.MainForm_Deactivate);
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.DragDrop += new System.Windows.Forms.DragEventHandler(this.MainForm_DragDrop);
			this.DragEnter += new System.Windows.Forms.DragEventHandler(this.MainForm_DragEnter);
			this.DoubleClick += new System.EventHandler(this.MainForm_DoubleClick);
			this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseDown);
			this.toolStrip1.ResumeLayout(false);
			this.toolStrip1.PerformLayout();
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.KomaStatusMenu.ResumeLayout(false);
			this.ResumeLayout(false);

        }

        #endregion

        private ContDocument contDocument1;
        private CutNumber cutNumber1;
        private KomaDraw komaDraw1;
        private MemoAndWords memoAndWords1;
        private CutSec cutSec1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton OpenMenu;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripButton btnAppendPage;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btnImport;
        private System.Windows.Forms.ToolStripButton btnSelectPic;
        private System.Windows.Forms.ToolStripButton btnInputSec;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem fileMenu;
        private System.Windows.Forms.ToolStripMenuItem nazBrowserMenu;
        private System.Windows.Forms.ToolStripMenuItem newTakeTMenu;
        private System.Windows.Forms.ToolStripMenuItem selectTakeMenu;
        private System.Windows.Forms.ToolStripMenuItem quitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem appendPageMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem topPageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prevPageMenu;
        private System.Windows.Forms.ToolStripMenuItem nextPageMenu;
		private System.Windows.Forms.ToolStripMenuItem lastPageToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem10;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem9;
        private System.Windows.Forms.ToolStripButton SaveBtn;
        private System.Windows.Forms.ToolStripMenuItem saveMenu;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
		private System.Windows.Forms.ToolStripButton btnNextPage;
		private System.Windows.Forms.ToolStripButton btnPrevPage;
        private System.Windows.Forms.ToolStripButton btnPageBreak;
        private System.Windows.Forms.ToolStripButton btnTopPage;
        private System.Windows.Forms.ToolStripButton btnLastPage;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripLabel lbCurrentPage;
        private System.Windows.Forms.ToolStripMenuItem renameTakeMenu;
        private System.Windows.Forms.ToolStripMenuItem pageBreakToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem picturMenu;
        private System.Windows.Forms.ToolStripMenuItem importPictureToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectPictureToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unlinkPictureMenu;
        private System.Windows.Forms.ToolStripMenuItem deletePictureFileMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem makeThumbMenu;
        private System.Windows.Forms.VScrollBar PageScrol;
        private System.Windows.Forms.ToolStripLabel lbPictureName;
        private System.Windows.Forms.ToolStripLabel lbTotalSec;
        private System.Windows.Forms.ToolStripLabel lbCutCount;
        private System.Windows.Forms.ToolStripButton btnKomaUpto;
        private System.Windows.Forms.ToolStripButton btnKomaDownto;
        private System.Windows.Forms.ToolStripButton btnCutUpto;
        private System.Windows.Forms.ToolStripButton btnCutDownto;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem pageSetupMenu;
        private System.Windows.Forms.ToolStripMenuItem printPreviewMenu;
		private System.Windows.Forms.ToolStripMenuItem printMenu;
        private System.Windows.Forms.ToolStripMenuItem copyPictureLinkMenu1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
		private System.Windows.Forms.ToolStripMenuItem remakeThumbAllToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
		private System.Windows.Forms.ToolStripSeparator toolStripMenuItem20;
		private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem peastPictureLinkMenu1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem21;
		private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripButton btnPicOffset;
        private System.Windows.Forms.ToolStripLabel lbTargetSec;
        private System.Windows.Forms.ToolStripLabel lbCutAdd;
        private System.Windows.Forms.ToolStripLabel lbParCutSec;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem komaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearKomaMenu;
        private System.Windows.Forms.ToolStripMenuItem deleteKomaMenu;
        private System.Windows.Forms.ToolStripMenuItem insertKomaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem insertContinudToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem insertNoneNumberToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
		private System.Windows.Forms.ToolStripMenuItem inputTimeToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem uptoKomaTMenu;
        private System.Windows.Forms.ToolStripMenuItem downtoKomaMenu;
        private System.Windows.Forms.ToolStripMenuItem cutMenu;
        private System.Windows.Forms.ToolStripMenuItem cutUptoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cutDowntoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem16;
        private System.Windows.Forms.ToolStripMenuItem deleteCutMenu;
        private System.Windows.Forms.ContextMenuStrip KomaStatusMenu;
        private System.Windows.Forms.ToolStripMenuItem IsNoneNumberMenu;
        private System.Windows.Forms.ToolStripMenuItem isContinuedMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem insertCutMenu;
        private System.Windows.Forms.ToolStripMenuItem incertContinedMenu;
        private System.Windows.Forms.ToolStripMenuItem insertNoneNumberMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem komaClearMenu;
        private System.Windows.Forms.ToolStripMenuItem komaDeleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripLabel lbNoneDurationCut;
        private System.Windows.Forms.ToolStripMenuItem CopyPictureLinkMenu2;
        private System.Windows.Forms.ToolStripMenuItem peastPictureLinkMenu2;
        private System.Windows.Forms.ToolStripButton btnHideMemo;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private ContPrint contPrint1;
        private System.Windows.Forms.ToolStripMenuItem savePrintToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editMenu;
        private System.Windows.Forms.ToolStripMenuItem previewContMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem findNoneDurationMenu;
        private System.Windows.Forms.ToolStripMenuItem LockNumberMenu;
        private System.Windows.Forms.ToolStripMenuItem trimPageMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem contSettingMenu;
        private System.Windows.Forms.ToolStripMenuItem pictureImportMenu;
        private System.Windows.Forms.ToolStripMenuItem extInstMenu;
        private System.Windows.Forms.ToolStripMenuItem partToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editPartCaptionMenu;
        private System.Windows.Forms.ToolStripMenuItem partEndMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem goPartStartToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem goPartEndToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem partInfoMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem11;
		private System.Windows.Forms.ToolStripMenuItem unlockedNumberMenu;
        private System.Windows.Forms.ToolStripMenuItem copyCutMenu;
        private System.Windows.Forms.ToolStripMenuItem peastCutMenu;
        private System.Windows.Forms.ToolStripMenuItem setCopyStartMenu;
        private System.Windows.Forms.ToolStripMenuItem cutCutMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem13;
        private CopyProgress copyProgress1;
    }
}

