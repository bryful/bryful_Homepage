﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class CopyProgress : UserControl
    {
        public CopyProgress()
        {
            InitializeComponent();
            
            Size sz = new Size(plProgress.Width, plProgress.Height);
            this.Size = sz;
            this.MaximumSize = sz;
            this.MinimumSize = sz;
        }
        public string Info
        {
            get { return lbProgress.Text; }
            set 
            { 
                lbProgress.Text = value;
                lbProgress.Refresh();
            }
        }
        public int MaxValue
        {
            get { return progressBar1.Maximum; }
            set { progressBar1.Maximum = value; }
        }
        public int MinValue
        {
            get { return progressBar1.Minimum; }
            set { progressBar1.Minimum = value; }
        }
        public int Value
        {
            get { return progressBar1.Value; }
            set { progressBar1.Value = value; }
        }
    }
}
