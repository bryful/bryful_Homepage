﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class EditPartCaptionsDlg : Form
    {
        private MainForm mf;
        private ContDocument _ContDocument;
        private Label[] lbs = new Label[def.PartMaxCount];
        private TextBox[] tbs = new TextBox[def.PartMaxCount];
        //--------------------------------------------------------------------------
        private string Zero3(int v)
        {
            if (v <= 0)
            {
                return "000";
            }
            else if (v < 10)
            {
                return "00" + v.ToString();
            }
            else if (v < 100)
            {
                return "0" + v.ToString();
            }
            else
            {
                return v.ToString();
            }
        }
        //--------------------------------------------------------------------------
        public EditPartCaptionsDlg(MainForm m)
        {
            InitializeComponent();
            mf = m;
            _ContDocument = mf.ContDocument;
            int inter = 26;
            for (int i = 0; i < def.PartMaxCount; i++)
            {
                lbs[i] = new Label();
                lbs[i].Name = "lb" + i.ToString();
                lbs[i].Text = Zero3(i+1);
                lbs[i].Location = new Point(lbBase.Left, lbBase.Top + inter *i);
                lbs[i].Size = lbBase.Size;
                lbs[i].Font = lbBase.Font;
                lbs[i].TextAlign = lbBase.TextAlign;
                lbs[i].Visible = false;
                panel1.Controls.Add(lbs[i]);

                tbs[i] = new TextBox();
                tbs[i].Name = "tb" + i.ToString();
                tbs[i].Text = "";
                tbs[i].Location = new Point(tbBase.Left, tbBase.Top + inter * i);
                tbs[i].Size = tbBase.Size;
                tbs[i].Font = tbBase.Font;
                tbs[i].TextAlign = tbBase.TextAlign;
                tbs[i].MaxLength = 4;
                tbs[i].TextChanged += new EventHandler(tbBase_TextChanged);
                tbs[i].Visible = false;
                panel1.Controls.Add(tbs[i]);

            }
            GetParams();
        }
        //--------------------------------------------------------------------------
        private void GetParams()
        {
            if (_ContDocument == null) return;
            for (int i = 0; i < def.PartMaxCount; i++)
            {
                tbs[i].Text = _ContDocument.GetPartCaptions(i);
                if (i < _ContDocument.PartCount)
                {
                    tbs[i].Visible = true;
                    lbs[i].Visible = true;

                }
            }
            cbIsPrintPartCaption.Checked = _ContDocument.IsPrintPartCaption;
            
        }
        //--------------------------------------------------------------------------
        public string Captions(int idx)
        {
            if ((idx < 0) || (idx >= def.PartMaxCount)) return string.Empty;
            return tbs[idx].Text.Trim();
        }

        //--------------------------------------------------------------------------
        private void tbBase_TextChanged(object sender, EventArgs e)
        {
            btnOK.Enabled = true;
            for (int i = 0; i < def.PartMaxCount; i++)
            {
                if (tbs[i].Text.Trim() == string.Empty)
                {
                    btnOK.Enabled = false;
                    return;
                }
                if (i >= _ContDocument.PartCount) return;
            }

        }
        //--------------------------------------------------------------------------
        public bool IsPrintPartCaption
        {
            get { return cbIsPrintPartCaption.Checked; }
            set { cbIsPrintPartCaption.Checked = value; }
        }
    }
}
