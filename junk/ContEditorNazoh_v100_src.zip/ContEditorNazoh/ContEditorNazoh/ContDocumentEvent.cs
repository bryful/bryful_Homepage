﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class ContDocument : Component
    {
        /// <summary>
        /// 選択コマが変更された。
        /// </summary>
        public event EventHandler SelectedIndexChanged;
        /// <summary>
        /// コマのEmptyが変更された
        /// </summary>
        ///
        public event EventHandler komaChanged;
        //******************************************************************************************
        /*
         * イベント
         */
        //******************************************************************************************
        //----------------------------------------------------------------
        protected virtual void OnSelectedIndexChanged(EventArgs e)
        {
            if (SelectedIndexChanged != null)
            {
                SelectedIndexChanged(this, e);
            }
        }
        //----------------------------------------------------------------
        protected virtual void OnkomaChanged(EventArgs e)
        {
            if (komaChanged != null)
            {
                komaChanged(this, e);
            }
        }
 
    }
}
