﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class ContDocument : Component
    {
        //------------------------------------------------------
        /// <summary>
        /// 新しいページを末尾に追加する
        /// </summary>
        private void newPageAppend()
        {
            ChkItemCount();
            for (int i = 0; i < def.KomaCount; i++)
            {
                _Items.Add(new KomaInfo());
            }
        }
        //-------------------------------------------------------------------------------
        public void NextPage()
        {
            int pc = _Items.Count / def.KomaCount;
            if (_CurrentPage < pc - 1)
            {
                _CurrentPage += 1;
                _SelectedIndex += def.KomaCount;
                if (_SelectedIndex < 0) _SelectedIndex = 0;
                else if (_SelectedIndex >= _Items.Count) _SelectedIndex = _Items.Count - 1;
                OnkomaChanged(new EventArgs());
            }

        }
        //-------------------------------------------------------------------------------
        public void PrevPage()
        {
            if (_CurrentPage > 0)
            {
                _CurrentPage -= 1;
                if (_SelectedIndex < 0)
                {
                    _SelectedIndex = 0;
                }
                _SelectedIndex -= def.KomaCount;
                if (_SelectedIndex < 0) _SelectedIndex = 0;
                else if (_SelectedIndex >= _Items.Count) _SelectedIndex = _Items.Count - 1;
                OnkomaChanged(new EventArgs());
            }

        }
        //-------------------------------------------------------------------------------
        public void AppendPage()
        {
            if (_Locked == true) return;
            _CopyStartIndex = -1;

            //末尾のEmptyをfalseにする
            int cnt = _Items.Count - 1;
            for (int i = cnt; i >= 0; i--)
            {
                if (_Items[i].Empty == true)
                {
                    _Items[i].Empty = false;
                }
                else
                {
                    break;
                }
            }
            newPageAppend();
            ChkItems();
            _CurrentPage = (_Items.Count / def.KomaCount - 1);
            _changeFlag = true;
            OnkomaChanged(new EventArgs());
        }
        //-------------------------------------------------------------------------------
        public void TopPage()
        {
            if (_CurrentPage > 0)
            {
                _CurrentPage = 0;
                if (_SelectedIndex < 0) _SelectedIndex = 0;
                _SelectedIndex = _SelectedIndex % def.KomaCount;
                OnkomaChanged(new EventArgs());
            }

        }
        //-------------------------------------------------------------------------------
        public void LastPage()
        {
            int lp = _Items.Count / def.KomaCount - 1;
            if (_CurrentPage < lp)
            {
                _CurrentPage = lp;

                if (_SelectedIndex < 0) _SelectedIndex = 0;
                _SelectedIndex = (def.KomaCount * lp) + _SelectedIndex % def.KomaCount;

                OnkomaChanged(new EventArgs());
            }

        }

    }
}
