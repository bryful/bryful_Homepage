﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ContEditorNazoh
{
	public partial class NazDirBrowser : Form
	{
        private ContDocument _ContDocument;
        private bool errWorkDir = false;
        private bool _newFLag = false;
		//---------------------------------------------------
		public NazDirBrowser(ContDocument cd)
		{
			InitializeComponent();
            _ContDocument = cd;
            if (_ContDocument != null)
            {
                tbWorkDir.Text = _ContDocument.WorkDir;
                tbNazDir.Text = Path.GetFileName(_ContDocument.NazDir);
            }
            ChkStatus();
            if (errWorkDir == true)
            {
                SelectWorkDir();
                ChkStatus();

                if (errWorkDir == true)
                {
                    this.DialogResult = DialogResult.Cancel;
                    this.Close();
                }

            }
            PrefLoad();
        }
        private void NazDirBrowser_FormClosed(object sender, FormClosedEventArgs e)
        {
            PrefSave();
        }
        //---------------------------------------------------
        private bool ChkWorkDir()
        {
            if (_ContDocument == null) return false;
            if (Directory.Exists(tbWorkDir.Text) == false)
            {
                try
                {
                    Directory.CreateDirectory(tbWorkDir.Text);
                }
                catch
                {
                    tbWorkDir.Text = _ContDocument.DefaultWorkDir;
                }
            }
            if (Directory.Exists(tbWorkDir.Text) == false)
            {
                tbWorkDir.Text = "";
                return false;
            }
            else
            {
                return true;
            }
        }
        //---------------------------------------------------
        private void ChkStatus()
        {
            errWorkDir = !ChkWorkDir();
            if (errWorkDir == false)
            {
                Listup();
            }
            else
            {
                listBox1.Items.Clear();
            }
            btnOK.Enabled = ((listBox1.SelectedIndex >= 0) && (errWorkDir==false));
            tbNazDir.Text = tbNazDir.Text.Trim(); 
        }
        //---------------------------------------------------
        public string WorkDir
		{
			get 
            {
                return tbWorkDir.Text;
            }
			set
			{
                tbWorkDir.Text = value;
                if (ChkWorkDir() == true)
                {
                    Listup();
                }
                else
                {
                    listBox1.Items.Clear();
                }
			}
		}
        //---------------------------------------------------
        public string NazDir
        {
            set
            {
                tbNazDir.Text = Path.GetFileName( value.Trim());
            }
            get
            {
                if (errWorkDir == false)
                {
                    ChkNew();
                    return Path.Combine(tbWorkDir.Text, tbNazDir.Text);
                }
                else
                {
                    return "";
                }
            }
        }
        //---------------------------------------------------
        //---------------------------------------------------
        public void Listup()
		{
            
            listBox1.Items.Clear();
            if (Directory.Exists(tbWorkDir.Text) == false)
            {
                return;
            }
			string[] lst = Directory.GetDirectories(WorkDir);

			foreach (string s in lst)
			{
				listBox1.Items.Add(Path.GetFileName(s));
			}
			if ( (tbNazDir.Text != "")&&(listBox1.Items.Count>0))
			{
				for (int i = 0; i < listBox1.Items.Count; i++)
				{
                    if (listBox1.Items[i].ToString() == tbNazDir.Text)
					{
						listBox1.SelectedIndex = i;
						break;
					}
				}
			}
		}
        //---------------------------------------------------
		private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
            if (errWorkDir == true)
            {
                btnOK.Enabled = false;
            }
            else
            {
                if (listBox1.SelectedIndex >= 0)
                {
                    tbNazDir.Text = listBox1.Items[listBox1.SelectedIndex].ToString();
                }
                btnOK.Enabled =  (tbNazDir.Text != string.Empty);
            }
		}
        //---------------------------------------------------
        private void ChangeWorkDirMenu_Click(object sender, EventArgs e)
        {
            SelectWorkDir();
        }
        //---------------------------------------------------
        public void SelectWorkDir()
        {
            if (errWorkDir == false)
            {
                folderBrowserDialog1.SelectedPath = WorkDir;
            }
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                WorkDir = folderBrowserDialog1.SelectedPath;
            }
        }
        //---------------------------------------------------
        public bool NewFlag
        {
            get
            {
                ChkNew();
                return _newFLag;
            }
        }
        //---------------------------------------------------
        private void ChkNew()
        {
            _newFLag = true;
            int cnt = listBox1.Items.Count;
            if (cnt > 0)
            {
                for (int i = 0; i < cnt; i++)
                {
                    foreach (string s in listBox1.Items)
                    {
                        if ( s == tbNazDir.Text ) {
                            _newFLag = false;
                            return;
                        }
                    }
                }
            }
        }
        //---------------------------------------------------
        private void tbNazDir_TextChanged(object sender, EventArgs e)
        {
            btnOK.Enabled = (tbNazDir.Text != string.Empty);

        }
        //---------------------------------------------------
        private void PrefSave()
        {
            string p = Path.ChangeExtension(Application.ExecutablePath, def.NazPrefBrwExt);
            SaveFiles sv = new SaveFiles(def.PrefHeader);
            sv.SetInt("Left", this.Left);
            sv.SetInt("Top", this.Top);
            sv.SaveToFile(p);
        }
        //---------------------------------------------------------------------------
        public void PrefLoad()
        {
            string p = Path.ChangeExtension(Application.ExecutablePath, def.NazPrefBrwExt);
            SaveFiles sv = new SaveFiles(def.PrefHeader);
            sv.LoadFromFile(p);
            int l = sv.GetInt("Left", -1);
            int t = sv.GetInt("Top", -1);
            if ((l == -1) || (t == -1))
            {
                this.StartPosition = FormStartPosition.CenterScreen;
            }
            else
            {
                this.StartPosition = FormStartPosition.Manual;
                this.Left = l;
                this.Top = t;
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            this.DialogResult =
            btnOK.DialogResult = DialogResult.None;
            ChkNew();
            if (_newFLag == true)
            {
                if (MessageBox.Show("新しいコンテを作成しますか？", "確認", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    this.DialogResult =
                            btnOK.DialogResult = DialogResult.OK;
                }
                else
                {
                    return;
                }
            }
            else
            {
                this.DialogResult =
                  btnOK.DialogResult = DialogResult.OK;
            }
        }

        //---------------------------------------------------

    }
}
