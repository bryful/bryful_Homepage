﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class ContDocument : Component
    {
        public const string CopyHeader = "Nazoh! Copy Data";

        private List<KomaInfo> _CopyBuf = new List<KomaInfo>();
        private string _CopyTargetNazDir = "";
        private string _CopyTargetNazFileName = "";

        private int _CopyStartIndex = -1;

        //--------------------------------------------------------------
        public string ChkCopyStart()
        {
            if ((_CopyStartIndex >= 0) && (_CopyStartIndex < _Items.Count))
            {
                if ((_Items[_CopyStartIndex].Empty == true) || (_Items[_CopyStartIndex].IsContinued == true))
                {
                    _CopyStartIndex = -1;
                }
            }
            else
            {
                _CopyStartIndex = -1;
            }

            if (_CopyStartIndex < 0)
            {
                return "コピー開始点";
            }
            else
            {
                int pc = (_CopyStartIndex / def.KomaCount) + 1;
                int pi = (_CopyStartIndex % def.KomaCount) + 1;

                return "コピー開始点:" + pc.ToString() + "ページ" + pi.ToString() + "コマ目からのカット";
            }
        }
        //--------------------------------------------------------------
        public void SetCopyStart()
        {
            int idx = _SelectedIndex;
            if ((idx < 0) || (idx >= _Items.Count))
            {
                _CopyStartIndex = -1;
                return;
            }
            else if (_Items[idx].Empty == true)
            {
                _CopyStartIndex = -1;
                return;
            }
            if ( (_Items[idx].IsContinued == true)&&(idx>0))
            {
                for (int i = idx - 1; i >= 0; i--)
                {
                    if (_Items[i].IsContinued == false)
                    {
                        idx = i;
                        break;
                    }
                }
            }
            if (_CopyStartIndex != idx)
            {
                _CopyStartIndex = idx;
                OnkomaChanged(new EventArgs());
            }
            
        }
        //--------------------------------------------------------------
        public int CopyStartIndex
        {
            get { return _CopyStartIndex; }
         }
        //--------------------------------------------------------------
        private void CopyCutData(int idx0, int idx1,bool IsDel)
        {
            _CopyBuf.Clear();
            _CopyTargetNazDir = "";
            _CopyTargetNazFileName = "";
            bool IsPartEnd = false;

            int i0 = idx0;
            int i1 = idx1;
            if (i0 > i1)
            {
                int tmp = i0;
                i0 = i1;
                i1 = tmp;
            }
            i0 = FindCutStart(i0);
            if (i0 < 0) return;
            i1 = FindCutEnd(i1);
            if (i1 < 0) return;

            for (int i = i0; i <= i1; i++)
            {
                _CopyBuf.Add(_Items[i]);
                if (_Items[i].IsPartEnd == true) IsPartEnd = true;
                _Items[i].IsPartEnd = false;
            }
            if (IsDel == true)
            {
                for (int i = i1; i >= i0; i--)
                {
                    _Items.RemoveAt(i);
                }
                _SelectedIndex = i0;
                if (IsPartEnd == true)
                {
                    if (i0 > 0)
                    {
                        _Items[i0 - 1].IsPartEnd = true;
                    }
                }
                _changeFlag = true;
            }

            _CopyTargetNazDir = _NazDir;
            _CopyTargetNazFileName = _NazFileName;

         }

        //--------------------------------------------------------------
        private void FromCopyBufToClip()
        {
            if ( _CopyBuf.Count<=0) return;
            string s = CopyHeader +"\n";
            s += Path.Combine(_CopyTargetNazDir,_CopyTargetNazFileName)+"\n";
            s += "\n";
            for ( int i=0; i<_CopyBuf.Count; i++)
            {
                s += _CopyBuf[i].ToText() +"\n";
            }

            Clipboard.SetText(s);
        }
        //--------------------------------------------------------------
        public void CutToClip(bool IsDel)
        {
            int idx0 = _SelectedIndex;
            if ((idx0 < 0) || (idx0 >= _Items.Count)) return;

            int idx1 = _CopyStartIndex;
            _CopyStartIndex = -1;
            if (idx1 < 0) idx1 = idx0; 

            CopyCutData(idx0, idx1, IsDel);
            FromCopyBufToClip();
            ChkItems();
            OnkomaChanged(new EventArgs());
        }
        //--------------------------------------------------------------
        public void ClipToCut(CopyProgress cp)
        {
            int idx = _SelectedIndex;
            if ((idx < 0) || (idx >= _Items.Count)) return;
            if (ChkClip() == true)
            {
                FromClipToCopyBuf();
            }
            CopyBufToCutData(cp);
            ChkItems();
            OnkomaChanged(new EventArgs());

        }
        //--------------------------------------------------------------
        public bool ChkClip()
        {
            string s = Clipboard.GetText();
            if (s == string.Empty) return false;
            return (s.IndexOf(CopyHeader) == 0);
        }
        //--------------------------------------------------------------
        private string [] GetClip()
        {
            string[] ret = new string[0];
            string s = Clipboard.GetText();
            if (s == string.Empty) return ret;
            int p = s.IndexOf(CopyHeader);
            if (s.IndexOf(CopyHeader) != 0) return ret;
            ret = s.Split('\n');
            if (ret.Length <= 2) return new string[0];
            for (int i = 0; i < ret.Length; i++) ret[i] = ret[i].Trim();
            return ret;
        }
        //--------------------------------------------------------------
        private void FromClipToCopyBuf()
        {
            _CopyBuf.Clear();
            _CopyTargetNazDir = "";
            _CopyTargetNazFileName = "";

            string[] lines = GetClip();
            int cnt = lines.Length;
            if (cnt <= 0) return;
            if (lines[0] != CopyHeader) return;
            if ( File.Exists(lines[1]) ==false) return;
            _CopyTargetNazDir = Path.GetDirectoryName(lines[1]);
            _CopyTargetNazFileName = Path.GetFileName(lines[1]);

            int v = 2;
            int sIdx = 0;
            int eIdx = 0;
            while (v < cnt)
            {
                sIdx = FindTag(lines, "*KomaInfo", v);
                if (sIdx < 0) break;
                sIdx++;
                eIdx = FindTag(lines, "*KomaInfoEnd", sIdx);
                if (eIdx < 0) eIdx = cnt - 1;
                v = eIdx + 1;
                if (eIdx >= sIdx)
                {
                    string dada = "";
                    for (int j = sIdx; j < eIdx; j++) dada += lines[j] + "\n";
                    KomaInfo ci = new KomaInfo();
                    ci.FromText(dada);
                    _CopyBuf.Add(ci);
                }
            }
            if (_CopyBuf.Count <= 0)
            {
                _CopyTargetNazDir = "";
                _CopyTargetNazFileName = "";
            }
        }
        //--------------------------------------------------------------
        private int FindTag(string[] lines, string tag, int startIdx)
        {
            int ret = -1;

            if ((lines.Length <= 0) || (tag == "")) return ret;
            if (startIdx >= lines.Length) return ret;
            if (startIdx < 0) startIdx = 0;

            string t = tag.ToLower().Trim();
            //
            if (t[0] != '*') t = "*" + t;
            for (int i = startIdx; i < lines.Length; i++)
            {
                string line = lines[i].ToLower().Trim();
                if (line != string.Empty)
                {
                    string[] prm = line.Split('\t');
                    if (prm[0].Trim() == t)
                    {
                        return i;
                    }
                }
            }
            return ret;
        }
        //--------------------------------------------------------------
        private int NextTag(string[] lines, int startIdx)
        {
            int cnt = lines.Length - 1;
            if ((cnt < 0) || (startIdx > cnt)) return cnt;

            if (startIdx < 0) startIdx = 0;

            for (int i = startIdx; i <= cnt; i++)
            {
                string line = lines[i].ToLower().Trim();
                if (line != string.Empty)
                {
                    string[] prm = line.Split('\t');
                    if (prm[0][0] == '*')
                    {
                        return i;
                    }
                }
            }
            return cnt;
        }
        //--------------------------------------------------------------
        private List<string> GetPictureList()
        {
            List<string> ret = new List<string>();
            int cnt = _CopyBuf.Count;
            if ( cnt<= 0) return ret;

            for (int i = 0; i < cnt; i++)
            {
                if (_CopyBuf[i].Pic.name != string.Empty)
                {
                    ret.Add(_CopyBuf[i].Pic.name);
                }
                if (_CopyBuf[i].PicSub.name != string.Empty)
                {
                    ret.Add(_CopyBuf[i].PicSub.name);
                }
            }
            if (ret.Count <= 1) return ret;

            //ソートしてダブりを消す
            ret.Sort();
            for (int i = ret.Count - 1; i > 0; i--)
            {
                if (ret[i - 1] == ret[i]) ret.RemoveAt(i); 
            }

            return ret;
        }
        //--------------------------------------------------------------
        private string ChkImageFileName(string s)
        {
            string n = Path.GetFileNameWithoutExtension(s);
            string e = Path.GetExtension(s);

            string p = Path.Combine(_ImageDir,s);
            while (File.Exists(p) == true)
            {
                n += "_";
                p = Path.Combine(_ImageDir, n + e);
            }
            return n + e;
        }
        //--------------------------------------------------------------
        private void ChangePictName(string s, string d)
        {
            if (_CopyBuf.Count <= 0) return;
            for (int i = 0; i < _CopyBuf.Count; i++)
            {
                if (_CopyBuf[i].Pic.name == s) _CopyBuf[i].Pic.name = d;
                if (_CopyBuf[i].PicSub.name == s) _CopyBuf[i].PicSub.name = d;
            }
        }
        //--------------------------------------------------------------
        private void ImageFileCopy(List<string> lst,CopyProgress cp)
        {
            if (lst.Count <= 0) return;
            string srcP = Path.Combine(_CopyTargetNazDir, def.ImageFolderName);
            if (Directory.Exists(srcP) == false) return;
            string dstP = _ImageDir;

            if (cp != null)
            {
                cp.MaxValue = lst.Count;
                cp.MinValue = 0;
                cp.Value = 0;
                cp.Visible = true;
                cp.Info = "画像ファイルのインポート";
            }

            for (int i = 0; i < lst.Count; i++)
            {
                string sf = Path.Combine(srcP, lst[i]);
                if (File.Exists(sf) == false) continue;
                string n = ChkImageFileName(lst[i]);
                string df = Path.Combine(dstP, n);
                try
                {
                    if (cp != null) 
                    {
                        cp.Value = i;
                        cp.Info = "[ " + lst[i] + " ]をインポート中";
                    } 
                    File.Copy(sf, df);
                }
                catch
                {
                    MessageBox.Show("Image File Copy Error!:" + sf);
                    if (cp != null)
                    {
                        cp.Visible = false;
                    }
                    return;
                }
                if (lst[i] != n)
                {
                    ChangePictName(lst[i], n);
                }
            }
            if (cp != null)
            {
                cp.Visible = false;
            }
        }
        //--------------------------------------------------------------
        private void CopyBufToCutData(CopyProgress cp)
        {
            int idx = _SelectedIndex;
            if ((idx < 0) || (idx >= _Items.Count)) return;
            if (_CopyBuf.Count <= 0) return;
            //コピー先の確認
            //違うNazだったらファイルのコピー
            if (_CopyTargetNazDir != _NazDir)
            {
                string p = Path.Combine(_CopyTargetNazDir, def.ImageFolderName);
                //相手が存在していなかったら無しに
                if (Directory.Exists(p) == false)
                {
                    _CopyBuf.Clear();
                    _CopyTargetNazDir = "";
                    _CopyTargetNazFileName = "";
                    return;
                }
                ImageFileCopy(GetPictureList(),cp);
            }
            //Emptyをさかのぼる
            if (_Items[idx].Empty == true)
            {
                if (idx > 0)
                {
                    for (int i = idx; i > 0; i++)
                    {
                        if (_Items[idx - 1].Empty == false)
                        {
                            //Emptyの頭
                            idx = i;
                            break;
                        }
                    }
                }
            }
            //カットの頭を探す
            if (_Items[idx].Empty == false)
            {
                if (idx > 0)
                {
                    if (_Items[idx].IsContinued == true)
                    {
                        for (int i = idx - 1; i >= 0; i--)
                        {
                            if (_Items[i].IsContinued == false)
                            {
                                idx = i;
                                break;
                            }
                        }
                    }
                }
                
            }
            //パートエンドの処理
            for (int i = _Items.Count - 1; i >= 0; i--)
            {
                if (_Items[i].Empty == false)
                {
                    _Items[i].IsPartEnd = false;
                    break;
                }
            }

            int v =0;
            if (idx <= _Items.Count - 1)
            {
                v = idx;
                for (int i = 0; i < _CopyBuf.Count; i++)
                {
                    _Items.Insert(v, _CopyBuf[i]);
                    v++;
                }
            }
            else
            {
                idx = _Items.Count - 1;
                //多分ここには到達しない
                for (int i = 0; i < _CopyBuf.Count; i++)
                {
                    _Items.Add(_CopyBuf[i]);
                }

            }
            _SelectedIndex = idx;
            _CopyStartIndex = -1;
           
        }

    }
}
