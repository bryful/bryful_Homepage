﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class ContDocument : Component
    {
        //----------------------------------------------------------------------------------
        public void ShowContSettingDlg()
        {
            ContSettingDlg dlg = new ContSettingDlg(this);

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                bool IsLocked = false;
                bool b = false;
                if (Locked != dlg.Loacked)
                {
                    IsLocked = dlg.Loacked;
                    //b = true;
                }
                if (Title != dlg.ContTitle)
                {
                    Title = dlg.ContTitle;
                    //b = true;
                }
                if (SubTitle != dlg.SubTitle)
                {
                    SubTitle = dlg.SubTitle;
                    //b = true;
                }
                if (OPUS != dlg.OPUS)
                {
                    OPUS = dlg.OPUS;
                    //b = true;
                }
                if (CreateUser != dlg.CreateUser)
                {
                    CreateUser = dlg.CreateUser;
                    //b = true;
                }
                if (UpdateUser != dlg.UpdateUser)
                {
                    UpdateUser = dlg.UpdateUser;
                    //b = true;
                }
                if (Comment != dlg.Comment)
                {
                    Comment = dlg.Comment;
                    //b = true;
                }
                if (_NumberStart != dlg.NumberStart)
                {
                    _NumberStart = dlg.NumberStart;
                    b = true;
                }
                if (_PageNumberStart != dlg.PageNumberStart)
                {
                    _PageNumberStart = dlg.PageNumberStart;
                    b = true;
                }
                if (_Version != dlg.Version)
                {
                    _Version = dlg.Version;
                    b = true;
                }
                if (_fps != dlg.fps)
                {
                    _fps = dlg.fps;
                    b = true;
                }
                if (_TargtDuration != dlg.TargetDuration)
                {
                    _TargtDuration = dlg.TargetDuration;
                    b = true;
                }
                if (CampanyName != dlg.CampanyName)
                {
                    CampanyName = dlg.CampanyName;
                    b = true;
                }
                if (_IsPrintTitle != dlg.IsPrintTitle)
                {
                    _IsPrintTitle = dlg.IsPrintTitle;
                    b = true;
                }
                if (_IsPrintSubTitle != dlg.IsPrintSubTitle)
                {
                    _IsPrintSubTitle = dlg.IsPrintSubTitle;
                    b = true;
                }
                if (_IsPrintOPUS != dlg.IsPrintOPUS)
                {
                    _IsPrintOPUS = dlg.IsPrintOPUS;
                    b = true;
                }
                if (_IsPrintCampany != dlg.IsPrintCampany)
                {
                    _IsPrintCampany = dlg.IsPrintCampany;
                    b = true;
                }
                if (_IsPrintDurationInfo != dlg.IsPrintDurationInfo)
                {
                    _IsPrintDurationInfo = dlg.IsPrintDurationInfo;
                    b = true;
                }
                if (_IsPrintPartCaption != dlg.IsPrintPartCaption)
                {
                    _IsPrintPartCaption = dlg.IsPrintPartCaption;
                    b = true;
                }
                //Locked対策
                if (IsLocked == true)
                {
                    SaveNaz(IsLocked);
                }
                Locked = IsLocked;
                if (b == true)
                {
                    _changeFlag = true;
                    OnkomaChanged(new EventArgs());
                }

            }
        }
        //-------------------------------------------------------------------------------
        public void FindNoneDurationCut()
        {
            int ret = FindNoneDurationCut(0);
            if (ret >= 0)
            {
                _SelectedIndex = ret;
                CurrentPageChk();
                OnkomaChanged(new EventArgs());
            }
        }
        //-------------------------------------------------------------------------------
        public int FindNoneDurationCut(int sIdx)
        {
            int ret = -1;
            int cnt = _Items.Count;
            if ((sIdx < 0) || (sIdx >= cnt)) return ret;
            for (int i = sIdx; i < cnt; i++)
            {
                if ((_Items[i].Empty == false) && (_Items[i].IsNoneNumber == false) && (_Items[i].IsContinuedNext == false))
                {
                    if (_Items[i].DurationCutAdd == 0)
                    {
                        ret = i;
                        break;
                    }
                }
            }
            return ret;
        }
        //----------------------------------------------------------------------------------
        public void ShowPictureOffsetDlg(MainForm m)
        {
            if ((m == null) || (_Locked == true)) return;
            PictureOffsetDlg dlg = new PictureOffsetDlg(m, true);
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                OnkomaChanged(new EventArgs());
            }

        }

    }
}
