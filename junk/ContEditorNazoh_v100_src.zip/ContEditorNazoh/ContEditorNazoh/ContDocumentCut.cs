﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class ContDocument : Component
    {
        private int FindCutStart(int idx)
        {
            int ret = -1;
            if (idx < 0) return ret;
            else if (idx == 0) return 0;
            else if (idx >= _Items.Count) return ret;
            else if (_Items[idx].Empty == true) return ret;
            else if (_Items[idx].IsNoneNumber == true) return idx;
            else if (_Items[idx].IsContinued == false) return idx;
            //前を探す
            for (int i = idx - 1; i >= 0; i--)
            {
                if (_Items[i].IsContinued == false)
                {
                    ret = i;
                    break;
                }
            }
            return ret;
        }
        //------------------------------------------------------
        private int FindCutEnd(int idx)
        {
            int ret = -1;
            int cnt = _Items.Count;
            if (idx < 0) return ret;
            else if (idx >= cnt) return ret;
            else if (idx == cnt - 1) return idx;
            else if (_Items[idx].Empty == true) return ret;
            else if (_Items[idx].IsContinuedNext == false) return idx;
            ret = idx;
            for (int i = idx + 1; i < cnt; i++)
            {
                if (_Items[i].IsContinuedNext == false)
                {
                    ret = i;
                    break;
                }
            }
            return ret;
        }
        //------------------------------------------------------
        /// <summary>
        /// 指定した位置のカットをCopyして消す
        /// </summary>
        /// <param name="?"></param>
        /// <returns></returns>
        private List<KomaInfo> CutCut(int idx)
        {
            List<KomaInfo> ret = new List<KomaInfo>();
            if (_Items[idx].Empty == true) return ret;
            if (_Items[idx].IsNoneNumber == true)
            {
                ret.Add(_Items[idx]);
                _Items.RemoveAt(idx);
                return ret;
            }
            int i0 = FindCutStart(idx);
            if ( i0<0) return ret;
            int i1 = FindCutEnd(idx);
            if (i1 < 0) return ret;
            for (int i = i0; i <= i1; i++)
            {
                ret.Add(_Items[i]);
            }
            for (int i = i1; i >= i0; i--)
            {
                _Items.RemoveAt(i);
            }
            return ret;

        }
        //------------------------------------------------------
        private void InsertCutArray(int idx, List<KomaInfo> lst)
        {
            if ((idx < 0) || (idx >= _Items.Count)) return;
            if (lst.Count <= 0) return;
            int idx0 = idx;
            for (int i = 0; i < lst.Count; i++)
            {
                _Items.Insert(idx0, lst[i]);
                idx0++;
            }
        }
        //------------------------------------------------------
        private int SwapCut(int idx0, int idx1, int op)
        {
            if (idx0 == idx1) return -1;
            int s0 = FindCutStart(idx0);
            int s1 = FindCutStart(idx1);
            if ((s0 < 0) || (s1 < 0) || (s0 == s1)) return -1;
            if (s0 > s1)
            {
                int tmp = s0;
                s0 = s1;
                s1 = tmp;
            }
            List<KomaInfo> lst0 = CutCut(s0);
            if (lst0.Count <= 0) return -1;
            s1 -= lst0.Count;
            List<KomaInfo> lst1 = CutCut(s1);
            InsertCutArray(s0, lst1);
            s1 += lst1.Count;
            InsertCutArray(s1, lst0);
            if (op == 0)
            {
                return s0;
            }
            else
            {
                return s1;
            }
        }
        //------------------------------------------------------
        public void CutUpto()
        {
            if (_Locked == true) return;
            _CopyStartIndex = -1;

            int idx = _SelectedIndex;
            if (idx < 0) return;
            if (_Items[idx].Empty == true) return;

            int idx1 = FindCutStart(idx);
            if (idx1 <= 0) return;
            //前のカットを探す
            int idx0 = -1;
            for (int i = idx1 - 1; i >= 0; i--)
            {
                if (_Items[i].Empty == true)
                {
                    //読み飛ばす
                }
                else if (_Items[i].IsContinued == false)
                {
                    idx0 = i;
                    break;
                }
            }
            if (idx0 < 0) return;
            int si = SwapCut(idx0, idx1, 0);
            if (si >= 0)
            {
                _SelectedIndex = si;
                ChkItems();
                OnkomaChanged(new EventArgs());
            }
        }
        //------------------------------------------------------
        public void CutDownto()
        {
            if (_Locked == true) return;
            _CopyStartIndex = -1;

            int idx = _SelectedIndex;
            if (idx < 0) return;
            if (_Items[idx].Empty == true) return;

            int idx0 = FindCutStart(idx);
            if (idx0 >= _Items.Count - 1) return;
            //次カットを探す
            int idx1 = -1;
            for (int i = idx0 + 1; i < _Items.Count; i++)
            {
                if (_Items[i].Empty == true)
                {
                    //読み飛ばす
                }
                else if (_Items[i].IsContinued == false)
                {
                    idx1 = i;
                    break;
                }
            }
            if (idx0 < 0) return;
            int si = SwapCut(idx0, idx1, 1);
            if (si >= 0)
            {
                _SelectedIndex = si;
                ChkItems();
                OnkomaChanged(new EventArgs());
            }
        }
        //------------------------------------------------------
        public void DeleteCut()
        {
            if (_Locked == true) return;
            _CopyStartIndex = -1;
            int idx = _SelectedIndex;
            if (idx < 0) return;
            if (_Items[idx].Empty == true) return;

            if (MessageBox.Show("このカットのすべてのコマを削除します。", "確認", MessageBoxButtons.OKCancel) != DialogResult.OK)
            {
                return;
            }

            int idx0 = FindCutStart(_SelectedIndex);
            if (idx0 < 0)
            {
                return;
            }
            else if (idx0 == _Items.Count - 1)
            {
                _Items.RemoveAt(idx0);
                return;
            }
            //次カットを探す
            int idx1 = _Items.Count - 1;
            for (int i = idx0 + 1; i < _Items.Count; i++)
            {
                if (_Items[i].Empty == true)
                {
                    //読み飛ばす
                }
                else if (_Items[i].IsContinued == false)
                {
                    idx1 = i - 1;
                    break;
                }
            }

            for (int i = idx1; i >= idx0; i--)
            {
                _Items.RemoveAt(i);
            }
            ChkItems();

            OnkomaChanged(new EventArgs());
        }

    }
}
