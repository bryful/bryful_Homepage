﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class PictureOffsetDlg : Form
    {
        private MainForm mf;
        private ContDocument _ContDocument;
        private ContDraw _ContDraw;

        private float ox = 0f;
        private float oy = 0f;
        private int mx = 0;
        private int my = 0;
        private float mxF = 0;
        private float myF = 0;
        private bool IsMd = false;
        private bool IsMain = true;
        private KomaPict PicI;
        //----------------------------------------------------------------
        public PictureOffsetDlg(MainForm m,bool IsM)
        {
            InitializeComponent();
            mf = m;
            _ContDocument = m.ContDocument;
            _ContDraw = new ContDraw(_ContDocument);
            _ContDraw.CurrentPage = _ContDocument.CurrentPage;

            this.ClientSize = new Size(_ContDraw.PaperWidthP + groupBox1.Width + 4, _ContDraw.PaperHeightP);
            groupBox1.Left = _ContDraw.PaperWidthP +4;
            groupBox1.Height = _ContDraw.PaperHeightP ;
            groupBox1.Top = 0;

            if (_ContDocument.SelectedIndex >= 0)
            {
                IsMain = IsM;
                if (IsM == true)
                {
                    ox = _ContDocument.Pic.X;
                    oy = _ContDocument.Pic.Y;
                    PicI = _ContDocument.Pic;
                }
                else
                {
                    ox = _ContDocument.PicSub.X;
                    oy = _ContDocument.PicSub.Y;
                    PicI = _ContDocument.PicSub;
                }
            }
        }
        //----------------------------------------------------------------
        public int Currentpage
        {
            get { return _ContDraw.CurrentPage; }
            set { _ContDraw.CurrentPage = value; }
        }
        //----------------------------------------------------------------
        private void PictureOffsetDlg_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.PageUnit = GraphicsUnit.Millimeter;
            SolidBrush sb = new SolidBrush(Color.White);
            try
            {
                e.Graphics.FillRectangle(sb, new Rectangle(0, 0, this.Width, this.Height));
                if (_ContDraw != null)
                {
                    _ContDraw.DrawPreviewPage(e.Graphics);
                }
            }
            finally
            {
                sb.Dispose();
            }
        }
        //----------------------------------------------------------------
        private void btnInit_Click(object sender, EventArgs e)
        {
            if (_ContDocument != null)
            {  
                PicI.X = ox;
                PicI.Y = oy;
                this.Invalidate();
            }
        }
        //----------------------------------------------------------------
        private void btnDef_Click(object sender, EventArgs e)
        {
            if (_ContDocument != null)
            {
                PicI.X =0;
                PicI.Y =0;
                this.Invalidate();
            }

        }
        //----------------------------------------------------------------
        private void PictureOffsetDlg_MouseDown(object sender, MouseEventArgs e)
        {
            if (_ContDocument != null)
            {
                mx = e.X;
                my = e.Y;
             
                mxF = PicI.X;
                myF = PicI.Y;

                IsMd = true;
            }
        }
        //----------------------------------------------------------------
        private void PictureOffsetDlg_MouseUp(object sender, MouseEventArgs e)
        {
            IsMd = false;
            mx = 0;
            my = 0;
            mxF = 0;
            myF = 0;
        }
        //----------------------------------------------------------------
        private void PictureOffsetDlg_MouseMove(object sender, MouseEventArgs e)
        {
            if (IsMd == true)
            {
                float xx = ((float)(e.X - mx) *25.4f / def.DisplayDpi);
                float yy = ((float)(e.Y - my) * 25.4f / def.DisplayDpi);
                PicI.X =  mxF + xx;
                PicI.Y =  myF + yy;

                this.Invalidate();

            }

        }

        //----------------------------------------------------------------
        public void PicMove(int p)
        {
            if (_ContDocument == null) return;
            float a = 1.0f;
            switch (p)
            {
                case 0:
                    PicI.Y -=a;
                    break;
                case 1:
                    PicI.X += a;
                    break;
                case 2:
                    PicI.Y += a;
                    break;
                case 3:
                    PicI.X -= a;
                    break;
            }
            this.Invalidate();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            PicI.X = ox;
            PicI.Y = oy;
        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            PicMove(0);
        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            PicMove(2);
        }

        private void btnRight_Click(object sender, EventArgs e)
        {
            PicMove(1);
        }

        private void btnLeft_Click(object sender, EventArgs e)
        {
            PicMove(3);
        }



    }
}
