﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;


namespace ContEditorNazoh
{
    public class CutNumber : Control
    {
        private ContDocument _ContDocument;
        private int _Index = -1;

        //public event EventHandler SelectedIndexChanged;

        private StringFormat format = new StringFormat();

        public CutNumber()
        {
            //ダブルバッファー表示
            this.SetStyle(ControlStyles.DoubleBuffer, true);
            this.SetStyle(ControlStyles.UserPaint, true);
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);

            this.SuspendLayout();
            this.SetStyle(ControlStyles.SupportsTransparentBackColor, true);
            this.BackColor = Color.Transparent;

            this.Width = def.PreviewNumberWidthP;
            this.Height = def.PreviewKomaHeightP * def.KomaCount;
            this.MaximumSize = new Size(this.Width, this.Height);
            this.MinimumSize = new Size(this.Width, this.Height);

            format.Alignment = StringAlignment.Center;
            format.LineAlignment = StringAlignment.Center;
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.ResumeLayout();
        }
        //******************************************************************************************
    
        //----------------------------------------------------------------
        private void contDocument_DispChanged(object sender, EventArgs e)
        {
            this.Invalidate();
        }

        //***********************************************************
        /*
         * プロパティ
         */ 
        //***********************************************************
        public ContDocument ContDocument
        {
            get { return _ContDocument; }
            set 
            {
                _Index = -1;
                _ContDocument = value;
                if (_ContDocument != null)
                {
                    _Index = _ContDocument.CurrentPage * def.KomaCount;
                    _ContDocument.SelectedIndexChanged += new EventHandler(contDocument_DispChanged);
                    _ContDocument.komaChanged += new EventHandler(contDocument_DispChanged);
				}
            }
        }
        //-----------------------------------------------------------
        //***********************************************************
        /*
         * 描画
         */
        //***********************************************************
        protected override void OnPaint(PaintEventArgs e)
        {
			_Index = _ContDocument.CurrentPage * def.KomaCount;
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.PageUnit = GraphicsUnit.Pixel;
            SolidBrush sb = new SolidBrush(Color.Transparent);
            Pen p = new Pen(Color.Black);
            try
            {
                g.FillRectangle(sb, new Rectangle(0, 0, this.Width, this.Height));
                if (_ContDocument != null)
                {
                    for (int i = 0; i < def.KomaCount; i++)
                    {
                        DrawNumbers(g, sb, p, i);
                    }
                }

            }
            finally
            {
                sb.Dispose();
                p.Dispose();
            }
        }
        //-------------------------------------------------------------------------
        private void DrawNumbers(Graphics g, SolidBrush sb, Pen p,int idx)
        {
            //if (_ContDocument == null) return;
            float pw = p.Width;
            Color c = sb.Color;
            int x0 = 0;
            int x1 = this.Width - 1;
            int y0 = idx * def.PreviewKomaHeightP;
            int y1 = y0 + def.PreviewKomaHeightP - 1;

            g.DrawLine(p, x0, y0, x1, y0);
            g.DrawLine(p, x0, y0, x0, y1);
            g.DrawLine(p, x1, y0, x1, y1);
            p.Width = 1;
            if (idx == def.KomaCount - 1)
            {
                g.DrawLine(p, x0, y1, x1, y1);
            }
            int pIndex = _Index + idx;
            KomaInfo ki = _ContDocument.GetItem(pIndex);
            if (ki != null)
            {
                if (_ContDocument.CopyStartIndex == pIndex)
                {
                    p.Width = 2;
                    p.Color = Color.Red;
                    g.DrawRectangle(p, new Rectangle(x0+2, y0+2, this.Width - 4, def.PreviewKomaHeightP - 3));
                    p.Color = Color.Black;
                    p.Width = 1;

                }
                if (ki.IsPartEnd == true)
                {
                    p.Width = 8;
                    int yy1 = (idx + 1) * def.PreviewKomaHeightP - 4;
                    p.Color = Color.DarkGray;
                    g.DrawLine(p, 1, yy1, this.Width - 2, yy1);
                    p.Color = Color.Black;
                    p.Width = 1;
                }
                if (ki.IsPageBreak == true)
                {
                    p.Width = 4;
                    int yyy1 = (idx + 1) * def.PreviewKomaHeightP - 2;
                    g.DrawLine(p, 1, yyy1, this.Width - 2, yyy1);
                    p.Width = 1;

                }

                if (ki.Empty == true)
                {
                    g.DrawLine(p, x0, y0, x1, y1);
                    g.DrawLine(p, x0, y1, x1, y0);
                }
                else
                {
                    if (ki.IsContinued == true)
                    {
                        int cx = this.Width / 2;
                        g.DrawLine(p, cx, y0, cx, y1);
                        if (ki.IsContinuedNext == false)
                        {
                            g.DrawLine(p, cx, y1, cx - 10, y1 - 10);
                            g.DrawLine(p, cx, y1, cx + 10, y1 - 10);
                        }
                    }
                    else if (ki.IsNoneNumber == false)
                    {
                        Rectangle rct = new Rectangle(x0 + 8, y0 + 8, this.Width - 16, def.PreviewKomaHeightP - 16);
                        sb.Color = Color.Black;
                        g.DrawString(_ContDocument.DispNumber(_Index + idx), this.Font, sb, rct, format);
                        if (_ContDocument.IsPrintPartCaption == true)
                        {
                            StringFormat fmt = new StringFormat();
                            fmt.Alignment = StringAlignment.Near;
                            fmt.LineAlignment = StringAlignment.Near;
                            Font ff = new Font(this.Font.FontFamily, this.Font.Size * 0.75f,FontStyle.Regular);
                            g.DrawString(_ContDocument.DispPartCaption(_Index + idx), ff, sb, rct, fmt);
                            ff.Dispose();
                        }

                        if (ki.IsContinuedNext == true)
                        {
                            int cx = this.Width / 2;
                            g.DrawLine(p, cx, y1 - 50, cx, y1);
                        }

                    }
                }
                if (_ContDocument.SelectedPageIndex == idx)
                {
                    p.Width = 2;
                    x0 += 2;
                    y0 += 2;
                    g.DrawRectangle(p, new Rectangle(x0, y0, this.Width - 4, def.PreviewKomaHeightP - 3));
                    p.Width = 1;

                }
            }
            p.Width = pw;
            sb.Color = c;



        }
        //-------------------------------------------------------------------------
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (_ContDocument != null)
            {
                int v = (e.Y / def.PreviewKomaHeightP) + _Index;
                if (_ContDocument.SelectedIndex != v)
                {
                    _ContDocument.SelectedIndex = v;
                    //this.Invalidate();
                }
               
            }
            
        }
        //-------------------------------------------------------------------------

    }
}
