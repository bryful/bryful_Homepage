﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class ContDocument : Component
    {
        //******************************************************************************************
        //プロパティ関係
        //******************************************************************************************
        public bool IsPrintTitle
        {
            get { return _IsPrintTitle; }
            set { _IsPrintTitle = value; }
        }
        public bool IsPrintSubTitle
        {
            get { return _IsPrintSubTitle; }
            set { _IsPrintSubTitle = value; }
        }
        public bool IsPrintOPUS
        {
            get { return _IsPrintOPUS; }
            set { _IsPrintOPUS = value; }
        }
        public bool IsPrintCampany
        {
            get { return _IsPrintCampany; }
            set { _IsPrintCampany = value; }
        }
        public bool IsPrintDurationInfo
        {
            get { return _IsPrintDurationInfo; }
            set { _IsPrintDurationInfo = value; }
        }
        //------------------------------------------------------
        /// <summary>
        /// 編集・セーブ禁止フラグ
        /// </summary>
        public bool Locked
        {
            get { return _Locked; }
            set { _Locked = value; }
        }
        //------------------------------------------------------
        /// <summary>
        /// 表示されているページインデックス
        /// </summary>
        public int CurrentPage
        {
            get
            {
                if (_CurrentPage < 0)
                {
                    _CurrentPage = 0;
                    return 0;
                }
                else
                {
                    int pc = (_Items.Count / def.KomaCount) - 1;
                    if (_CurrentPage > pc)
                    {
                        _CurrentPage = pc;
                    }
                    return _CurrentPage;
                }
            }
            set
            {
                int cp = value;
                if (cp < 0) cp = 0;
                else if (cp >= _Items.Count) cp = _Items.Count - 1;
                if (_CurrentPage != cp)
                {
                    _CurrentPage = cp;

                    if (_SelectedIndex < 0) _SelectedIndex = 0;
                    _SelectedIndex = cp * def.KomaCount + (_SelectedIndex % def.KomaCount);

                    OnkomaChanged(new EventArgs());
                }
            }
        }
        //------------------------------------------------------
        /// <summary>
        /// 現在のページ枚数
        /// </summary>
        public int PageCount
        {
            get
            {
                int pc = _Items.Count / def.KomaCount;
                if ((_Items.Count % def.KomaCount) != 0) pc++;
                return pc;

            }
        }
        //------------------------------------------------------
        /// <summary>
        /// ページ情報
        /// </summary>
        public string PageNavCaption
        {
            get
            {
                if (_NazDir == "")
                {
                    return "Now Page";
                }
                else
                {
                    string s = (_CurrentPage + 1).ToString();
                    s += "/";
                    s += (_Items.Count / def.KomaCount).ToString();
                    return s;
                }
            }
        }
        //------------------------------------------------------
        public int SelectedIndex
        {
            get { return _SelectedIndex; }
            set
            {
                if ((value >= -1) && (value < _Items.Count))
                {
                    if (_SelectedIndex != value)
                    {
                        _SelectedIndex = value;
                        //CurrentPageChk();
                        OnSelectedIndexChanged(new EventArgs());
                    }
                }
            }
        }
        //------------------------------------------------------
        /// <summary>
        /// 現在のページの何コマめが選択されているか
        /// </summary>
        public int SelectedPageIndex
        {
            get
            {
                if (_SelectedIndex < 0)
                {
                    return -1;
                }
                else
                {
                    //カレントページじゃないとだめ
                    if (_CurrentPage == (_SelectedIndex / def.KomaCount))
                    {
                        return _SelectedIndex % def.KomaCount;
                    }
                    else
                    {
                        return -1;
                    }
                }
            }
        }
        //------------------------------------------------------
        /// <summary>
        /// 現在選択されているKomaInfo
        /// </summary>
        public KomaInfo SelectedKoma
        {
            get
            {
                if (_SelectedIndex < 0)
                {
                    return null;
                }
                else
                {
                    return _Items[_SelectedIndex];
                }
            }
        }

        //------------------------------------------------------
        public int KomaCount
        {
            get { return _Items.Count; }
        }

        //------------------------------------------------------

        public string GetNumberStr(int idx)
        {
            if ((idx < 0) || (idx >= _Items.Count)) return "";
            return _Items[idx].NumberStr;
        }
        //------------------------------------------------------
        public void SetNumberStr(int idx, string s)
        {
            if (_Locked == true) return;
            if ((idx < 0) || (idx >= _Items.Count)) return;
            _Items[idx].NumberStr = s;
        }
        //------------------------------------------------------
        public float GetDuration(int idx)
        {
            if ((idx < 0) || (idx >= _Items.Count)) return 0f;
            return _Items[idx].Duration;
        }
        //------------------------------------------------------
        public void SetDuration(int idx, float f)
        {
            if (_Locked == true) return;
            if ((idx < 0) || (idx >= _Items.Count)) return;
            if (_Items[idx].Duration != f)
            {
                _Items[idx].Duration = f;
                ChkDuration();
                _changeFlag = true;
                OnkomaChanged(new EventArgs());
            }
        }
        //------------------------------------------------------
        public bool GetPageBreak(int idx)
        {
            if ((idx < 0) || (idx >= _Items.Count)) return false;
            if (_Items[idx].Empty == true) return false;
            int ii = idx;
            if (_Items[idx].IsContinuedNext == true)
            {
                if (idx < _Items.Count - 1)
                {
                    for (int i = idx + 1; i < _Items.Count; i++)
                    {

                        if (_Items[i].IsContinuedNext == false)
                        {
                            ii = i;
                            break;
                        }

                    }
                }
                else
                {
                    ii = _Items.Count - 1;
                }
            }
            return _Items[ii].IsPageBreak;
        }
        //------------------------------------------------------
        public void SetPageBreak(int idx, bool b)
        {
            if (_Locked == true) return;
            if ((idx < 0) || (idx >= _Items.Count)) return;
            if (_Items[idx].Empty == true) return;
            int ii = idx;
            if (_Items[idx].IsContinuedNext == true)
            {
                if (idx < _Items.Count - 1)
                {
                    for (int i = idx + 1; i < _Items.Count; i++)
                    {

                        if (_Items[i].IsContinuedNext == false)
                        {
                            ii = i;
                            break;
                        }

                    }
                }
                else
                {
                    ii = _Items.Count - 1;
                }
            }

            if (_Items[ii].IsPageBreak != b)
            {
                _Items[ii].IsPageBreak = b;
                _SelectedIndex = ii;
                ChkItems();
                CurrentPageChk();
                _changeFlag = true;
                OnkomaChanged(new EventArgs());
            }
        }
        //-------------------------------------------------------------------------------
        public string WorkDir
        {
            get
            {
                if (Directory.Exists(_WorkDir) == false)
                {
                    _WorkDir = DefaultWorkDir;
                }
                return _WorkDir;
            }
        }
        //-------------------------------------------------------------------------------
        public string NazDir
        {
            get { return _NazDir; }
            set { SetNazDir(value); }
        }
        //-------------------------------------------------------------------------------
        public string ImageDir
        {
            get { return _ImageDir; }
        }
        //-------------------------------------------------------------------------------
        public string ThumsDir
        {
            get { return _ThumbDir; }
        }
        //-------------------------------------------------------------------------------
        public bool Enabled
        {
            get
            {
                return SetNazDir(_NazDir);
            }
        }

        //-------------------------------------------------------------------------------
        public KomaInfo GetItem(int idx)
        {
            if ((idx < 0) || (idx >= _Items.Count)) return null;
            return _Items[idx];

        }
        //-------------------------------------------------------------------------------
        public void SetItem(int idx, KomaInfo ki)
        {
            if (_Locked == true) return;
            if ((idx < 0) || (idx >= _Items.Count)) return;
            _Items[idx].Assign(ki);
            _changeFlag = true;

        }
        //-------------------------------------------------------------------------------
        public bool Empty
        {
            get
            {
                ChkSelected();
                if (_SelectedIndex < 0)
                { return false; }
                else
                {
                    return _Items[_SelectedIndex].Empty;
                }
            }
        }
        //-------------------------------------------------------------------------------
        public bool IsContinued
        {
            get
            {
                ChkSelected();
                if (_SelectedIndex < 0)
                { return false; }
                else
                {
                    return _Items[_SelectedIndex].IsContinued;
                }
            }
            set
            {
                if (_Locked == true) return;
                ChkSelected();
                int idx = _SelectedIndex;
                if (idx >= 0)
                {
                    if (_Items[idx].IsContinued != value)
                    {
                        if (_Items[idx].Empty == true)
                        {
                            ChkPageBrakeEmpty(idx, true);
                        }
                        //trueになった場合PageBreak/PartEndの処理
                        if (value == true)
                        {
                            if (idx > 0)
                            {
                                //前のコマの状態を調べる
                                int pp = -1;
                                for (int i = idx - 1; i >= 0; i--)
                                {
                                    if (_Items[i].Empty == false)
                                    {
                                        pp = i;
                                        break;
                                    }
                                }
                                if (pp >= 0)
                                {
                                    if (_Items[pp].IsPageBreak == true)
                                    {
                                        _Items[pp].IsPageBreak = false;
                                        _Items[idx].IsPageBreak = true;
                                    }
                                    if (_Items[pp].IsPartEnd == true)
                                    {
                                        _Items[pp].IsPartEnd = false;
                                        _Items[idx].IsPartEnd = true;
                                    }
                                }
                            }
                        }
                        _CopyStartIndex = -1;
                        _Items[idx].IsContinued = value;
                        ChkItems();
                        _changeFlag = true;
                        OnkomaChanged(new EventArgs());
                    }
                }
            }
        }
        //-------------------------------------------------------------------------------
        public bool IsPageBreak
        {
            get
            {
                ChkSelected();
                if (_SelectedIndex < 0)
                { return false; }
                else
                {
                    return GetPageBreak(_SelectedIndex);
                }
            }
            set
            {
                if (_Locked == true) return;
                _CopyStartIndex = -1;

                ChkSelected();
                SetPageBreak(_SelectedIndex, value);
                
            }
        }
        //-------------------------------------------------------------------------------
        public bool IsNoneNumber
        {
            get
            {
                ChkSelected();
                if (_SelectedIndex < 0)
                { return false; }
                else
                {
                    return _Items[_SelectedIndex].IsNoneNumber;
                }
            }
            set
            {
                if (_Locked == true) return;
                ChkSelected();
                int idx = _SelectedIndex;
                if (idx >= 0)
                {
                    if (_Items[idx].IsNoneNumber != value)
                    {
                        if (_Items[idx].Empty == true)
                        {
                            ChkPageBrakeEmpty(idx, false);
                        }

                        _CopyStartIndex = -1;

                        _Items[idx].IsNoneNumber = value;
                        ChkIsContinued();//継続コマの確認
                        ChkNumber();//カットナンバー割り振り
                        ChkDuration();//秒数計算
                        _changeFlag = true;
                        OnkomaChanged(new EventArgs());
                    }
                }
            }
        }
        //-------------------------------------------------------------------------------
        public bool IsContinuedNext
        {
            get
            {
                ChkSelected();
                if (_SelectedIndex < 0)
                { return false; }
                else
                {
                    return _Items[_SelectedIndex].IsContinuedNext;
                }
            }

        }
        //-------------------------------------------------------------------------------
        public void SetMemo(int idx, string value)
        {
            if (_Locked == true) return;
            if ((idx < 0) || (idx >= _Items.Count)) return;
            if (_Items[idx].Memo != value)
            {
                _Items[idx].Memo = value;
                _changeFlag = true;
            }
        }
		//-------------------------------------------------------------------------------
		public void SetMemoU(int idx, string value)
		{
			if (_Locked == true) return;
			if ((idx < 0) || (idx >= _Items.Count)) return;
			if (_Items[idx].MemoU != value)
			{
				_Items[idx].MemoU = value;
				_changeFlag = true;
			}
		}
		//-------------------------------------------------------------------------------
        public void SetWords(int idx, string value)
        {
            if (_Locked == true) return;
            if ((idx < 0) || (idx >= _Items.Count)) return;
            if (_Items[idx].Words != value)
            {
                _Items[idx].Words = value;
                _changeFlag = true;
            }
        }
		//-------------------------------------------------------------------------------
		public void SetWordsU(int idx, string value)
		{
			if (_Locked == true) return;
			if ((idx < 0) || (idx >= _Items.Count)) return;
			if (_Items[idx].WordsU != value)
			{
				_Items[idx].WordsU = value;
				_changeFlag = true;
			}
		}
		//-------------------------------------------------------------------------------
        public string GetMemo(int idx)
        {
            if ((idx < 0) || (idx >= _Items.Count)) return string.Empty;
            return _Items[idx].Memo;
        }
		//-------------------------------------------------------------------------------
		public string GetMemoU(int idx)
		{
			if ((idx < 0) || (idx >= _Items.Count)) return string.Empty;
			return _Items[idx].MemoU;
		}
		//-------------------------------------------------------------------------------
        public string GetWords(int idx)
        {
            if ((idx < 0) || (idx >= _Items.Count)) return string.Empty;
            return _Items[idx].Words;
        }
		//-------------------------------------------------------------------------------
		public string GetWordsU(int idx)
		{
			if ((idx < 0) || (idx >= _Items.Count)) return string.Empty;
			return _Items[idx].WordsU;
		}
		//-------------------------------------------------------------------------------
        public string GetKomaData(int idx)
        {
            if ((idx < 0) || (idx >= _Items.Count)) return string.Empty;
            return _Items[idx].ToText();
        }
        //-------------------------------------------------------------------------------
        public void SetKomaData(int idx, string value)
        {
            if (_Locked == true) return;
            if ((idx < 0) || (idx >= _Items.Count)) return;
            _Items[idx].FromText(value);
        }
        //-------------------------------------------------------------------------------
        public int NumberStart
        {
            get { return _NumberStart; }
            set
            {
                if (_NumberStart != value)
                {
                    _NumberStart = value;
                    _changeFlag = true;
                }
            }
        }
        //-------------------------------------------------------------------------------
        public int PageNumberStart
        {
            get { return _PageNumberStart; }
            set
            {
                if (_PageNumberStart != value)
                {
                    _PageNumberStart = value;
                    _changeFlag = true;
                }
            }
        }
        //-------------------------------------------------------------------------------
        public float fps
        {
            get { return _fps; }
            set { _fps = value; }
        }
        //-------------------------------------------------------------------------------
        public string DefaultWorkDir
        {
            get
            {
                try
                {
                    return Path.Combine(System.Environment.GetFolderPath(Environment.SpecialFolder.Personal), def.WorkDirName);
                }
                catch
                {
                    return "";
                }
            }
        }
        //-------------------------------------------------------------------------------
        public bool GetEmpty(int idx)
        {
            if ((idx < 0) || (idx >= _Items.Count)) return false;

            return _Items[idx].Empty;
        }
        //-------------------------------------------------------------------------------
        public string GetPictureName(int idx)
        {
            if ((idx < 0) || (idx >= _Items.Count)) return string.Empty;

            return _Items[idx].PictName;
        }
        //-------------------------------------------------------------------------------
        public void SetPictureName(int idx, string name)
        {
            if (_Locked == true) return;
            if ((idx < 0) || (idx >= _Items.Count)) return;
            if (_Items[idx].Empty == true) return;
            if (_Items[idx].Pic.name != name)
            {
                _Items[idx].Pic.Clear();
                _Items[idx].Pic.name = name;
                _changeFlag = true;
                OnkomaChanged(new EventArgs());
            }
        }
        //------------------------------------------------
        public int NoneDurationCut
        {
            get { return _NoneDurationCut; }
        }
        //------------------------------------------------
        public float TargetDuration
        {
            get { return _TargtDuration; }
            set { _TargtDuration = value; }
        }
        //------------------------------------------------
        public string DurationInfo
        {
            get
            {
                if (_TargtDuration <= 0)
                {
                    return string.Empty;
                }
                float f = _TargtDuration - _Duration;
                if (f == 0)
                {
                    return "定尺です。";
                }
                else if (f > 0)
                {
                    return "後、" + DurationToSecFrame(f) + " です";
                }
                else
                {
                    return " " + DurationToSecFrame(f * -1) + " Over!";
                }
            }
        }
        //------------------------------------------------
        public string ParCutSec
        {
            get { return DurationToSecFrame(_ParCutSec); }
        }
        //------------------------------------------------
        public string CutAddInfo
        {
            get
            {
                if (_TargtDuration <= 0)
                {
                    return string.Empty;
                }
                float f = _TargtDuration - _Duration;
                if (f == 0)
                {
                    return string.Empty;
                }
                int v = (int)Math.Abs(Math.Round(f / _ParCutSec));
                if (f > 0)
                {
                    return "約" + v.ToString() + "カット足し";
                }
                else
                {
                    return "約" + v.ToString() + "カット削除";
                }
            }
        }
        //----------------------------------------------------------------------------------
        public ContVersion Version
        {
            get { return _Version; }
            set { _Version = value; }
        }
        //----------------------------------------------------------------------------------
        public float Duration
        {
            get { return _Duration; }
        }
        //----------------------------------------------------------------------------------
        public String Frame
        {
            get { return Math.Round(_Duration * _fps).ToString(); }
        }
        //----------------------------------------------------------------------------------
        public String SecKoma
        {
            get { return DurationToSecFrame(_Duration); }
        }
        public int CutCount
        {
            get { return _CutCount; }
        }
        //----------------------------------------------------------------------------------
        public int ItemsCount
        {
            get { return _Items.Count; }
        }
        //-------------------------------------------------------------------------------
        public string NazCaption
        {
            get
            {
                string p = Path.GetFileName(_NazDir);
                if (_NazFileName != def.NazFileName)
                {
                    p += " [ " + Path.GetFileNameWithoutExtension(_NazFileName) + " ]";
                }
                if (_Locked == true)
                {
                    p += " Locked!";
                }
                return p;
            }
        }

    }
}
