﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;


namespace ContEditorNazoh
{
    public class ContPrint : Component
    {
        private ContDocument _ContDocument;
        private PrintDocument pd = new PrintDocument();
        private PrintDialog pdlg = new PrintDialog();
        PageSetupDialog psd = new PageSetupDialog();
        PrintPreviewDialog ppd = new PrintPreviewDialog();


        private int _CurrentPage = 0;
        private ContDraw _ContDraw = null;

        //-------------------------------------------------------------------------
        public ContPrint()
        {

            //PrintPageイベントハンドラの追加
            pd.PrintPage += new PrintPageEventHandler(pd_PrintPage);

            pdlg.Document = pd;
            psd.Document = pd;
            ppd.Document = pd;
            //ページ指定できるようにする
            //pdlg.AllowSomePages = true;

            PrefLoad();
        }
        //-------------------------------------------------------------------------
        public ContDocument ContDocument
        {
            get { return _ContDocument; }
            set
            {
                _ContDocument = value;
                if (value != null)
                {
                    _CurrentPage = _ContDocument.CurrentPage + 1;
                    _ContDraw = new ContDraw(_ContDocument,true);
                    pdlg.AllowSomePages = true;
                    pdlg.PrinterSettings.MinimumPage = 1;
                    pdlg.PrinterSettings.MaximumPage = _ContDocument.PageCount;
                    GetPaperSize();
                }
                else
                {
                    _CurrentPage = 1;
                    _ContDraw = null;
                }
            }
        }
        //-------------------------------------------------------------------------
        private void GetPaperSize()
        {

            if (_ContDraw != null)
            {
                _ContDraw.SetPaperSize(pd.DefaultPageSettings.PaperSize);
            }
        }
        //-------------------------------------------------------------------------
        private void pd_PrintPage(object sender,PrintPageEventArgs e)
        {
            if (_ContDocument == null) { return; }
            if (_ContDraw == null) { return; }

            if ( (e.PageSettings.PrinterSettings.PrintRange ==PrintRange.SomePages) && (_CurrentPage == 1))
            {
                _CurrentPage = e.PageSettings.PrinterSettings.FromPage;
            }





            _ContDraw.CurrentPage = _CurrentPage -1;
            _ContDraw.DrawPrintPage(e.Graphics);

            //次のページがあるか調べる
            if (_CurrentPage >= _ContDocument.PageCount || ((e.PageSettings.PrinterSettings.PrintRange == PrintRange.SomePages) && (e.PageSettings.PrinterSettings.ToPage <= _CurrentPage)))
            {
                //次のページがないことを通知する
                e.HasMorePages = false;
                _CurrentPage = 1;
            }
            else
            {
                e.HasMorePages = true;
                _CurrentPage++;
            }

        }
        //-------------------------------------------------------------------------
        public int CurrentPage
        {
            get
            {
                return _CurrentPage - 1 ;
            }
            set
            {
                _CurrentPage = value + 1;
            }
        }
        //-------------------------------------------------------------------------
        public void ShowPageSetup()
        {
            if (_ContDocument == null) return;
            GetPaperSize();
            if (psd.ShowDialog() == DialogResult.OK)
            {
                GetPaperSize();
            }
        }
        //-------------------------------------------------------------------------
        public void ShowPrintPreview()
        {
            if (_ContDocument == null) return;
            PrefLoad();

            GetPaperSize();
            if (ppd.ShowDialog() == DialogResult.OK)
            {
                GetPaperSize();
            }
            PrefSave();
        }
        //-------------------------------------------------------------------------
        public void ShowPrint()
        {
            if (_ContDocument == null) return;
            GetPaperSize();
            //ページ指定できるようにする
            pdlg.AllowSomePages = true;
            pdlg.PrinterSettings.MinimumPage = 1;
            pdlg.PrinterSettings.MaximumPage = _ContDocument.PageCount;
            //印刷開始と終了ページを指定する
            pdlg.PrinterSettings.FromPage = pdlg.PrinterSettings.MinimumPage;
            pdlg.PrinterSettings.ToPage = pdlg.PrinterSettings.MaximumPage;

            //印刷の選択ダイアログを表示する
            if (pdlg.ShowDialog() == DialogResult.OK)
            {
                GetPaperSize();
                //OKがクリックされた時は印刷する
                pd.Print();

            }
        }

        //-------------------------------------------------------------------------
        public void SavePringImage()
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Title = "印刷イメージの保存";
            dlg.DefaultExt = ".png";
            dlg.Filter = "PNG(*.png)|*.png|ALL(*.*)|*.*";
            dlg.FilterIndex = 1;
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    GetPaperSize();
                    Bitmap bmp = new Bitmap(_ContDraw.PaperWidthP, _ContDraw.PaperHeightP);
                    bmp.SetResolution(def.dpi, def.dpi);
                    Graphics g = Graphics.FromImage(bmp);
                    g.PageUnit = GraphicsUnit.Millimeter;
                    _ContDraw.CurrentPage = _ContDocument.CurrentPage;
                    _ContDraw.DrawPrintPage(g);
                    bmp.Save(dlg.FileName);
                }
                catch
                {
                    MessageBox.Show("Save Error!");
                }
            }
        }
        //-------------------------------------------------------------------------
        private void PrefSave()
        {
            string p = Path.ChangeExtension(Application.ExecutablePath, def.NazPrefPrntExt);
            SaveFiles sv = new SaveFiles(def.PrintHeader);

            Rectangle r = ppd.DesktopBounds;
            sv.SetInt("Left", r.Left);
            sv.SetInt("Top", r.Top);
            sv.SetInt("Width", r.Width);
            sv.SetInt("Height", r.Height);

            int zm = (int)Math.Round(ppd.PrintPreviewControl.Zoom* 1000);
            sv.SetInt("Zoom", zm);
            sv.SaveToFile(p);

        }
        //---------------------------------------------------------------------------
        public void PrefLoad()
        {
            string p = Path.ChangeExtension(Application.ExecutablePath, def.NazPrefPrntExt);
            SaveFiles sv = new SaveFiles(def.PrintHeader);
            sv.LoadFromFile(p);
            int l = sv.GetInt("Left", 0);
            int t = sv.GetInt("Top", 0);
            int w = sv.GetInt("Width", 0);
            int h = sv.GetInt("Height", 0);
            if ((l > 0) && (t > 0) && (w > 0) && (h > 0))
            {
                ppd.StartPosition = FormStartPosition.Manual;
                ppd.DesktopBounds = new Rectangle(l, t, w, h);
            }
            else
            {
                ppd.StartPosition = FormStartPosition.CenterScreen;
            }
            int zm = sv.GetInt("Zoom", 1000);
            ppd.PrintPreviewControl.Zoom = (float)zm / 1000;

        }
        //-------------------------------------------------------------------------
    }
}
