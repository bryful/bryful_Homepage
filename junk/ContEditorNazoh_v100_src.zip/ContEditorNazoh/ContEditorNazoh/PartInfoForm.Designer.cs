﻿namespace ContEditorNazoh
{
    partial class PartInfoForm
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
			this.panel1 = new System.Windows.Forms.Panel();
			this.tbBase = new System.Windows.Forms.TextBox();
			this.tbTotal = new System.Windows.Forms.TextBox();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.panel1.AutoScroll = true;
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.tbBase);
			this.panel1.Location = new System.Drawing.Point(10, 20);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(258, 42);
			this.panel1.TabIndex = 0;
			// 
			// tbBase
			// 
			this.tbBase.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.tbBase.BackColor = System.Drawing.SystemColors.Control;
			this.tbBase.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.tbBase.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
			this.tbBase.Location = new System.Drawing.Point(12, 3);
			this.tbBase.Multiline = true;
			this.tbBase.Name = "tbBase";
			this.tbBase.ReadOnly = true;
			this.tbBase.Size = new System.Drawing.Size(238, 18);
			this.tbBase.TabIndex = 0;
			this.tbBase.Text = "001 A: カット数:        秒数:";
			this.tbBase.Visible = false;
			// 
			// tbTotal
			// 
			this.tbTotal.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.tbTotal.BackColor = System.Drawing.SystemColors.Control;
			this.tbTotal.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.tbTotal.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
			this.tbTotal.Location = new System.Drawing.Point(12, 6);
			this.tbTotal.Multiline = true;
			this.tbTotal.Name = "tbTotal";
			this.tbTotal.ReadOnly = true;
			this.tbTotal.Size = new System.Drawing.Size(256, 12);
			this.tbTotal.TabIndex = 1;
			this.tbTotal.Text = "総カット数:        合計秒数:　　後　　秒";
			// 
			// PartInfoForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(280, 74);
			this.Controls.Add(this.tbTotal);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
			this.MaximizeBox = false;
			this.MaximumSize = new System.Drawing.Size(500, 600);
			this.MinimizeBox = false;
			this.MinimumSize = new System.Drawing.Size(250, 100);
			this.Name = "PartInfoForm";
			this.ShowIcon = false;
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "パートの情報";
			this.TopMost = true;
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.PartInfoForm_FormClosed);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tbBase;
        private System.Windows.Forms.TextBox tbTotal;
    }
}