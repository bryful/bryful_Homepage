﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class CutNumberDlg : Form
    {
        public CutNumberDlg()
        {
            InitializeComponent();
            this.Cursor = System.Windows.Forms.Cursors.Default;
        }
        //--------------------------------------------------
        public string NumberStr
        {
            get { return tbNew.Text.Trim(); }
            set
            {
                tbNew.Text
                    = tbOrg.Text
                    = value.Trim();
            }
        }

        private void CutNumberDlg_Load(object sender, EventArgs e)
        {
            this.Cursor = System.Windows.Forms.Cursors.Default;
        }
        //--------------------------------------------------
    }
}
