﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ContEditorNazoh
{
	public partial class ContSettingDlg : Form
	{
		private ContDocument _ContDocument;
		public ContSettingDlg(ContDocument cd)
		{
			InitializeComponent();
			_ContDocument = cd;
			GetParams();
		}
		//-----------------------------------------------------------
		private void GetParams()
		{
			if (_ContDocument == null) return;

			cbLock.Checked = _ContDocument.Locked;

			tbTitle.Text = _ContDocument.Title;
			tbSubTitle.Text = _ContDocument.SubTitle;
			tbOPUS.Text = _ContDocument.OPUS;
			tbCreateUser.Text = _ContDocument.CreateUser;
			tbUpdateUser.Text = _ContDocument.UpdateUser;
			tbComment.Text = _ContDocument.Comment;
			tbCampanyName.Text = _ContDocument.CampanyName;

			NumberStart = _ContDocument.NumberStart;
			PageNumberStart = _ContDocument.PageNumberStart;


            tbFps.Text = _ContDocument.fps.ToString();
            SetTargetDuration(_ContDocument.TargetDuration);

            cmbVersion.Items.Clear();

            for (int i = 0; i < (int)ContVersion.Count; i++)
            {
                cmbVersion.Items.Add(_ContDocument.VerCaption[i]);
            }
            cmbVersion.SelectedIndex = (int)_ContDocument.Version;


			cbIsPrintTitle.Checked = _ContDocument.IsPrintTitle;
			cbIsPrintSubTitle.Checked = _ContDocument.IsPrintSubTitle;
			cbIsPrintOPUS.Checked = _ContDocument.IsPrintOPUS;
			cbIsPrintCampany.Checked = _ContDocument.IsPrintCampany;
			cbIsPrintDurationInfo.Checked = _ContDocument.IsPrintDurationInfo;
            cbIsPrintPartCaption.Checked = _ContDocument.IsPrintPartCaption;
		}
        //-----------------------------------------------------------
        public bool Loacked
		{
			get { return cbLock.Checked; }
			set { cbLock.Checked = value; }
		}
		//-----------------------------------------------------------
		public string ContTitle
		{
			get { return tbTitle.Text; }
			set { tbTitle.Text = value; }
		}
		//-----------------------------------------------------------
		public string SubTitle
		{
			get { return tbSubTitle.Text; }
			set { tbSubTitle.Text = value; }
		}
		//-----------------------------------------------------------
		public string OPUS
		{
			get { return tbOPUS.Text; }
			set { tbOPUS.Text = value; }
		}
		//-----------------------------------------------------------
		public string CreateUser
		{
			get { return tbCreateUser.Text; }
			set { tbCreateUser.Text = value; }
		}
		//-----------------------------------------------------------
		public string UpdateUser
		{
			get { return tbUpdateUser.Text; }
			set { tbUpdateUser.Text = value; }
		}
		//-----------------------------------------------------------
		public string CampanyName
		{
			get { return tbCampanyName.Text; }
			set { tbCampanyName.Text = value; }
		}
		//-----------------------------------------------------------
		public string Comment
		{
			get { return tbComment.Text; }
			set { tbComment.Text = value; }
		}
		//-----------------------------------------------------------
		public bool IsPrintTitle
		{
			get { return cbIsPrintTitle.Checked; }
			set { cbIsPrintTitle.Checked = value;}
		}
		//-----------------------------------------------------------
		public bool IsPrintSubTitle
		{
			get { return cbIsPrintTitle.Checked; }
			set { cbIsPrintTitle.Checked = value; }
		}
		//-----------------------------------------------------------
		public bool IsPrintOPUS
		{
			get { return cbIsPrintOPUS.Checked; }
			set { cbIsPrintOPUS.Checked = value; }
		}
		//-----------------------------------------------------------
		public bool IsPrintCampany
		{
			get { return cbIsPrintCampany.Checked; }
			set { cbIsPrintCampany.Checked = value; }
		}
		//-----------------------------------------------------------
		public bool IsPrintDurationInfo
		{
			get { return cbIsPrintDurationInfo.Checked; }
			set { cbIsPrintDurationInfo.Checked = value; }
		}
        //-----------------------------------------------------------
        public bool IsPrintPartCaption
        {
            get { return cbIsPrintPartCaption.Checked; }
            set { cbIsPrintPartCaption.Checked = value; }
        }
        //-----------------------------------------------------------
		public int NumberStart
		{
			get
			{
				int i = 0;
				if (int.TryParse(tbNumberStart.Text, out i) == true)
				{
					return i;
				}
				else
				{
					return 1;
				}
			}
			set
			{
				tbNumberStart.Text = value.ToString();
			}
		}
		//-----------------------------------------------------------
		public int PageNumberStart
		{
			get
			{
				int i = 0;
				if (int.TryParse(tbPageNumberStart.Text, out i) == true)
				{
					return i;
				}
				else
				{
					return 1;
				}
			}
			set
			{
				tbPageNumberStart.Text = value.ToString();
			}
		}

		//-----------------------------------------------------------
		private void tbNumberStart_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (((e.KeyChar < '0') || (e.KeyChar > '9')) && (e.KeyChar != '\b'))
			{
				e.Handled = true;
			}
		}
		//-----------------------------------------------------------
        public ContVersion Version
        {
            get 
            {
                int si = cmbVersion.SelectedIndex;
                if (si < 0) si = 1;
                return (ContVersion)si; 
            }
            set
            {
                int v = (int)value;
                if ((v < 0) || (v >= (int)ContVersion.Count)) v = -1;
                cmbVersion.SelectedIndex = v;
            }
        }
		//-----------------------------------------------------------
		public float TargetDuration
		{
			get 
			{
				float v = GetTargetDuration();
				if (v < 0) v = 0;
				return v;
			}
            set
            {
                SetTargetDuration(value);
            }

		}

        private void ContSettingDlg_Load(object sender, EventArgs e)
        {

        }
		//-----------------------------------------------------------
		private void tbTargetMin_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (((e.KeyChar < '0') || (e.KeyChar > '9')) && (e.KeyChar != '\b'))
			{
				e.Handled = true;
			}
		}
		//-----------------------------------------------------------
		private void SetTargetDuration(float f)
		{
			float v = (int)Math.Round(f);
            int sec = (int)Math.Round(v % 60);
            int min = (int)Math.Round(v / 60);

            tbTargetMin.Text = min.ToString();
            tbTargetSec.Text = sec.ToString();
		}

		//-----------------------------------------------------------
		private float GetTargetDuration()
		{
			float f = 0;
			bool er = false;
			if (tbTargetMin.Text != "")
			{
				float ff = 0;
				if (float.TryParse(tbTargetMin.Text, out ff) == true)
				{
					f = ff * 60;
				}
				else
				{
					er = true;
				}
			}
			if (tbTargetSec.Text != "")
			{
				float ff = 0;
				if (float.TryParse(tbTargetSec.Text, out ff) == true)
				{
					f += ff;
				}
				else
				{
					er = true;
				}
			}
			if (er == true)
			{
				btnOK.Enabled = false;
				return -1;
			}
			else
			{
				btnOK.Enabled = true;
				return f;
			}
		}
		//-----------------------------------------------------------
		private void tbTargetMin_TextChanged(object sender, EventArgs e)
		{
			bool noErr = true;
			float f = GetTargetDuration();
			if (f < 0)
			{
				noErr = false;
			}
			float ff = 0;
			if (float.TryParse(tbFps.Text, out ff) ==false)
			{
				noErr = false;
			}
			btnOK.Enabled = noErr;
		}

		//-----------------------------------------------------------
		private void tbFps_KeyPress(object sender, KeyPressEventArgs e)
		{
			string s = tbFps.Text;
			if (e.KeyChar == '.')
			{
				if (s.IndexOf('.') >= 0)
				{
					e.Handled = true;
				}
			}
			else
			{
				if (((e.KeyChar < '0') || (e.KeyChar > '9')) && (e.KeyChar != '\b'))
				{
					e.Handled = true;
				}
			}

		}
        //-----------------------------------------------------------
        public float fps
        {
            get
            {
                float f = 0;
                if (float.TryParse(tbFps.Text, out f) == true)
                {
                    return f;
                }
                else
                {
                    return 24f;
                }
            }
            set
            {
                tbFps.Text = value.ToString();
            }
        }

        private void cbIsPrintOPUS_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void tbOPUS_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
