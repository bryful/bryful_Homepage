﻿namespace ContEditorNazoh
{
    partial class CopyProgress
    {
        /// <summary> 
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region コンポーネント デザイナーで生成されたコード

        /// <summary> 
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を 
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.lbProgress = new System.Windows.Forms.Label();
            this.plProgress = new System.Windows.Forms.Panel();
            this.plProgress.SuspendLayout();
            this.SuspendLayout();
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(3, 22);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(227, 23);
            this.progressBar1.TabIndex = 1;
            // 
            // lbProgress
            // 
            this.lbProgress.AutoSize = true;
            this.lbProgress.Font = new System.Drawing.Font("MS UI Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbProgress.Location = new System.Drawing.Point(3, 7);
            this.lbProgress.Name = "lbProgress";
            this.lbProgress.Size = new System.Drawing.Size(31, 11);
            this.lbProgress.TabIndex = 0;
            this.lbProgress.Text = "label1";
            // 
            // plProgress
            // 
            this.plProgress.BackColor = System.Drawing.SystemColors.ControlLight;
            this.plProgress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.plProgress.Controls.Add(this.progressBar1);
            this.plProgress.Controls.Add(this.lbProgress);
            this.plProgress.Location = new System.Drawing.Point(0, 0);
            this.plProgress.Name = "plProgress";
            this.plProgress.Size = new System.Drawing.Size(239, 57);
            this.plProgress.TabIndex = 10;
            // 
            // CopyProgress
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.plProgress);
            this.Name = "CopyProgress";
            this.Size = new System.Drawing.Size(387, 81);
            this.plProgress.ResumeLayout(false);
            this.plProgress.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label lbProgress;
        private System.Windows.Forms.Panel plProgress;
    }
}
