﻿namespace ContEditorNazoh
{
	partial class ContPreviewForm
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
			this.toolStrip1 = new System.Windows.Forms.ToolStrip();
			this.btnReDraw = new System.Windows.Forms.ToolStripButton();
			this.btnHome = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
			this.btnTopPage = new System.Windows.Forms.ToolStripButton();
			this.btnPrevPage = new System.Windows.Forms.ToolStripButton();
			this.btnNextPage = new System.Windows.Forms.ToolStripButton();
			this.btnLastPage = new System.Windows.Forms.ToolStripButton();
			this.btnCurrentSet = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.btnClose = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
			this.PageScrol = new System.Windows.Forms.VScrollBar();
			this.toolStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// toolStrip1
			// 
			this.toolStrip1.AutoSize = false;
			this.toolStrip1.BackColor = System.Drawing.SystemColors.Control;
			this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Right;
			this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnReDraw,
            this.btnHome,
            this.toolStripSeparator2,
            this.btnTopPage,
            this.btnPrevPage,
            this.btnNextPage,
            this.btnLastPage,
            this.btnCurrentSet,
            this.toolStripSeparator1,
            this.btnClose,
            this.toolStripSeparator3});
			this.toolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
			this.toolStrip1.Location = new System.Drawing.Point(647, 0);
			this.toolStrip1.Name = "toolStrip1";
			this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
			this.toolStrip1.Size = new System.Drawing.Size(105, 884);
			this.toolStrip1.TabIndex = 1;
			this.toolStrip1.Text = "toolStrip1";
			this.toolStrip1.TextDirection = System.Windows.Forms.ToolStripTextDirection.Vertical90;
			// 
			// btnReDraw
			// 
			this.btnReDraw.Image = global::ContEditorNazoh.Properties.Resources.RestartHS;
			this.btnReDraw.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnReDraw.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnReDraw.Name = "btnReDraw";
			this.btnReDraw.Size = new System.Drawing.Size(103, 20);
			this.btnReDraw.Text = "再描画";
			this.btnReDraw.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnReDraw.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.btnReDraw.Click += new System.EventHandler(this.btnReDraw_Click);
			// 
			// btnHome
			// 
			this.btnHome.Image = global::ContEditorNazoh.Properties.Resources.WindowsHS;
			this.btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnHome.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnHome.Name = "btnHome";
			this.btnHome.Size = new System.Drawing.Size(103, 20);
			this.btnHome.Text = "編集画面";
			this.btnHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnHome.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
			// 
			// toolStripSeparator2
			// 
			this.toolStripSeparator2.Name = "toolStripSeparator2";
			this.toolStripSeparator2.Size = new System.Drawing.Size(103, 6);
			this.toolStripSeparator2.TextDirection = System.Windows.Forms.ToolStripTextDirection.Vertical90;
			// 
			// btnTopPage
			// 
			this.btnTopPage.Image = global::ContEditorNazoh.Properties.Resources.DataContainer_MoveFirstHS;
			this.btnTopPage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnTopPage.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnTopPage.Name = "btnTopPage";
			this.btnTopPage.Size = new System.Drawing.Size(103, 20);
			this.btnTopPage.Text = "最初のページへ";
			this.btnTopPage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnTopPage.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.btnTopPage.Click += new System.EventHandler(this.btnTopPage_Click);
			// 
			// btnPrevPage
			// 
			this.btnPrevPage.Image = global::ContEditorNazoh.Properties.Resources.FillUpHS;
			this.btnPrevPage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnPrevPage.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnPrevPage.Name = "btnPrevPage";
			this.btnPrevPage.Size = new System.Drawing.Size(103, 20);
			this.btnPrevPage.Text = "前のページヘ";
			this.btnPrevPage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnPrevPage.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.btnPrevPage.Click += new System.EventHandler(this.btnPrevPage_Click);
			// 
			// btnNextPage
			// 
			this.btnNextPage.Image = global::ContEditorNazoh.Properties.Resources.FillDownHS;
			this.btnNextPage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnNextPage.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnNextPage.Name = "btnNextPage";
			this.btnNextPage.Size = new System.Drawing.Size(103, 20);
			this.btnNextPage.Text = "次のページヘ";
			this.btnNextPage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnNextPage.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.btnNextPage.Click += new System.EventHandler(this.btnNextPage_Click);
			// 
			// btnLastPage
			// 
			this.btnLastPage.Image = global::ContEditorNazoh.Properties.Resources.DataContainer_MoveLastHS;
			this.btnLastPage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLastPage.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnLastPage.Name = "btnLastPage";
			this.btnLastPage.RightToLeftAutoMirrorImage = true;
			this.btnLastPage.Size = new System.Drawing.Size(103, 20);
			this.btnLastPage.Text = "最後のページへ";
			this.btnLastPage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLastPage.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.btnLastPage.Click += new System.EventHandler(this.btnLastPage_Click);
			// 
			// btnCurrentSet
			// 
			this.btnCurrentSet.Image = global::ContEditorNazoh.Properties.Resources.OpenFile;
			this.btnCurrentSet.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnCurrentSet.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnCurrentSet.Name = "btnCurrentSet";
			this.btnCurrentSet.RightToLeftAutoMirrorImage = true;
			this.btnCurrentSet.Size = new System.Drawing.Size(103, 20);
			this.btnCurrentSet.Text = "ページを合わせる";
			this.btnCurrentSet.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnCurrentSet.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.btnCurrentSet.Click += new System.EventHandler(this.btnCurrentSet_Click);
			// 
			// toolStripSeparator1
			// 
			this.toolStripSeparator1.Name = "toolStripSeparator1";
			this.toolStripSeparator1.Size = new System.Drawing.Size(103, 6);
			this.toolStripSeparator1.TextDirection = System.Windows.Forms.ToolStripTextDirection.Vertical90;
			// 
			// btnClose
			// 
			this.btnClose.Image = global::ContEditorNazoh.Properties.Resources.DocumentHS;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(103, 20);
			this.btnClose.Text = "閉じる";
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// toolStripSeparator3
			// 
			this.toolStripSeparator3.Name = "toolStripSeparator3";
			this.toolStripSeparator3.Size = new System.Drawing.Size(103, 6);
			this.toolStripSeparator3.TextDirection = System.Windows.Forms.ToolStripTextDirection.Vertical90;
			// 
			// PageScrol
			// 
			this.PageScrol.LargeChange = 1;
			this.PageScrol.Location = new System.Drawing.Point(630, 9);
			this.PageScrol.Name = "PageScrol";
			this.PageScrol.Size = new System.Drawing.Size(17, 866);
			this.PageScrol.TabIndex = 2;
			this.PageScrol.ValueChanged += new System.EventHandler(this.vScrollBar1_ValueChanged);
			// 
			// ContPreviewForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(752, 884);
			this.Controls.Add(this.PageScrol);
			this.Controls.Add(this.toolStrip1);
			this.DoubleBuffered = true;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ContPreviewForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "コンテのプレビュー";
			this.Activated += new System.EventHandler(this.ContPreviewForm_Activated);
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ContPreviewForm_FormClosed);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.ContPreviewForm_Paint);
			this.toolStrip1.ResumeLayout(false);
			this.toolStrip1.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btnReDraw;
        private System.Windows.Forms.ToolStripButton btnNextPage;
        private System.Windows.Forms.ToolStripButton btnPrevPage;
        private System.Windows.Forms.ToolStripButton btnTopPage;
        private System.Windows.Forms.ToolStripButton btnClose;
        private System.Windows.Forms.ToolStripButton btnLastPage;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
		private System.Windows.Forms.ToolStripButton btnHome;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
		private System.Windows.Forms.ToolStripButton btnCurrentSet;
        private System.Windows.Forms.VScrollBar PageScrol;
	}
}