﻿namespace ContEditorNazoh
{
	partial class ContSettingDlg
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbIsPrintDurationInfo = new System.Windows.Forms.CheckBox();
            this.cbIsPrintCampany = new System.Windows.Forms.CheckBox();
            this.cbIsPrintSubTitle = new System.Windows.Forms.CheckBox();
            this.cbIsPrintOPUS = new System.Windows.Forms.CheckBox();
            this.cbIsPrintTitle = new System.Windows.Forms.CheckBox();
            this.tbFps = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tbTargetSec = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tbTargetMin = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cmbVersion = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tbComment = new System.Windows.Forms.TextBox();
            this.tbCampanyName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbUpdateUser = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbCreateUser = new System.Windows.Forms.TextBox();
            this.tbSubTitle = new System.Windows.Forms.TextBox();
            this.tbOPUS = new System.Windows.Forms.TextBox();
            this.tbTitle = new System.Windows.Forms.TextBox();
            this.cbLock = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tbPageNumberStart = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbNumberStart = new System.Windows.Forms.TextBox();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.cbIsPrintPartCaption = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.cbIsPrintCampany);
            this.groupBox1.Controls.Add(this.cbIsPrintSubTitle);
            this.groupBox1.Controls.Add(this.cbIsPrintOPUS);
            this.groupBox1.Controls.Add(this.cbIsPrintTitle);
            this.groupBox1.Controls.Add(this.tbFps);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.tbTargetSec);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.tbTargetMin);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.cmbVersion);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.tbComment);
            this.groupBox1.Controls.Add(this.tbCampanyName);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.tbUpdateUser);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tbCreateUser);
            this.groupBox1.Controls.Add(this.tbSubTitle);
            this.groupBox1.Controls.Add(this.tbOPUS);
            this.groupBox1.Controls.Add(this.tbTitle);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(556, 255);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "情報";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 12);
            this.label1.TabIndex = 29;
            this.label1.Text = "チェックがONの項目が印刷されます";
            // 
            // cbIsPrintDurationInfo
            // 
            this.cbIsPrintDurationInfo.AutoSize = true;
            this.cbIsPrintDurationInfo.Location = new System.Drawing.Point(21, 68);
            this.cbIsPrintDurationInfo.Name = "cbIsPrintDurationInfo";
            this.cbIsPrintDurationInfo.Size = new System.Drawing.Size(106, 16);
            this.cbIsPrintDurationInfo.TabIndex = 28;
            this.cbIsPrintDurationInfo.Text = "累計秒数の印刷";
            this.cbIsPrintDurationInfo.UseVisualStyleBackColor = true;
            // 
            // cbIsPrintCampany
            // 
            this.cbIsPrintCampany.AutoSize = true;
            this.cbIsPrintCampany.Checked = true;
            this.cbIsPrintCampany.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbIsPrintCampany.Location = new System.Drawing.Point(326, 152);
            this.cbIsPrintCampany.Name = "cbIsPrintCampany";
            this.cbIsPrintCampany.Size = new System.Drawing.Size(60, 16);
            this.cbIsPrintCampany.TabIndex = 27;
            this.cbIsPrintCampany.Text = "組織名";
            this.cbIsPrintCampany.UseVisualStyleBackColor = true;
            // 
            // cbIsPrintSubTitle
            // 
            this.cbIsPrintSubTitle.AutoSize = true;
            this.cbIsPrintSubTitle.Checked = true;
            this.cbIsPrintSubTitle.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbIsPrintSubTitle.Location = new System.Drawing.Point(328, 55);
            this.cbIsPrintSubTitle.Name = "cbIsPrintSubTitle";
            this.cbIsPrintSubTitle.Size = new System.Drawing.Size(78, 16);
            this.cbIsPrintSubTitle.TabIndex = 26;
            this.cbIsPrintSubTitle.Text = "サブタイトル";
            this.cbIsPrintSubTitle.UseVisualStyleBackColor = true;
            // 
            // cbIsPrintOPUS
            // 
            this.cbIsPrintOPUS.AutoSize = true;
            this.cbIsPrintOPUS.Checked = true;
            this.cbIsPrintOPUS.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbIsPrintOPUS.Location = new System.Drawing.Point(255, 55);
            this.cbIsPrintOPUS.Name = "cbIsPrintOPUS";
            this.cbIsPrintOPUS.Size = new System.Drawing.Size(48, 16);
            this.cbIsPrintOPUS.TabIndex = 25;
            this.cbIsPrintOPUS.Text = "話数";
            this.cbIsPrintOPUS.UseVisualStyleBackColor = true;
            this.cbIsPrintOPUS.CheckedChanged += new System.EventHandler(this.cbIsPrintOPUS_CheckedChanged);
            // 
            // cbIsPrintTitle
            // 
            this.cbIsPrintTitle.AutoSize = true;
            this.cbIsPrintTitle.Checked = true;
            this.cbIsPrintTitle.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbIsPrintTitle.Location = new System.Drawing.Point(21, 55);
            this.cbIsPrintTitle.Name = "cbIsPrintTitle";
            this.cbIsPrintTitle.Size = new System.Drawing.Size(83, 16);
            this.cbIsPrintTitle.TabIndex = 24;
            this.cbIsPrintTitle.Text = "作品タイトル";
            this.cbIsPrintTitle.UseVisualStyleBackColor = true;
            // 
            // tbFps
            // 
            this.tbFps.Location = new System.Drawing.Point(21, 171);
            this.tbFps.Name = "tbFps";
            this.tbFps.Size = new System.Drawing.Size(85, 19);
            this.tbFps.TabIndex = 23;
            this.tbFps.TextChanged += new System.EventHandler(this.tbTargetMin_TextChanged);
            this.tbFps.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbFps_KeyPress);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(19, 156);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(69, 12);
            this.label14.TabIndex = 22;
            this.label14.Text = "フレームレート";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(268, 178);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(17, 12);
            this.label13.TabIndex = 21;
            this.label13.Text = "秒";
            // 
            // tbTargetSec
            // 
            this.tbTargetSec.Location = new System.Drawing.Point(229, 171);
            this.tbTargetSec.Name = "tbTargetSec";
            this.tbTargetSec.Size = new System.Drawing.Size(37, 19);
            this.tbTargetSec.TabIndex = 20;
            this.tbTargetSec.TextChanged += new System.EventHandler(this.tbTargetMin_TextChanged);
            this.tbTargetSec.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbTargetMin_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(211, 178);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(17, 12);
            this.label12.TabIndex = 19;
            this.label12.Text = "分";
            // 
            // tbTargetMin
            // 
            this.tbTargetMin.Location = new System.Drawing.Point(119, 171);
            this.tbTargetMin.Name = "tbTargetMin";
            this.tbTargetMin.Size = new System.Drawing.Size(89, 19);
            this.tbTargetMin.TabIndex = 18;
            this.tbTargetMin.TextChanged += new System.EventHandler(this.tbTargetMin_TextChanged);
            this.tbTargetMin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbTargetMin_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(117, 156);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 17;
            this.label11.Text = "目標秒数";
            // 
            // cmbVersion
            // 
            this.cmbVersion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVersion.FormattingEnabled = true;
            this.cmbVersion.Location = new System.Drawing.Point(21, 220);
            this.cmbVersion.Name = "cmbVersion";
            this.cmbVersion.Size = new System.Drawing.Size(153, 20);
            this.cmbVersion.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(19, 205);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 12);
            this.label10.TabIndex = 14;
            this.label10.Text = "バージョン";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(228, 106);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 12);
            this.label7.TabIndex = 13;
            this.label7.Text = "コメント";
            // 
            // tbComment
            // 
            this.tbComment.Location = new System.Drawing.Point(229, 121);
            this.tbComment.Name = "tbComment";
            this.tbComment.Size = new System.Drawing.Size(311, 19);
            this.tbComment.TabIndex = 7;
            // 
            // tbCampanyName
            // 
            this.tbCampanyName.Location = new System.Drawing.Point(326, 171);
            this.tbCampanyName.Name = "tbCampanyName";
            this.tbCampanyName.Size = new System.Drawing.Size(154, 19);
            this.tbCampanyName.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(117, 106);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 9;
            this.label5.Text = "修正者";
            // 
            // tbUpdateUser
            // 
            this.tbUpdateUser.Location = new System.Drawing.Point(119, 121);
            this.tbUpdateUser.Name = "tbUpdateUser";
            this.tbUpdateUser.Size = new System.Drawing.Size(89, 19);
            this.tbUpdateUser.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 7;
            this.label4.Text = "作成者";
            // 
            // tbCreateUser
            // 
            this.tbCreateUser.Location = new System.Drawing.Point(21, 121);
            this.tbCreateUser.Name = "tbCreateUser";
            this.tbCreateUser.Size = new System.Drawing.Size(85, 19);
            this.tbCreateUser.TabIndex = 4;
            // 
            // tbSubTitle
            // 
            this.tbSubTitle.Location = new System.Drawing.Point(326, 73);
            this.tbSubTitle.Name = "tbSubTitle";
            this.tbSubTitle.Size = new System.Drawing.Size(214, 19);
            this.tbSubTitle.TabIndex = 3;
            // 
            // tbOPUS
            // 
            this.tbOPUS.Location = new System.Drawing.Point(254, 73);
            this.tbOPUS.Name = "tbOPUS";
            this.tbOPUS.Size = new System.Drawing.Size(66, 19);
            this.tbOPUS.TabIndex = 2;
            this.tbOPUS.TextChanged += new System.EventHandler(this.tbOPUS_TextChanged);
            // 
            // tbTitle
            // 
            this.tbTitle.Location = new System.Drawing.Point(21, 73);
            this.tbTitle.Name = "tbTitle";
            this.tbTitle.Size = new System.Drawing.Size(232, 19);
            this.tbTitle.TabIndex = 1;
            // 
            // cbLock
            // 
            this.cbLock.AutoSize = true;
            this.cbLock.Location = new System.Drawing.Point(33, 384);
            this.cbLock.Name = "cbLock";
            this.cbLock.Size = new System.Drawing.Size(102, 16);
            this.cbLock.TabIndex = 2;
            this.cbLock.Text = "コンテをロックする";
            this.cbLock.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbIsPrintPartCaption);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.cbIsPrintDurationInfo);
            this.groupBox2.Controls.Add(this.tbPageNumberStart);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.tbNumberStart);
            this.groupBox2.Location = new System.Drawing.Point(12, 273);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(556, 105);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "設定";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(311, 33);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(129, 12);
            this.label9.TabIndex = 11;
            this.label9.Text = "印刷時の開始ページ番号";
            // 
            // tbPageNumberStart
            // 
            this.tbPageNumberStart.Location = new System.Drawing.Point(446, 30);
            this.tbPageNumberStart.Name = "tbPageNumberStart";
            this.tbPageNumberStart.Size = new System.Drawing.Size(94, 19);
            this.tbPageNumberStart.TabIndex = 1;
            this.tbPageNumberStart.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbNumberStart_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 33);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(175, 12);
            this.label8.TabIndex = 9;
            this.label8.Text = "自動カット番号割り当てのスタート値";
            // 
            // tbNumberStart
            // 
            this.tbNumberStart.Location = new System.Drawing.Point(200, 30);
            this.tbNumberStart.Name = "tbNumberStart";
            this.tbNumberStart.Size = new System.Drawing.Size(94, 19);
            this.tbNumberStart.TabIndex = 0;
            this.tbNumberStart.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbNumberStart_KeyPress);
            // 
            // btnOK
            // 
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Location = new System.Drawing.Point(369, 384);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 0;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(458, 384);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // cbIsPrintPartCaption
            // 
            this.cbIsPrintPartCaption.AutoSize = true;
            this.cbIsPrintPartCaption.Location = new System.Drawing.Point(160, 68);
            this.cbIsPrintPartCaption.Name = "cbIsPrintPartCaption";
            this.cbIsPrintPartCaption.Size = new System.Drawing.Size(86, 16);
            this.cbIsPrintPartCaption.TabIndex = 29;
            this.cbIsPrintPartCaption.Text = "パートの印刷";
            this.cbIsPrintPartCaption.UseVisualStyleBackColor = true;
            // 
            // ContSettingDlg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(583, 418);
            this.ControlBox = false;
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.cbLock);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ContSettingDlg";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "コンテの情報";
            this.Load += new System.EventHandler(this.ContSettingDlg_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.CheckBox cbLock;
		private System.Windows.Forms.TextBox tbSubTitle;
		private System.Windows.Forms.TextBox tbOPUS;
		private System.Windows.Forms.TextBox tbTitle;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox tbUpdateUser;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox tbCreateUser;
		private System.Windows.Forms.TextBox tbCampanyName;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox tbComment;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox tbNumberStart;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.TextBox tbPageNumberStart;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.ComboBox cmbVersion;
        private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.TextBox tbTargetSec;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.TextBox tbTargetMin;
		private System.Windows.Forms.TextBox tbFps;
		private System.Windows.Forms.CheckBox cbIsPrintCampany;
		private System.Windows.Forms.CheckBox cbIsPrintSubTitle;
		private System.Windows.Forms.CheckBox cbIsPrintOPUS;
		private System.Windows.Forms.CheckBox cbIsPrintTitle;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.CheckBox cbIsPrintDurationInfo;
        private System.Windows.Forms.CheckBox cbIsPrintPartCaption;
	}
}