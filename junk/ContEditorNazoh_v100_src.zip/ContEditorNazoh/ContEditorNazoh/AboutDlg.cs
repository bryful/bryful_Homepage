﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ContEditorNazoh
{
	public partial class AboutDlg : Form
	{
		public AboutDlg()
		{
			InitializeComponent();

			lbVersion.Text = ContEditorNazoh.Properties.Resources.Version;
		}

		private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			//リンク先に移動したことにする
			linkLabel1.LinkVisited = true;
			//ブラウザで開く
			System.Diagnostics.Process.Start(linkLabel1.Text);
		}
	}
}
