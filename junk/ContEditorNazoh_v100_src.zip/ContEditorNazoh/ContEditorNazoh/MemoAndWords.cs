﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class MemoAndWords : UserControl
    {
        private ContDocument _ContDocument;
		private int _CurrentPage;
        private int _Index = -1;
        private int _Target = -1;
        private int _SelectedPageIndex = -1;

		private ZBobb.AlphaBlendTextBox[] _Memos = new ZBobb.AlphaBlendTextBox[def.KomaCount];
		private ZBobb.AlphaBlendTextBox[] _Words = new ZBobb.AlphaBlendTextBox[def.KomaCount];
		private ZBobb.AlphaBlendTextBox[] _MemosU = new ZBobb.AlphaBlendTextBox[def.KomaCount];
		private ZBobb.AlphaBlendTextBox[] _WordsU = new ZBobb.AlphaBlendTextBox[def.KomaCount];


        public event EventHandler MemoChanged;

		private const int MemoW = 115;
		private const int WordW = 85;
		private const int MemoH = def.PreviewKomaHeightP - 20;
		private const int MemoUH = 20;
		public MemoAndWords()
        {
            InitializeComponent();


			BorderStyle bs = BorderStyle.FixedSingle;
			Padding pd = new Padding(0);
			for (int i = 0; i < def.KomaCount; i++)
			{
				_Memos[i] = new ZBobb.AlphaBlendTextBox();
				_Memos[i].Name = "tbMemo" + i.ToString();
				_Memos[i].Multiline = true;
				_Memos[i].Tag = i;
				_Memos[i].Location = new Point(0, i * def.PreviewKomaHeightP);
				_Memos[i].Size = new Size(MemoW, MemoH);
				_Memos[i].Enter += new EventHandler(tb_Enter);
				_Memos[i].TextChanged += new EventHandler(tb_TextChanged);
				_Memos[i].Font = this.Font;
				_Memos[i].BackAlpha = 64;
				_Memos[i].BorderStyle = bs;
				_Memos[i].Margin = pd;
				_Memos[i].MaxLength = 600;
				this.Controls.Add(_Memos[i]);

				_Words[i] = new ZBobb.AlphaBlendTextBox();
				_Words[i].Name = "tbWords" + i.ToString();
				_Words[i].Multiline = true;
				_Words[i].Tag = i;
				_Words[i].Location = new Point(MemoW, i * def.PreviewKomaHeightP);
				_Words[i].Size = new Size(WordW, MemoH);
				_Words[i].Enter += new EventHandler(tb_Enter);
				_Words[i].TextChanged += new EventHandler(tb_TextChanged);
				_Words[i].Font = this.Font;
				_Words[i].BackAlpha = 64;
				_Words[i].BorderStyle = bs;
				_Words[i].Margin = pd;
				_Words[i].MaxLength = 300;
				this.Controls.Add(_Words[i]);

				_MemosU[i] = new ZBobb.AlphaBlendTextBox();
				_MemosU[i].Name = "tbMemoU" + i.ToString();
				//_MemosU[i].Multiline = true;
				_MemosU[i].Tag = i;
				_MemosU[i].Location = new Point(0, i * def.PreviewKomaHeightP + MemoH);
				_MemosU[i].Size = new Size(MemoW, MemoUH);
				_MemosU[i].Enter += new EventHandler(tb_Enter);
				_MemosU[i].TextChanged += new EventHandler(tb_TextChanged);
				_MemosU[i].Font = this.Font;
				_MemosU[i].BackAlpha = 64;
				_MemosU[i].BorderStyle = bs;
				_MemosU[i].MaxLength = 30;
				_MemosU[i].Margin = pd;
				this.Controls.Add(_MemosU[i]);

				_WordsU[i] = new ZBobb.AlphaBlendTextBox();
				_WordsU[i].Name = "tbWordsU" + i.ToString();
				//_WordsU[i].Multiline = true;
				_WordsU[i].Tag = i;
				_WordsU[i].Location = new Point(MemoW, i * def.PreviewKomaHeightP +MemoH);
				_WordsU[i].Size = new Size(WordW, MemoUH);
				_WordsU[i].Enter += new EventHandler(tb_Enter);
				_WordsU[i].TextChanged += new EventHandler(tb_TextChanged);
				_WordsU[i].Font = this.Font;
				_WordsU[i].BackAlpha = 64;
				_WordsU[i].BorderStyle = bs;
				_WordsU[i].MaxLength = 30;
				_WordsU[i].Margin = pd;
				this.Controls.Add(_WordsU[i]);


			}
            this.SetStyle(ControlStyles.SupportsTransparentBackColor, true);
            this.BackColor = Color.Transparent;
            this.Height = def.KomaCount * def.PreviewKomaHeightP;
			this.Width = MemoW + WordW;
			SetPos();
        }
        //----------------------------------------------------------------
        private void SetPos()
        {
            this.SuspendLayout();
			for (int i = 0; i < def.KomaCount; i++)
            {
                _Memos[i].Left = 0;
                _Memos[i].Top = i * def.PreviewKomaHeightP;
                _Memos[i].Width = MemoW+1;
                _Memos[i].Height = MemoH+2;

				_MemosU[i].Left = 0;
				_MemosU[i].Top = i * def.PreviewKomaHeightP + MemoH;
				_MemosU[i].Width = MemoW+1;
                

				_Words[i].Left = MemoW;
                _Words[i].Top = i * def.PreviewKomaHeightP;
                _Words[i].Width = WordW;
                _Words[i].Height = MemoH+2;

				_WordsU[i].Left = MemoW;
				_WordsU[i].Top = i * def.PreviewKomaHeightP +MemoH;
				_WordsU[i].Width = WordW;
			}
            this.ResumeLayout();
        }
        //----------------------------------------------------------------
        private void MemoAndWords_Resize(object sender, EventArgs e)
        {
            if (this.Height != def.KomaCount * def.PreviewKomaHeightP)
            {
                this.Height = def.KomaCount * def.PreviewKomaHeightP;
            }
			if (this.Width != (MemoW + WordW))
			{
				this.Width = (MemoW + WordW);
			}
            SetPos();
        }
        //----------------------------------------------------------------
        private string GetText(TextBox tb)
        {
            if (tb.Text == "") { return ""; }
            int cnt = tb.Lines.Length - 1;
            string s = "";
            for (int i = 0; i <= cnt; i++)
            {
                s += tb.Lines[i];
                if (i != cnt) s += "\\n";
            }
            return s;
        }
        //----------------------------------------------------------------
        private void SetText(TextBox tb, string value)
        {
            if (value == "")
            {
                tb.Text = "";
            }
            else
            {
                string s = value.Replace("\\n", "\n");
                tb.Lines = s.Split('\n');
            }
        }
		//----------------------------------------------------------------
        public ContDocument ContDocument
        {
            get { return _ContDocument; }
            set
            {
                _Index = -1;
                _ContDocument = value;
                if (_ContDocument != null)
                {
					_CurrentPage = _ContDocument.CurrentPage;
					_Index = _CurrentPage * def.KomaCount;
					_ContDocument.komaChanged += new EventHandler(Page_Changed);


                }
            }
        }
		//----------------------------------------------------------------
	
		private void Page_Changed(object sender, EventArgs e)
		{
            if (_CurrentPage != _ContDocument.CurrentPage)
            {

                ToContDocument();
                _CurrentPage = _ContDocument.CurrentPage;
                _Index = _CurrentPage * def.KomaCount;
            }
            FromContDocument();
        }
         //----------------------------------------------------------------
        public void ToContDocument()
        {
            if (_ContDocument != null)
            {
                if (_ContDocument.Locked == true) return;
                for (int i = 0; i < def.KomaCount; i++)
                {
					int idx = _Index + i;
					_ContDocument.SetMemo(idx, GetText(_Memos[i]));
                    _ContDocument.SetWords(idx, GetText(_Words[i]));
					_ContDocument.SetMemoU(idx, GetText(_MemosU[i]));
					_ContDocument.SetWordsU(idx, GetText(_WordsU[i]));
				}
            }
        }
        //----------------------------------------------------------------
        public void FromContDocument()
        {
            if (_ContDocument != null)
            {
                this.SuspendLayout();
                for (int i = 0; i < def.KomaCount; i++)
                {
					int idx = _Index + i;
                    SetText(_Memos[i] ,_ContDocument.GetMemo(idx) );
                    SetText(_Words[i], _ContDocument.GetWords(idx));
					SetText(_MemosU[i], _ContDocument.GetMemoU(idx));
					SetText(_WordsU[i], _ContDocument.GetWordsU(idx));
					_Memos[i].Visible = 
                    _Words[i].Visible =
					_MemosU[i].Visible =
					_WordsU[i].Visible =
					!_ContDocument.GetEmpty(idx);
                }
                this.ResumeLayout();
            }
        }
        //----------------------------------------------------------------
        public void EmptyChk()
        {
            if (_ContDocument != null)
            {
                this.SuspendLayout();
                for (int i = 0; i < def.KomaCount; i++)
                {
                    _Memos[i].Visible =
                    _Words[i].Visible =
					_MemosU[i].Visible =
					_WordsU[i].Visible = 
					!_ContDocument.GetEmpty(_Index + i);
                }
                this.ResumeLayout();
            }
        }
        //----------------------------------------------------------------
        private void tb_Enter(object sender, EventArgs e)
        {
            if (_ContDocument != null)
            {
				int t = (int)((TextBox)sender).Tag;
                int idx = t + _Index;
                _SelectedPageIndex = t; 

                if (_Target != t)
                {
                    if (_Target >= 0)
                    {
                        _ContDocument.SetMemo(_Index + _Target, GetText(_Memos[t]));
                        _ContDocument.SetWords(_Index + _Target, GetText(_Words[t]));
						_Target = t;
					}
                }


                if (_ContDocument.SelectedIndex != idx)
                {
                    _ContDocument.SelectedIndex = idx;
                }

            }
        }
		//----------------------------------------------------------------
		private void SetSelectedPageIndex(int idx)
        {
            if (idx < 0)
            {
                this.Focus();
            }
            else if ( idx< def.KomaCount)
            {
                _Memos[idx].Focus();
            }
        }
        //----------------------------------------------------------------
        private void MemoAndWords_Paint(object sender, PaintEventArgs e)
        {
            EmptyChk();
			
        }
        //----------------------------------------------------------------
        private void tb_TextChanged(object sender, EventArgs e)
        {
            OnMemeChanged(new EventArgs());
        }
        //----------------------------------------------------------------
        protected virtual void OnMemeChanged(EventArgs e)
        {
            if (MemoChanged != null)
            {
                MemoChanged(this, e);
            }
        }
        //----------------------------------------------------------------

    }
}
