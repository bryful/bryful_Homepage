﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class ExtInstDlg : Form
    {
        ExtentionSetup ExtSetng = new ExtentionSetup();
       
        private const string appName = "ContEditor Nazoh!";
        public ExtInstDlg()
        {
            InitializeComponent();
            SetupExts();
        }
        private void SetupExts()
        {
            Extention ex = new Extention();
            ex.ext = def.NazExt;
            ex.fileType = "Nazf";
            ex.description = appName + " Save Data";
            ex.iconIndex = 1;
            ExtSetng.Add(ex);

            ex.ext = def.NazPrefExt;
            ex.fileType = "NazP";
            ex.description = appName + " Pref Data";
            ex.iconIndex = 2;
            ExtSetng.Add(ex);

            ex.ext = def.NazPrefSTExt;
            ex.fileType = "NazS";
            ex.description = appName + " Select Take Dialog Pref Data";
            ex.iconIndex = 2;
            ExtSetng.Add(ex);

            ex.ext = def.NazPrefPrntExt;
            ex.fileType = "NazT";
            ex.description = appName + " Print Preview Dialog Pref Data";
            ex.iconIndex = 2;
            ExtSetng.Add(ex);

			ex.ext = def.NazPrefPartExt;
			ex.fileType = "NazI";
			ex.description = appName + " PartInfo Palette Pref Data";
			ex.iconIndex = 2;
			ExtSetng.Add(ex);
        
            ex.ext = def.NazPrefCPExt;
            ex.fileType = "NazC";
            ex.description = appName + " ContPreview Window Pref Data";
            ex.iconIndex = 2;
            ExtSetng.Add(ex);
        }

        private void btnInst_Click(object sender, EventArgs e)
        {
            ExtSetng.Inst();
        }

        private void btnUnInst_Click(object sender, EventArgs e)
        {
            ExtSetng.Uninst();
        }
    }
}
