﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class ContDocument : Component
    {
        /// ワークフォルダのパス
        /// </summary>
        private string _WorkDir = "";
        /// <summary>
        /// コンテデータのあるフォルダのパス
        /// </summary>
        private string _NazDir = "";
        /// <summary>
        /// 印刷用のイメージファイルのあるフォルダのパス。
        /// </summary>
        private string _ImageDir = "";
        /// <summary>
        /// 画面表示用のサムネイルのあるフォルダのパス
        /// </summary>
        private string _ThumbDir = "";
        /// <summary>
        /// Nazファイルのバックアップフォルダのパス
        /// </summary>
        private string _BackupDir = "";
        
        /// <summary>
        /// 編集ターゲットのNazファイル名
        /// </summary>
        private string _NazFileName = "";

        //*******************************************************************************************
        /*
         * ファイル
         */
        //*******************************************************************************************
        /// <summary>
        /// WorkDirを設定する。無ければ作成する
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public bool SetWorkDir(string path)
        {
            if (Directory.Exists(path) == false)
            {
                try
                {
                    Directory.CreateDirectory(path);
                }
                catch
                {
                    return false;
                }
            }
            _WorkDir = path;
            return true;
        }
        //-------------------------------------------------------------------------------
        /// <summary>
        /// TargetDirを設定する。
        /// 同時に_ImageDir/_ThumbDirも獲得。フォルダが無ければ作成する
        /// </summary>
        /// <param name="path">
        /// 設定するフォルダのパス。無ければエラー
        /// </param>
        /// <returns>
        /// 有効なフォルダが指定されると true
        /// </returns>
        public bool SetNazDir(string path)
        {
            _NazDir = "";
            _ImageDir = "";
            _ThumbDir = "";
            _BackupDir = "";
            if (Directory.Exists(path) == false) return false;

            string p = Path.Combine(path, def.ImageFolderName);
            string t = Path.Combine(path, def.ThumbFolderName); ;
            string b = Path.Combine(path, def.BackupFolderName); ;

            if (File.Exists(p) == false)
            {
                try
                {
                    Directory.CreateDirectory(p);
                }
                catch
                {
                    return false;
                }
            }
            if (File.Exists(t) == false)
            {
                try
                {
                    Directory.CreateDirectory(t);
                }
                catch
                {
                    return false;
                }
            }
            if (File.Exists(b) == false)
            {
                try
                {
                    Directory.CreateDirectory(b);
                }
                catch
                {
                    return false;
                }
            }
            _NazDir = path;
            _ImageDir = p;
            _ThumbDir = t;
            _BackupDir = b;
            return true;
        }
        //-------------------------------------------------------------------------------
        public string NazFileName
        {
            get
            {
                if (_NazFileName == "") _NazFileName = def.NazFileName;
                return _NazFileName;
            }
        }
        //-------------------------------------------------------------------------------
        public void SetNazFileName(string value)
        {
            _NazFileName = Path.GetFileName(value);

        }
        //-------------------------------------------------------------------------------
        /// <summary>
        /// 現在のNazFile名を変更する。バックアップファイルも同時に行う。
        /// </summary>
        /// <param name="newName"></param>
        /// <returns></returns>
        public bool NazFileNameRename(string newName)
        {
            if (_Locked == true) return false;
            if (Directory.Exists(_NazDir) == false) return false;
            //とりあえず
            SaveNaz();
            string nn = newName;
            //拡張子は無理やり付ける
            if (Path.GetExtension(nn) != def.NazExt) nn = Path.ChangeExtension(nn, def.NazExt);
            //フルパス作成
            string p = Path.Combine(_NazDir, nn);
            //ファイルがあったらエラー
            if (File.Exists(p) == true) return false;
            string org = Path.Combine(_NazDir, _NazFileName);

            try
            {
                File.Move(org, p);
            }
            catch
            {
                return false;
            }
            //---ここにBackupの処理を
            string[] files = Directory.GetFiles(_BackupDir, _NazFileName + ".*");
            if (files.Length > 0)
            {
                try
                {
                    string[] newFiles = new string[files.Length];
                    for (int i = 0; i < files.Length; i++)
                    {
                        string oldN = Path.GetFileName(files[i]);
                        string newN = Path.Combine(_BackupDir, nn + Path.GetExtension(oldN));
                        File.Move(files[i], newN);
                    }
                }
                catch
                {
                }
            }
            _NazFileName = nn;
            return true;
        }
        //-------------------------------------------------------------------------------
        public bool NazFileNameCreate(string newName, bool IsNoneClear)
        {
            if (Directory.Exists(_NazDir) == false) return false;
            //とりあえず
            SaveNaz();
            string nn = newName;
            //拡張子は無理やり付ける
            if (Path.GetExtension(nn) != def.NazExt) nn = Path.ChangeExtension(nn, def.NazExt);
            //フルパス作成
            string p = Path.Combine(_NazDir, nn);
            //ファイルがあったらエラー
            if (File.Exists(p) == true) return false;

            _NazFileName = nn;
            if (IsNoneClear == false) this.Clear();
            ContFiles cf = new ContFiles(this);
            return cf.SaveNazDir();

        }
        //-------------------------------------------------------------------------------
        public bool NazFileNameRenameDlg()
        {
            if (_Locked == true) return false;
            if (Directory.Exists(_NazDir) == false) return false;
            NazFileSelectDlg dlg = new NazFileSelectDlg(NazFileSelector.Rename, _NazDir, _NazFileName);

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                return NazFileNameRename(dlg.NazFileName);
            }
            return true;
        }
        //-------------------------------------------------------------------------------
        public bool NazFileNameCreateDlg()
        {
            if (Directory.Exists(_NazDir) == false) return false;
            NazFileSelectDlg dlg = new NazFileSelectDlg(NazFileSelector.Create, _NazDir, _NazFileName);
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                return NazFileNameCreate(dlg.NazFileName, dlg.IsNoneClear);
            }
            return true;
        }
        //-------------------------------------------------------------------------------
        public bool NazFileNameSelectDlg()
        {
            if (Directory.Exists(_NazDir) == false) return false;
            NazFileSelectDlg dlg = new NazFileSelectDlg(NazFileSelector.Select, _NazDir, _NazFileName);
            //とりあえず
            SaveNaz();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                if (_NazFileName != dlg.NazFileName)
                {
                    ContFiles cf = new ContFiles(this);
                    if (cf.LoadFromNazFile(dlg.NazFile) == true)
                    {
                        _SelectedIndex = -1;
                        SetNazFileName(dlg.NazFileName);
                        OnSelectedIndexChanged(new EventArgs());
                    }
                }

            }
            return true;
        }
        //-------------------------------------------------------------------------------
        /// <summary>
        /// コンテデータを保存する。実行時に必ずファイルが存在してるはずなので、上書き保存のみ
        /// </summary>
        /// <returns></returns>
        //-------------------------------------------------------------------------------
        public bool SaveNaz()
        {
            if (_Locked == true) return false;
            ContFiles cf = new ContFiles(this);

            CreateBackup();
            if (cf.SaveNazDir() == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        //-------------------------------------------------------------------------------
        public bool SaveNaz(bool IsLocked)
        {
            CreateBackup();
            _Locked = IsLocked;
            ContFiles cf = new ContFiles(this);
            return cf.SaveNazDir();
        }
        //-------------------------------------------------------------------------------
        private string Zero3(int v)
        {
            if (v <= 0)
            {
                return "000";
            }
            else if (v < 10)
            {
                return "00" + v.ToString();
            }
            else if (v < 100)
            {
                return "0" + v.ToString();
            }
            else
            {
                return v.ToString();
            }
        }
        //-------------------------------------------------------------------------------
        private void CreateBackup()
        {
            if ((_changeFlag == false) || (_Locked == true)) return;
            _changeFlag = false;
            int v = BackupInfoLoad();
            string oldName = Path.Combine(_NazDir, _NazFileName);
            string newName = Path.Combine(_BackupDir, _NazFileName + "." + Zero3(v));
            if (File.Exists(newName) == true)
            {
                File.Delete(newName);
            }
            File.Move(oldName, newName);

            v++;
            BackupInfoSave(v);
        }
        //-------------------------------------------------------------------------------
        private void BackupInfoSave(int v)
        {
            if ((_BackupDir == string.Empty) || (_NazFileName == string.Empty)) return;
            //ファイルを作成してバックアップのナンバーを保存する。
            string p = Path.Combine(_BackupDir, _NazFileName + def.BackupInfoExt);
            StreamWriter sw = new StreamWriter(p, false, Encoding.GetEncoding("utf-8"));
            try
            {
                sw.Write(v.ToString());
            }
            catch
            {
                return;
            }
            finally
            {
                sw.Close();
            }
        }
        //-------------------------------------------------------------------------------
        private int BackupInfoLoad()
        {
            if ((_BackupDir == string.Empty) || (_NazFileName == string.Empty)) return -1;
            //ファイルを作成してバックアップのナンバーを保存する。
            string p = Path.Combine(_BackupDir, _NazFileName + def.BackupInfoExt);
            int ret = 0;
            if (File.Exists(p) == false) return ret;
            try
            {
                string[] lines = File.ReadAllLines(p, Encoding.GetEncoding("utf-8"));
                if (lines.Length > 0)
                {
                    int v = 0;
                    if (int.TryParse(lines[0], out v))
                    {
                        ret = v;
                    }
                }
            }
            catch
            {
                return ret;
            }
            return ret;
        }
        //-------------------------------------------------------------------------------
        /// <summary>
        /// NazBrowserから呼び出す事
        /// </summary>
        public void SelectWorkDir()
        {
            FolderBrowserDialog fb = new FolderBrowserDialog();
            fb.RootFolder = Environment.SpecialFolder.Desktop;
            fb.ShowNewFolderButton = true;
            if (Directory.Exists(_WorkDir) == false)
            {
                SetWorkDir(DefaultWorkDir);
            }
            fb.SelectedPath = _WorkDir;
            if (fb.ShowDialog() == DialogResult.OK)
            {
                _WorkDir = fb.SelectedPath;
                Clear();
            }

        }
        //-------------------------------------------------------------------------------
        public bool OpenNazBrowser()
        {
            bool ret = false;
            NazDirBrowser nz = new NazDirBrowser(this);
            if (nz.ShowDialog() == DialogResult.OK)
            {
                if (nz.NewFlag == true)
                {
                    //新規の場合は現在のものを消す
                    Clear();
                    if (CreateNazDir(nz.NazDir) == true)
                    {
                        ret = true;
                    }
                    else
                    {
                        MessageBox.Show("error! Create Naz");
                    }
                }
                else
                {
                    if (OpenNazDir(nz.NazDir) == true)
                    {
                        ret = true;
                    }
                    else
                    {
                        MessageBox.Show("error! Open Naz");
                    }
                }
                OnkomaChanged(new EventArgs());
            }
            return ret;
        }
        //-------------------------------------------------------------------------------
        public bool CreateNazDir(string path)
        {
            ContFiles cf = new ContFiles(this);
            if (cf.CreateNazDir(path))
            {
                _changeFlag = false;
                return true;
            }
            else
            {
                return false;
            }
        }
        //-------------------------------------------------------------------------------

        public bool OpenNazFile(string path)
        {
            ContFiles cf = new ContFiles(this);

            if (cf.OpenNazFile(path) == true)
            {
                _changeFlag = false;
                return true;
            }
            else
            {
                return false;
            }
        }
        //-------------------------------------------------------------------------------
        public bool OpenNazDir(string path)
        {
            ContFiles cf = new ContFiles(this);
            if (cf.OpenNazDir(path))
            {
                _changeFlag = false;
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
