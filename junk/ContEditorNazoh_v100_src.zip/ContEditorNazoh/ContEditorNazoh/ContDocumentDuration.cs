﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class ContDocument : Component
    {
        //------------------------------------------------
        public string DurationToMinSec(float f)
        {
            int fps = (int)Math.Round(_fps);
            int mm = (int)Math.Round(f * _fps);
            int kk = mm % fps;
            mm /= fps;
            int ss = mm % 60;
            mm /= 60;

            string s = "";
            if (mm > 0) s += mm.ToString() + "分 ";
            if (ss <= 0) s += "00";
            else if (ss < 10) s += "0" + ss.ToString();
            else s += ss.ToString();
            s += "秒 ";
            if (kk <= 0) s += "00";
            else if (kk < 10) s += "0" + kk.ToString();
            else s += kk.ToString();
            s += "コマ";
            return s;
        }
  		
        //-------------------------------------------------------------------------------
        public string DurationStr()
        {
            return DurationToMinSec(_Duration);
        }
        //-------------------------------------------------------------------------------
        public string DurationStr(int pg)
        {
            if ((pg < 0) || (pg >= (_Items.Count / def.KomaCount))) return "";
            int idx = (pg + 1) * def.KomaCount - 1;
            return DurationToMinSec(_Items[idx].DurationTotal);
        }
        //------------------------------------------------------
        /// <summary>
        /// コマの秒数を表示。
        /// </summary>
        /// <param name="idx"></param>
        /// <returns></returns>
        public string DispCutSec(int idx)
        {
            string ret = string.Empty;
            if ((idx < 0) || (idx >= _Items.Count)) return ret;
            if ((_Items[idx].Empty == true) || (_Items[idx].IsNoneNumber == true)) return ret;
            if (_Items[idx].IsContinuedNext == false)
            {
                //if (_Items[idx].Duration > 0)
                {
                    ret = DurationToSecFrame(_Items[idx].DurationCutAdd);
                }
            }
            return ret;
        }
        //------------------------------------------------------
        /// <summary>
        /// コマの秒数を表示。
        /// </summary>
        /// <param name="idx"></param>
        /// <returns></returns>
        public string DispKomaSec(int idx)
        {
            string ret = string.Empty;
            if ((idx < 0) || (idx >= _Items.Count)) return ret;
            if ((_Items[idx].Empty == true) || (_Items[idx].IsNoneNumber == true)) return ret;

            if (_Items[idx].Duration > 0)
            {
                ret = "(" + DurationToSecFrame(_Items[idx].Duration) + ")";
            }

            return ret;
        }
        //----------------------------------------------
        /// <summary>
        /// DUrationを"秒+コマ"形式へ
        /// </summary>
        /// <param name="d"></param>
        /// <returns></returns>
        public string DurationToSecFrame(float d)
        {
            int frm = (int)Math.Round(d * _fps);
            int fr = (int)Math.Round(_fps);
            string ret = "";

            ret = (frm / fr).ToString() + "+";
            int v = frm % fr;
            if (v <= 0)
            {
                ret += "00";
            }
            else if (v < 10)
            {
                ret += "0" + v.ToString();
            }
            else
            {
                ret += v.ToString();
            }


            return ret;
        }

    }
}
