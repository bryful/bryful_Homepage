﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ContEditorNazoh
{
	public partial class ContPreviewForm : Form
	{
        private MainForm mf;
        private ContDocument _ContDocument;
        private ContDraw _ContDraw;
		private bool DrawNow = false;
		private Bitmap OffScr;

        //------------------------------------------
        public ContPreviewForm(MainForm m)
		{
			InitializeComponent();
            mf = m;
            _ContDocument = m.ContDocument;
            _ContDraw = new ContDraw(_ContDocument);
            _ContDraw.PageChangeChanged += new EventHandler(contDraw_PageChanged);

            PageScrol.Top = 0;
            PageScrol.Height = _ContDraw.PaperHeightP;
            PageScrol.Left = _ContDraw.PaperWidthP;
            this.ClientSize = new Size(_ContDraw.PaperWidthP + toolStrip1.Width + PageScrol.Width, _ContDraw.PaperHeightP);
            PageMove(0);
            PrefLoad();
			OffScr = new Bitmap(_ContDraw.PaperWidthP, _ContDraw.PaperHeightP, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
		}
		//----------------------------------------------------------------
		public int Currentpage
		{
			get { return _ContDraw.CurrentPage; }
			set 
            {
                if (_ContDraw.CurrentPage != value)
                {
                    _ContDraw.CurrentPage = value;
                }
                if (_ContDraw.PageCount != PageScrol.Maximum)
                {
                    PageScrol.Maximum = _ContDraw.PageCount;
                }
            }
		}
        //----------------------------------------------------------------
        private void contDraw_PageChanged(object sender, EventArgs e)
        {
            if (PageScrol.Value != _ContDraw.CurrentPage)
            {
                PageScrol.Value = _ContDraw.CurrentPage;
            }

            this.Invalidate();
        }
        //----------------------------------------------------------------
        private void ContPreviewForm_Paint(object sender, PaintEventArgs e)
        {
			if (_ContDraw == null) return;
			if (DrawNow == true) return;
			DrawNow = true;
			if (OffScr != null)
			{
				Graphics g = Graphics.FromImage(OffScr);
				SolidBrush sb = new SolidBrush(Color.White);
				try
				{
					g.FillRectangle(sb, new Rectangle(0, 0, OffScr.Width, OffScr.Height));
              
					_ContDraw.DrawPreviewPage(g);
					e.Graphics.DrawImage(OffScr, 0, 0);
				}
				finally
				{
					sb.Dispose();
				}
			}
			DrawNow = false;
        }
        //------------------------------------------
        private void btnReDraw_Click(object sender, EventArgs e)
        {
            if ( (_ContDraw != null)&&(mf != null))
            {
                mf.MemoToContDocument();
                PageScrol.Value = _ContDraw.CurrentPage;
                this.Invalidate();
            }
            

        }
        //--------------------------------------------------------------------------------
        private void ContPreviewForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            mf.cpf = null;
            PrefSave();
        }
        //--------------------------------------------------------------------------------
        private void btnPrevPage_Click(object sender, EventArgs e)
        {
            PageMove(-1);

        }
        //--------------------------------------------------------------
        private void btnNextPage_Click(object sender, EventArgs e)
        {
            PageMove(+1);
        }
        //--------------------------------------------------------------
        private void PageMove(int ad)
        {
            if (ad != 0)
            {
                _ContDraw.CurrentPage = _ContDraw.CurrentPage + ad;
            }
            int cnt = _ContDraw.PageCount;

            if (cnt <= 1)
            {
                PageScrol.Enabled = false;
                if (PageScrol.Maximum != 0)
                {
                    PageScrol.Maximum = 0;
                }
                if (PageScrol.Value != 0)
                {
                    PageScrol.Value = 0;
                }
            }
            else
            {
                PageScrol.Enabled = true;
                if (PageScrol.Maximum != cnt - 1)
                {
                    PageScrol.Maximum = cnt - 1;
                }
                if (PageScrol.Value != _ContDraw.CurrentPage)
                {
                    PageScrol.Value = _ContDraw.CurrentPage;
                }
            }
            btnPrevPage.Enabled = false;
            btnNextPage.Enabled = false;
            btnTopPage.Enabled = false;
            btnLastPage.Enabled = false;
            if (_ContDraw.CurrentPage > 0)
            {
                btnTopPage.Enabled = true;
                btnPrevPage.Enabled = true;
            }
            if (_ContDraw.CurrentPage < cnt - 1)
            {
                btnLastPage.Enabled = true;
                btnNextPage.Enabled = true;
            }
        }

        private void btnTopPage_Click(object sender, EventArgs e)
        {
            _ContDraw.CurrentPage = 0;
            PageScrol.Value = _ContDraw.CurrentPage;
            PageMove(0);
        }

        private void btnLastPage_Click(object sender, EventArgs e)
        {
            _ContDraw.CurrentPage = _ContDraw.PageCount + 1;
            PageScrol.Value = _ContDraw.CurrentPage;
            PageMove(0);
        }

		private void btnClose_Click(object sender, EventArgs e)
		{
			mf.cpf = null;
			this.Close();
		}

		private void btnHome_Click(object sender, EventArgs e)
		{
			mf.Focus();
		}

        //--------------------------------------------------------------
        private void ContPreviewForm_Activated(object sender, EventArgs e)
        {
            this.Invalidate();
        }

		private void btnCurrentSet_Click(object sender, EventArgs e)
		{
			_ContDraw.CurrentPage = _ContDocument.CurrentPage;
			PageMove(0);
		}

        private void vScrollBar1_ValueChanged(object sender, EventArgs e)
        {
            if (_ContDraw.CurrentPage != PageScrol.Value)
            {
                _ContDraw.CurrentPage = PageScrol.Value;
            }
            PageMove(0);
        }
        //--------------------------------------------------------------
        //---------------------------------------------------
        private void PrefSave()
        {
            string p = Path.ChangeExtension(Application.ExecutablePath, def.NazPrefCPExt);
            SaveFiles sv = new SaveFiles(def.PrefHeader);
            sv.SetInt("Left", this.Left);
            sv.SetInt("Top", this.Top);
            sv.SetInt("Width", this.Width);
            sv.SetInt("Height", this.Height);
            sv.SaveToFile(p);
        }
        //---------------------------------------------------------------------------
        public void PrefLoad()
        {
            string p = Path.ChangeExtension(Application.ExecutablePath, def.NazPrefCPExt);
            SaveFiles sv = new SaveFiles(def.PrefHeader);
            sv.LoadFromFile(p);
            int l = sv.GetInt("Left", -1);
            int t = sv.GetInt("Top", -1);
            int w = sv.GetInt("Width", -1);
            int h = sv.GetInt("Height", -1);
            if ((l == -1) || (t == -1) || (w == -1) || (h == -1))
            {
                this.StartPosition = FormStartPosition.CenterScreen;
            }
            else
            {
                this.StartPosition = FormStartPosition.Manual;
                this.Left = l;
                this.Top = t;
                this.Width = w;
                this.Height = h;
            }
        }


    }
}
