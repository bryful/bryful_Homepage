﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ContEditorNazoh
{
    public class def
    {
		/// <summary>
		/// 印刷解像度 300dpi
		/// </summary>
        public const float dpi = 300;
		/// <summary>
		/// ディスプレイ表示解像度 96dpi
		/// </summary>
		public const float DisplayDpi = 96;

		/// <summary>
		/// フレームレート 24fps
		/// </summary>
        public const float fps = 24;
		/// <summary>
		/// 1ページに表示されるコマ数
		/// </summary>
        public const int KomaCount = 5;

		/// <summary>
		/// ディスプレイ表示時のスケール率
		/// </summary>
        public const float PreviewScale = 0.78125f;  // 256/ (1024 *96/300);

		/// <summary>
		/// コマの横幅(mm)
		/// </summary>
		public const float KomaWidth = 86.699f;
		/// <summary>
		/// コマの縦幅(mm)
		/// </summary>
		public const float KomaHeight = 48.768f;
		/// <summary>
		/// コマの横幅(pixel)
		/// </summary>
		public const int KomaWidthP = 1024;
		/// <summary>
		/// コマの縦幅(pixel)
		/// </summary>
		public const int KomaHeightP = 576;


		public const float TitleHeight = 15.0f; 
        public const float CampanyHeight = 10.0f;
		public const float NumberWidth = 11.0f;
		public const float MemoWidth = 42.0f;
		public const float WordsWidth = 33.0f;
		public const float SecWidth = 15.0f;
		public const float CaptionHeigh = 6.0f;
		public const float FooterHeigh = 7.0f;



        public const float PageNumberLine = 1f;
        public const float PageNumberLeft = 5.0f;
        public const float PageNumberWidth = 30.0f;


        /// <summary>
        /// 上下のマージン
        /// </summary>
        public const float MarginH = 0.75f;
        /// <summary>
        /// メモの横マージン
        /// </summary>
        public const float MarginMemo = 1.5f;
        
        /// <summary>
        /// カットナンバーの横マージン
        /// </summary>
        public const float MarginNumber = 0.4f;
        /// <summary>
        /// 秒数の横マージン
        /// </summary>
        public const float MarginSec = 0.20f;

        //------------------------
        public const int PreviewNumberWidthP = 50;
        public const int PreviewSecWidthP = 60;
        public const int PreviewKomaWidthP = 256;
        public const int PreviewKomaHeightP = 144;


		/// <summary>
		/// 印刷範囲の横幅(mm)
		/// </summary>
		public const float PrintWidth = def.NumberWidth + def.KomaWidth + def.MemoWidth + def.WordsWidth + def.SecWidth;
		/// <summary>
		/// 印刷範囲の縦幅(mm)
		/// </summary>
		public const float PrintHeight = def.TitleHeight +def.CampanyHeight +def.CaptionHeigh + (def.KomaHeight * def.KomaCount)+def.FooterHeigh;

		/// <summary>
		/// 印刷用紙の横幅(mm)
		/// </summary>
        public const float PaperWidth = 211f; //186.699
		/// <summary>
		/// 印刷用紙の縦幅(mm)
		/// </summary>
		public const float PaperHeight = 296f;//249.495

        public const float PenSizeS = 0.25f;
        public const float PenSizeM = 0.6f;
        public const float PenSizeL = 1.2f;

		public const float FontSizeText = 12f;
        public const float FontSizeCaption = 12f;
        public const float FontSizeNumber = 14f;
        public const float FontSizeSec = 12f;
        public const float FontSizeCampany = 18f;
		public const float FontSizeTitle = 20f;

        public const string NumberDef = "000";
        public const string NumberNone = "none";
        public const string NumberEmpty = "empty";
        public const string NumberContinued = "";

        public const string ImageFolderName = "image";
        public const string TrushFolderName = "imageTrush";
        public const string ThumbFolderName = "thumb";
        public const string BackupFolderName = "backup";
        public const string NazHeader = "ContEditorNazoh SaveData";
		public const string PrefHeader = "ContEditorNazoh PrefData";
        public const string PrintHeader = "ContEditorNazoh PrintPref";
        public const string PicExt = ".png";

        public const string NazExt = ".Naz";
        public const string NazPrefExt = ".NazPref";
        /// <summary>
        /// NazBrowser Pref Ext
        /// </summary>
        public const string NazPrefBrwExt = ".NazBrw";
            /// <summary>
            /// Naz File Selector  pref Ext
            /// </summary>
        public const string NazPrefSTExt = ".NazST";
        /// <summary>
        /// Print Preview Pref Ext
        /// </summary>
        public const string NazPrefPrntExt = ".NazPrnt";
        /// <summary>
        /// PartInfo Pref Ext
        /// </summary>
		public const string NazPrefPartExt = ".NazPart";
        /// <summary>
        /// Cont Preview Pref Ext
        /// </summary>
        public const string NazPrefCPExt = ".NazCP";

        public const string BackupInfoExt = ".___";
		/// <summary>
		/// ワークフォルダの名前
		/// </summary>
		public const string WorkDirName = "My ContNazoh";
        
		/// <summary>
		/// コンテデータのファイル名。固定
		/// </summary>
		public const string NazFileName = "default" + NazExt;
        /// <summary>
        /// パートの最大値
        /// </summary>
        public const int PartMaxCount = 26+4;//A-Z,OP,ED,AVAN,予告

    }
    public enum ContVersion
    {
        OK = 0,
        First,
        Second,
        Third,
        Fourth,
        Fifth,
        Sixth,
        Seventh,
        Eighth,
        Ninth,
        Tenth,
        Count
    }
    public enum ImportResize
    {
        none = 0,
        sz1024x576,
        sz1280x720,
        sz1440x810,
        sz1920x1080,
        Count
    }
    public enum ImportErr
    {
        /// <summary>
        /// エラーなし
        /// </summary>
        NoErr = 0,
        /// <summary>
        /// ファイルが存在しない
        /// </summary>
        NoneFile,
        /// <summary>
        /// 同名ファイルが既にインポートされている
        /// </summary>
        SameFile,
        /// <summary>
        /// 存在しないインデックス
        /// </summary>
        IndexErr,
        /// <summary>
        /// 読み込みエラー
        /// </summary>
        LoadErr,
        /// <summary>
        /// 解像度エラー
        /// </summary>
        DPIErr,
        /// <summary>
        /// サムネイル作成エラー
        /// </summary>
        ThumbErr,
        /// <summary>
        /// Emptyなコマにインポート
        /// </summary>
        EmptyKoma,
        Count
    }

}
