﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Imaging;

namespace ContEditorNazoh
{
    public class KomaPict
    {
        public string name = "";
        public float X = 0f;
        public float Y = 0f;
        public Bitmap bmp = null;
        public KomaPict()
        {
        }
        public void Clear()
        {
            name = "";
            X = 0f;
            Y = 0f;
            if (bmp != null)
            {
                bmp.Dispose();
            }
            bmp = null;
        }
        public void Assign(KomaPict kp)
        {
            name = kp.name;
            X = kp.X;
            Y = kp.Y;
            bmp = kp.bmp;
        }
        public bool IsBitmap
        {
            get { return (bmp != null); }
        }
    }
}
