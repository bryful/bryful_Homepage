﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class DurationEdit : UserControl
    {
        private bool _refFlag = false;
        public float fps = def.fps;
        //************************************************************
        public DurationEdit()
        {
            InitializeComponent();
        }
        //************************************************************
        public bool IsInputFrame
        {
            get
            {
                return rbIsFrame.Checked;
            }
            set
            {
                if (rbIsFrame.Checked != value)
                {
                    _refFlag = true;
                    rbIsFrame.Checked = value;
                    rbIsSec.Checked = !value;
                    tbFrame.Enabled = value;
                    tbSec.Enabled = !value;
                    tbKoma.Enabled = !value;
                    _refFlag = false;
                }

            }
        }
        //************************************************************
        public float Duration
        {
            get
            {
                if (IsInputFrame == true)
                {
                    int f = 0;
                    if (int.TryParse(tbFrame.Text, out f) == true)
                    {
                        return (float)f / fps;
                    }
                    else
                    {
                        return 0;
                    }
                }
                else
                {
                    int frm = 0;
                    int v = 0;
                    if (int.TryParse(tbSec.Text, out v) == true)
                    {
                        frm = v * (int)Math.Round(fps);
                    }
                    else
                    {
                        return 0;
                    }
                    if (int.TryParse(tbKoma.Text, out v) == true)
                    {
                        frm += v;
                        return (float)frm / fps;
                    }
                    else
                    {
                        return 0;
                    }

                }
            }
            set
            {
                int frm = (int)Math.Round(value * fps);
                tbFrame.Text = frm.ToString();
                int fr = (int)Math.Round(fps);
                tbSec.Text = (frm / fr).ToString();
                tbKoma.Text = (frm % fr).ToString();
            }
        }

        private void tb_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || e.KeyChar > '9') && (e.KeyChar != '\b'))
            {
                e.Handled = true;
            }
        }

        private void rbIsFrame_CheckedChanged(object sender, EventArgs e)
        {
            if (_refFlag == false)
            {
                IsInputFrame = true;
            }
        }

        private void rbIsSec_CheckedChanged(object sender, EventArgs e)
        {
            if (_refFlag == false)
            {
                IsInputFrame = false;
            }
        }
        //************************************************************

    }
}
