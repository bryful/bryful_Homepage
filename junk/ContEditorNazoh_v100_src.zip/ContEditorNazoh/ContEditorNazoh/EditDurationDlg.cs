﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class EditDurationDlg : Form
    {
        public EditDurationDlg(float fps)
        {
            InitializeComponent();
            durationEdit1.fps = fps;
        }

        public float Duration
        {
            get { return durationEdit1.Duration; }
            set { durationEdit1.Duration = value; }
        }
        public bool IsInputFrame
        {
            get { return durationEdit1.IsInputFrame; }
            set { durationEdit1.IsInputFrame = value; }
        }
    }
}
