﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class ImportSettingDlg : Form
    {
        public ImportSettingDlg()
        {
            InitializeComponent();
        }

        public ImportResize ImportResize
        {
            get
            {
                int v = cmbImport.SelectedIndex;
                if (v < 0) v = 0;
                return (ImportResize)v;
            }
            set
            {
                int v = (int)value;
                if (v < 0) v = 0;
                else if (v >= cmbImport.Items.Count) v = cmbImport.Items.Count - 1;
                cmbImport.SelectedIndex = v;
            }
        }
    }
}
