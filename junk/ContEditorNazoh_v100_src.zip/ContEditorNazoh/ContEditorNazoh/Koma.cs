﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace ContEditorNazoh
{
    //**********************************************************************
    [Serializable]
    public class KomaInfo
    {
        //************************
        //セーブデータに保存される項目
        /// <summary>
        /// このコマが無効かどうか
        /// </summary>
        private bool _Empty = false;
        /// <summary>
        /// このコマの次で改ページ
        /// </summary>
        public bool IsPageBreak = false;
        /// <summary>
        /// パートの終わり。
        /// </summary>
        public bool IsPartEnd = false;
        private int _PartNumber = 0;
        /// <summary>
        /// カット番号を割り振らないコマ。
        /// </summary>
        private bool _IsNoneNumber = true;
        /// <summary>
        /// このコマが前のコマと同じカットであるかどうかのフラグ
        /// </summary>
        private bool _IsContinued = false;
        /// <summary>
        /// 表示されるカットナンバー。これがEmptyなら、Numberの数値が表示される
        /// </summary>
        private string _NumberStr = "";//表示される文字。

        /// <summary>
        /// 時間
        /// </summary>
        public float Duration = 0;
        public float DurationCutAdd = 0;    //カットの秒数の計算用
        public float DurationTotal = 0;    //全体の秒数の計算用



        private KomaPict _Pic = new KomaPict();
        private KomaPict _PicSub = new KomaPict();
        /// <summary>
        /// セリフテキスト
        /// </summary>
        public string Words = "";
		public string WordsU = "";

        /// <summary>
        /// 内容テキスト
        /// </summary>
        public string Memo = "";
		public string MemoU = "";
		//************************
        //実行時に使われる項目
        /// <summary>
        /// 自動割当されるカットナンバー
        /// </summary>
        private int _Number = 0;

        /// <summary>
        /// カット継続の矢印描画に使うフラグ
        /// </summary>
        public bool IsContinuedNext = false;


        public int Tag = 0;
        //----------------------------------------------
        public KomaInfo()
        {
        }
        //----------------------------------------------
        /// <summary>
        /// コマの内容をテキスト化
        /// </summary>
        /// <returns>string</returns>
        public string ToText()
        {
            string data ="*KomaInfo\n";
            data += "\t" + "Empty\t" + _Empty.ToString()+"\n";
            data += "\t" + "Number\t" + _NumberStr + "\n";
            data += "\t" + "IsNoneNumber\t" + _IsNoneNumber.ToString() + "\n";
            data += "\t" + "IsContinued\t" + IsContinued.ToString() + "\n";
            data += "\t" + "IsPageBreak\t" + IsPageBreak.ToString() + "\n";
            data += "\t" + "IsPartEnd\t" + IsPartEnd.ToString() + "\n";
            data += "\t" + "Duration\t" + Duration.ToString() + "\n";
            data += "\t" + "PictureName\t" + _Pic.name + "\n";
            data += "\t" + "PicOffsetX\t" + _Pic.X.ToString() + "\n";
            data += "\t" + "PicOffsetY\t" + _Pic.Y.ToString() + "\n";
            data += "\t" + "PictureSubName\t" + _PicSub.name + "\n";
            data += "\t" + "PicOffsetSubX\t" + _PicSub.X.ToString() + "\n";
            data += "\t" + "PicOffsetSubY\t" + _PicSub.Y.ToString() + "\n";
            data += "\t" + "Memo\t" + Memo + "\n";
            data += "\t" + "Words\t" + Words + "\n";
			data += "\t" + "MemoU\t" + MemoU + "\n";
			data += "\t" + "WordsU\t" + WordsU + "\n";
			data += "*KomaInfoEnd\n";

            return data;
        }
        //----------------------------------------------
        /// <summary>
        /// テキストからコマの内容を得る
        /// </summary>
        /// <param name="data">string</param>
        public void FromText(string data)
        {
            Clear();
            if (data == "") return;
            string [] lines = data.Split('\n');
            if (lines.Length <= 1) return;
            for (int i = 0; i < lines.Length; i++)
            {
                //小文字にしておく
                string line = lines[i].Trim().ToLower(); 
                if ( line !=null)
                {
                    bool b = false;
                    float f = 0f;
                    string[] prm = line.Split('\t');
                    if (prm.Length >= 2)
                    {
                        switch (prm[0])
                        {
                            case "empty":
                                b = false;
                                if ( bool.TryParse(prm[1],out b)==true){
                                    _Empty = b;
                                }
                                break;
                            case "number":
                                _NumberStr = prm[1].Trim();
                                break;
                            case "isnonenumber":
                                b = false;
                                if (bool.TryParse(prm[1], out b) == true)
                                {
                                    _IsNoneNumber = b;
                                }
                                break;
                            case "iscontinued":
                                b = false;
                                if (bool.TryParse(prm[1], out b) == true)
                                {
                                    IsContinued = b;
                                }
                                break;
							case "ispagebreak":
                                b = false;
                                if (bool.TryParse(prm[1], out b) == true)
                                {
                                    IsPageBreak = b;
                                }
                                break;
                            case "ispartend":
                                b = false;
                                if (bool.TryParse(prm[1], out b) == true)
                                {
                                    IsPartEnd = b;
                                }
                                break;
                            case "duration":
                                f = 0;
                                if (float.TryParse(prm[1], out f) == true)
                                {
                                    Duration = f;
                                }
                                break;
                            case "picturename":
                                _Pic.name = prm[1].Trim();
                                break;
                            case "picturesubname":
                                _PicSub.name = prm[1].Trim();
                                break;
                            case "picoffsetx":
                                f = 0;
                                if (float.TryParse(prm[1], out f) == true)
                                {
                                    _Pic.X = f;
                                }
                                break;
                            case "picoffsetsubx":
                                f = 0;
                                if (float.TryParse(prm[1], out f) == true)
                                {
                                    _PicSub.X = f;
                                }
                                break;
                            case "picoffsety":
                                f = 0;
                                if (float.TryParse(prm[1], out f) == true)
                                {
                                    _Pic.Y = f;
                                }
                                break;
                            case "picoffsetsuby":
                                f = 0;
                                if (float.TryParse(prm[1], out f) == true)
                                {
                                    _PicSub.Y = f;
                                }
                                break;
                            case "memo":
                                Memo = prm[1].Trim();
                                break;
                            case "words":
                                Words = prm[1].Trim();
                                break;
							case "memou":
								MemoU = prm[1].Trim();
								break;
							case "wordsu":
								WordsU = prm[1].Trim();
								break;
 
                        }
                    }
                }
            }

        }
        //----------------------------------------------
        /// <summary>
        /// 内容を初期化
        /// </summary>
        public void Clear()
        {
            //PageNumber = -1;
			_Empty = false;
            IsPageBreak = false;
            IsPartEnd = false;
            _IsNoneNumber = true;

            _IsContinued = false;
            IsContinuedNext = false;

			_NumberStr = "";
            Duration = 0;
            DurationCutAdd = 0;
            _Pic.Clear();
            _PicSub.Clear();
            Words = "";
            Memo = "";
			WordsU = "";
			MemoU = "";
		}
        //----------------------------------------------
        public void Assign(KomaInfo ic)
        {
            _Empty = ic._Empty;
            IsPageBreak = ic.IsPageBreak;
            IsPartEnd = ic.IsPartEnd;
            _IsNoneNumber = ic._IsNoneNumber;

            _IsContinued = ic._IsContinued;
            NumberStr = ic.NumberStr;
            Duration = ic.Duration;
            _Pic.Assign(ic._Pic);
            _PicSub.Assign(ic._PicSub);
            Words = ic.Words;
            Memo = ic.Memo;
			WordsU = ic.WordsU;
			MemoU = ic.MemoU;
		}
        //----------------------------------------------
        public void swap(KomaInfo ic)
        {
            KomaInfo tmp = new KomaInfo();
            tmp.Assign(this);
            this.Assign(ic);
            ic.Assign(tmp);
        }
        //*******************************************************************
        /*
         * プロパティ
         */ 
        //*******************************************************************
        public int DispOffsetX
        {
            get
            {
                return (int)Math.Round(_Pic.X * def.PreviewScale * def.DisplayDpi / 25.4f);
            }
        }
        public int DispOffsetY
        {
            get
            {
                return (int)Math.Round(_Pic.Y * def.PreviewScale * def.DisplayDpi / 25.4f);
            }
        }
        //----------------------------------------------
        public bool Empty
        {
            get { return _Empty; }
            set
            {
                if (value == true)
                {
                    Clear();
                    _Empty = true;
                }
                else
                {
                    _IsNoneNumber = true;
                    _Empty = false;
                }
            }
        }
        //----------------------------------------------
        public bool IsContinued
        {
            get {
                if (_Empty == true) 
                {
                    return false;
                }
                else
                {
                    return _IsContinued;
                }
            }
            set {
                if (_Empty == true)
                {
                    _IsContinued = false;
                }
                else
                {
                    _IsContinued = value;
                    if (_IsContinued == true) _IsNoneNumber = false;
                }
            }
        }
        //----------------------------------------------
        public bool IsNoneNumber
        {
            get
            {
                if (_Empty == true)
                {
                    return false;
                }
                else
                {
                    return _IsNoneNumber;
                }
            }
            set {
                _IsNoneNumber = value;
                
                if (_IsNoneNumber == true)
                {
                    _IsContinued = false;
                }
            }
        }
         //----------------------------------------------
        public string NumberStr
        {
            get
            {
                if ((Empty == true) || (_IsNoneNumber == true))
                {
                    return string.Empty;
                }
                else
                {

                    return _NumberStr;
                }
            }
            set { _NumberStr = value; }
        }
		//----------------------------------------------
        public string SecFrame(float fps)
        {
            int frm = (int)Math.Round(Duration * fps);
            int _Fps = (int)Math.Round(fps);
            string ret = "";

            ret = (frm / _Fps).ToString() + "+";
            int v = frm % _Fps;
            if (v <= 0)
            {
                ret += "00";
            }
            else if (v < 10)
            {
                ret += "0" + v.ToString();
            }
            else
            {
                ret += v.ToString();
            }
            

            return ret;
        }
        //----------------------------------------------
        public string DispNumber
        {
            get
            {
                if ( _NumberStr != string.Empty)
                {
                    return _NumberStr;
                }
                    
                else
                {
                    int v = _Number + 1;
                    //3桁に強制
                    if (v <= 0)
                    {
                        return "000";
                    }
                    else if (v < 10)
                    {
                        return "00" + v.ToString();
                    }
                    else if (v < 100)
                    {
                        return "0" + v.ToString();
                    }
                    else
                    {
                        return v.ToString();
                    }
                }
            }
        }
        //----------------------------------------------
        public int Number
        {
            get { return _Number; }
            set { _Number = value; }
        }
        //----------------------------------------------------------------
        private string Decord(string value)
        {

            return value.Replace("\\n","\n");
        }
        
        //----------------------------------------------------------------
        private string Encord(string value)
        {
            if (value == string.Empty)
            {
                return string.Empty;
            }
            else
            {
                return value.Replace("\n", "\\n");
            }
        }
        //----------------------------------------------------------------
        public string MemoStr
        {
            get { return Decord(Memo); }
            set { Memo = Encord(value); }
        }
		//----------------------------------------------------------------
		public string MemoUStr
		{
			get { return Decord(MemoU); }
			set { MemoU = Encord(value); }
		}
		//----------------------------------------------------------------
        public string WordsStr
        {
            get { return Decord(Words); }
            set { Words = Encord(value); }
        }
		//----------------------------------------------------------------
		public string WordsUStr
		{
			get { return Decord(WordsU); }
			set { WordsU = Encord(value); }
		}
		//----------------------------------------------------------------
        public bool KomaEnabled
        {
            get
            {
                if (_Empty == true) return false;
                if ((_IsContinued == true) || (_IsNoneNumber == true)) return true;
                if (_Pic.name != string.Empty) return true;
                if (_PicSub.name != string.Empty) return true;
                if (Memo != string.Empty) return true;
				if (MemoU != string.Empty) return true;
				if (Words != string.Empty) return true;
				if (WordsU != string.Empty) return true;
				if (_NumberStr != string.Empty) return true;
                if (Duration > 0) return true;
                if ( IsPageBreak == true) return true;
                if (IsPartEnd == true) return true;
                return false;
            }
        }
        //----------------------------------------------------------------
        public string PictName
        {
            get
            {
                if (_Empty == true)
                {
                    return "";
                }
                else
                {
                    return _Pic.name;
                }
            }
            set
            {
                if (_Empty == false)
                {
                    _Pic.name = value; ;
                }
            }
        }
        //----------------------------------------------------------------
        public KomaPict Pic
        {
            get { return _Pic; }
            set { _Pic = value; }
        }
        //----------------------------------------------------------------
        public KomaPict PicSub
        {
            get { return _PicSub; }
            set { _PicSub = value; }
        }
        //----------------------------------------------------------------
        public int PartNumber
        {
            get { return _PartNumber; }
            set { _PartNumber = value; }

        }

    }


}
