﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ContEditorNazoh
{
    public partial class SelectPictureDlg : Form
    {
        private ContDocument contDocument;
        private string _NazDir ="";
        private string _ImageDir ="";
        private string _ThumbDir ="";
        private Bitmap bmp = null;
        private string _FileName = "";
        public SelectPictureDlg(ContDocument ci)
        {
            InitializeComponent();
            contDocument = ci;
            _NazDir = ci.NazDir;
            _ImageDir = ci.ImageDir;
            _ThumbDir = ci.ThumsDir;
            _FileName = contDocument.GetPictureName(ci.SelectedIndex);
            ListUp();
            if (_FileName != string.Empty)
            {
                lbLink.Text = _FileName;
                FindTarget();
            }
            else
            {
                lbLink.Text = "no link";
            }
            lbFind.Text = "Find PictureName";
        }
        //--------------------------
        public void ListUp()
        {
            listBox1.Items.Clear();
            lbFind.Text = "Find PictureName";
            lbInfo.Text =
                lbPreview.Text = "";
            lbLink.Text = "no link";
            pictureBox1.Image = ContEditorNazoh.Properties.Resources.NoneSelectedPicture;
            pictureBox1.Invalidate();
            if (contDocument == null) return;
            if (Directory.Exists(_ImageDir) == false) return;

            string[] files = Directory.GetFiles(_ImageDir);
            if (files.Length <= 0) return;
            for ( int i=0; i<files.Length;i++)
            {
                string ss = Path.GetFileName(files[i]);
                string e = Path.GetExtension(ss).ToLower();
                if ((e == ".jpg") || (e == ".png") || (e == ".tif") || (e == ".bmp"))
                {
                    listBox1.Items.Add(ss);
                }
            }
        }
        //--------------------------
        private void FindTarget()
        {
            if (_FileName == "") return;
            int cnt = listBox1.Items.Count;
            if (cnt <= 0) return;
            string tar = _FileName.ToLower();
            for (int i = 0; i < cnt; i++)
            {
                string ss = listBox1.Items[i].ToString().ToLower();
                if (string.Compare(tar, ss, true) == 0)
                {
                    listBox1.SelectedIndex = i;
                    break;
                }
            }

        }
        //--------------------------
        private void btnLoad_Click(object sender, EventArgs e)
        {
            ListUp();
            if (_FileName != string.Empty)
            {
                lbLink.Text = _FileName;
                FindTarget();
            }

        }
        //--------------------------
        public void preview(int idx)
        {
            if (idx < 0)
            {
                pictureBox1.Image = null;
                if (bmp != null)
                {
                    bmp.Dispose();
                    bmp = null;
                }
                lbPreview.Text = "";
                lbInfo.Text = "";
                pictureBox1.Image = ContEditorNazoh.Properties.Resources.NoneSelectedPicture;
                pictureBox1.Invalidate();
            }
            else
            {
                string n = listBox1.Items[idx].ToString();
                string p = Path.Combine(_ImageDir,n);
                try
                {
                    Bitmap buf = new Bitmap(p);
                    try
                    {
                        bmp = new Bitmap(buf.Width, buf.Height, buf.PixelFormat);
                        bmp.SetResolution(buf.HorizontalResolution, buf.VerticalResolution);
                        Graphics.FromImage(bmp).DrawImage(buf, new Rectangle(0, 0, bmp.Width, bmp.Height));
                    }
                    finally
                    {
                        buf.Dispose();
                    }
                    pictureBox1.Image = bmp;
                    lbPreview.Text = n;
                    lbInfo.Text = "Width:" + bmp.Width.ToString() + "Height:" + bmp.Height.ToString() + "dpi:" + bmp.HorizontalResolution.ToString();
                }
                catch
                {
                    pictureBox1.Image = null;
                    bmp = null;
                }
            }
        }
        //----------------------------------------------------------------------
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            preview(listBox1.SelectedIndex);
            bool b = (listBox1.SelectedIndex >= 0);
            btnDelete.Enabled = b;
            if (b == false)
            {

            }

        }
        //----------------------------------------------------------------------
        public string FileName
        {
            get
            {
                if (listBox1.SelectedIndex >= 0)
                {
                    return listBox1.Items[listBox1.SelectedIndex].ToString();
                }
                else
                {
                    return "";
                }
            }
            set
            {
                _FileName = value;
            }
        }

        //----------------------------------------------------------------------
        private void SelectPictureDlg_FormClosing(object sender, FormClosingEventArgs e)
        {
            pictureBox1.Image = null;
            if (bmp != null)
            {
                bmp.Dispose();
                bmp = null;
            }
        }
        //--------------------------------------------------------------------------------

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (contDocument == null) return;
            if ( listBox1.SelectedIndex <0) return;
            string n = listBox1.Items[listBox1.SelectedIndex].ToString();
            if (bmp != null)
            {
                pictureBox1.Image = null;
                bmp.Dispose();
            }
            contDocument.DeletePictureFile(n);

            ListUp();
        }
        //--------------------------------------------------------------------------------
        private void tbFind_TextChanged(object sender, EventArgs e)
        {
            btnFindPrev.Enabled = btnFindNext.Enabled = (tbFind.Text != string.Empty);
        }
        //--------------------------------------------------------------------------------
        private void FindNext()
        {
            int si = listBox1.SelectedIndex;
            if (si<0)  si = 0;
            int cnt = listBox1.Items.Count-1;
            int t = -1;
            string s = "";
            if (si < cnt)
            {
                string target = tbFind.Text.Trim().ToLower();
                for (int i = si + 1; i <= cnt; i++)
                {
                    s = listBox1.Items[i].ToString();
                    if (s.ToLower().IndexOf(target) >= 0)
                    {
                        t = i;
                        break;
                    }

                }

            }
            if (t >= 0)
            {
                lbFind.Text = "Find :" + s;
                listBox1.SelectedIndex = t;
            }
            else
            {
                lbFind.Text= "not Found!";
            }
        }
        //--------------------------------------------------------------------------------
        private void FindPrev()
        {
            int si = listBox1.SelectedIndex;
            if (si<0)  si = listBox1.Items.Count-1;
            int t = -1;
            string s = "";
            if (si > 0)
            {
                string target = tbFind.Text.Trim().ToLower();
                for (int i = si - 1; i >=0; i--)
                {
                    s = listBox1.Items[i].ToString();
                    if (s.ToLower().IndexOf(target) >= 0)
                    {
                        t = i;
                        break;
                    }

                }

            }
            if (t >= 0)
            {
                lbFind.Text = "Find :" + s;
                listBox1.SelectedIndex = t;
            }
            else
            {
                lbFind.Text= "not Found!";
            }
        }
        //---------------------------------------------------------------------
        private void btnFindPrev_Click(object sender, EventArgs e)
        {
            FindPrev();
        }

        private void btnFindNext_Click(object sender, EventArgs e)
        {
            FindNext();
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnImport_Click(object sender, EventArgs e)
        {
            if (contDocument == null) return;

            contDocument.ImportResize = ImportResize;
            string nm = contDocument.ImportPictureDlg();
            if (nm != "")
            {
                ListUp();
                _FileName = nm;
                lbLink.Text = _FileName;
                FindTarget();
            }
        }
        public ImportResize ImportResize
        {
            get
            {
                int v = cmbImport.SelectedIndex;
                if (v < 0) v = 0;
                return (ImportResize)v;
            }
            set
            {
                int v = (int)value;
                if (v < 0) v = 0;
                else if (v >= cmbImport.Items.Count) v = cmbImport.Items.Count - 1;
                cmbImport.SelectedIndex = v;
            }
        }

    }
}
