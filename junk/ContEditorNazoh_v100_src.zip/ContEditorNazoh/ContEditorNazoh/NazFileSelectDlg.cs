﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ContEditorNazoh
{
    public partial class NazFileSelectDlg : Form
    {
        /// <summary>
        /// NazFileのあるパス。NazDir
        /// </summary>
        private string _NazDir = "";
        private NazFileSelector _Mode = NazFileSelector.Select;
        //-------------------------------------------------------------------
        /// <summary>
        /// 作成後あらかじめ作成してあるリストをNazFileへ入れる事。
        /// </summary>
        /// <param name="m"></param>
        public NazFileSelectDlg(NazFileSelector m)
        {
            InitializeComponent();
            lbSelectedNaz.Text = "";
            RenameMode = m;
            PrefLoad();
        }
        //-------------------------------------------------------------------
        public NazFileSelectDlg(NazFileSelector m, string nd,string target)
        {
            InitializeComponent();
            lbSelectedNaz.Text = "";
            RenameMode = m;
            SetNazFiles(Directory.GetFiles(nd, "*" + def.NazExt));
            SetNazFileName(target);
            PrefLoad();
        }
        //-------------------------------------------------------------------
        public NazFileSelector RenameMode
        {
            get
            {
                return _Mode;
            }
            set
            {
                _Mode = value;
                switch (value)
                {
                    case NazFileSelector.Select:
                        btnOK.Text = "選択";
                        tbNewNazFileName.Enabled = false;
                        cbNoneClear.Visible = false;
                        btnCancel.Enabled = false;
                        break;
                    case NazFileSelector.Rename:
                        btnOK.Text = "改名";
                        tbNewNazFileName.Enabled = true;
                        cbNoneClear.Visible = false;
                        btnCancel.Enabled = true;
                        break;
                    case NazFileSelector.Create:
                        btnOK.Text = "作成";
                        tbNewNazFileName.Enabled = true;
                        cbNoneClear.Visible = true;
                        btnCancel.Enabled = true;
                        break;
                }
            }
        }
        //-------------------------------------------------------------------
        public bool IsNoneClear
        {
            get { return cbNoneClear.Checked; }
            set { cbNoneClear.Checked = value; }
        }
        //-------------------------------------------------------------------
        public void SetNazFiles(string [] value)
        {
            listBox1.Items.Clear();
            if (value.Length > 0)
            {
                _NazDir = Path.GetDirectoryName(value[0]);
                foreach (string s in value)
                {
                    string ss = Path.GetFileNameWithoutExtension(s.Trim());
                    if (ss != string.Empty)
                    {
                        listBox1.Items.Add(ss);
                    }
                }
            }
        }
        //-------------------------------------------------------------------
        public string[] NazFiles
        {
            get
            {
                if ( listBox1.Items.Count<=0)
                {
                    return new string[0];
                }else{
                    string[] ret = new string[listBox1.Items.Count];
                    int i=0;
                    foreach (string s in listBox1.Items)
                    {
                        ret[i] = Path.Combine(_NazDir,Path.ChangeExtension( s,def.NazExt));
                        i++;
                    }
                    return ret;
                }

            }
            set
            {
                SetNazFiles(value);
                
            }
        }
        //-------------------------------------------------------------------
        public string NazDir
        {
            get { return _NazDir; }
            set { SetNazFiles( Directory.GetFiles(value, "*" + def.NazExt)); }
        }
        //-------------------------------------------------------------------
        public string NazFile
        {
            get
            {
                string p = tbNewNazFileName.Text;
                if (p != string.Empty)
                {
                    return Path.Combine(_NazDir, Path.ChangeExtension(p, def.NazExt));
                }
                else
                {
                    return string.Empty;
                }
            }
        }
        //-------------------------------------------------------------------
        public void SetNazFileName(string s)
        {
            int cnt = listBox1.Items.Count;
            if (cnt > 0)
            {
                string t = Path.GetFileNameWithoutExtension(s);
                int si = -1;
                for (int i = 0; i < cnt; i++)
                {
                    if (t == listBox1.Items[i].ToString())
                    {
                        si = i;
                        break;
                    }
                }
                if (si >= 0)
                {
                    listBox1.SelectedIndex = si;
                    lbSelectedNaz.Text = t;
                    tbNewNazFileName.Text = t;
                }
            }
        }
        //-------------------------------------------------------------------
        public string NazFileName
        {
            get
            {
                string p = tbNewNazFileName.Text;
                if (p != string.Empty)
                {
                    return Path.ChangeExtension(p, def.NazExt);
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                SetNazFileName(value);
            }
        }
        //-------------------------------------------------------------------
        /// <summary>
        /// 新しい名前がリストに存在してるか？
        /// </summary>
        /// <returns></returns>
        private bool IsNewNameInList()
        {
            int cnt = listBox1.Items.Count; 
            if ( cnt <= 0) return false;
            string t = tbNewNazFileName.Text.ToLower();

            for ( int i = 0; i<cnt; i++)
            {
                if (listBox1.Items[i].ToString().ToLower() == t)
                {
                    return true;
                }
            }
            return false;
        }
        //-------------------------------------------------------------------
        private void chkEnabled()
        {
            btnOK.Enabled = false;
            if (tbNewNazFileName.Text != string.Empty)
            {
                switch (_Mode)
                {
                    case NazFileSelector.Create:
                        if (IsNewNameInList() == false) btnOK.Enabled = true;
                        break;
                    case NazFileSelector.Rename:
                        if (IsNewNameInList() == false) btnOK.Enabled = true;
                        break;
                    case NazFileSelector.Select:
                        btnOK.Enabled = true;
                        break;

                }
            }
        }
        //-------------------------------------------------------------------
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
            {
                tbNewNazFileName.Text = listBox1.Items[listBox1.SelectedIndex].ToString();
            }
            else
            {
                tbNewNazFileName.Text = "";
            }
            chkEnabled();
        }
        //-------------------------------------------------------------------
        private void tbNewNazFileName_TextChanged(object sender, EventArgs e)
        {
            chkEnabled();
        }
        //-------------------------------------------------------------------
        private void PrefSave()
        {
            string p = Path.ChangeExtension(Application.ExecutablePath, def.NazPrefSTExt);
            SaveFiles sv = new SaveFiles(def.PrefHeader);
            sv.SetInt("Left", this.Left);
            sv.SetInt("Top", this.Top);
            sv.SaveToFile(p);
        }
        //---------------------------------------------------------------------------
        public void PrefLoad()
        {
            string p = Path.ChangeExtension(Application.ExecutablePath, def.NazPrefSTExt);
            SaveFiles sv = new SaveFiles(def.PrefHeader);
            sv.LoadFromFile(p);
            int l = sv.GetInt("Left", -1);
            int t = sv.GetInt("Top", -1);
            if ((l == -1) || (t == -1))
            {
                this.StartPosition = FormStartPosition.CenterScreen;
            }
            else
            {
                this.StartPosition = FormStartPosition.Manual;
                this.Left = l;
                this.Top = t;
            }
        }

        //---------------------------------------------------
        private void NazFileSelectDlg_FormClosed(object sender, FormClosedEventArgs e)
        {
            PrefSave();
        }
        //---------------------------------------------------
        private void NazFileSelectDlg_Load(object sender, EventArgs e)
        {
        }
        //---------------------------------------------------

     
    }
    public enum NazFileSelector
    {
        Select =0,
        Rename,
        Create,
        Count
    }
}
