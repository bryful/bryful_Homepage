﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public partial class ContDocument : Component
    {
        /// <summary>
        /// パートのキャプション配列
        /// </summary>
        private string[] _PartCaptions = new string[def.PartMaxCount];
        private int[] _PartCutCount = new int[def.PartMaxCount];
        private float[] _PartDuration = new float[def.PartMaxCount];
        /// <summary>
        /// パート数。1スタート
        /// </summary>
        private int _PartCount = 1;
        private bool _IsPrintPartCaption = false;
        //--------------------------------------------------------------------
        private void InitPartDuration()
        {
            for (int i = 0; i < def.PartMaxCount; i++)
            {
                _PartCutCount[i] = 0;
                _PartDuration[i] = 0f;
            }
        }
        //--------------------------------------------------------------------
        /// <summary>
        /// パートキャプションの初期値を設定
        /// </summary>
        public void DefaultPartCaption()
        {
            for (int i = 0; i < 26; i++)
            {
                _PartCaptions[i] = Char.ConvertFromUtf32('A' + i); ;
            }
            _PartCaptions[26] = "OP";
            _PartCaptions[27] = "ED";
            _PartCaptions[28] = "アバン";
            _PartCaptions[29] = "予告";
        }
        //--------------------------------------------------------------------
        /// <summary>
        /// パートキャプションを1行で獲得
        /// </summary>
        /// <returns>,で区切られた文字列。</returns>
        public string GetPartCaptionLine()
        {
            string ret = "";
            for (int i = 0; i < def.PartMaxCount; i++)
            {
                ret += _PartCaptions[i].Trim() + ",";//最後にもつくけど気にしない
            }
            return ret;
        }
        //--------------------------------------------------------------------
        /// <summary>
        /// 1行からパートキャプションを設定
        /// </summary>
        /// <param name="value">,で区切られた文字列</param>
        public void SetPartCaptionLine(string value)
        {
            DefaultPartCaption();
            if (value == string.Empty) return;
            string[] ss = value.Split(',');
            if (ss.Length < def.PartMaxCount) return;
            for (int i = 0; i < def.PartMaxCount; i++)
            {
                _PartCaptions[i] = ss[i].Trim();
            }
        }
        //--------------------------------------------------------------------
        /// <summary>
        /// パートキャプション配列
        /// </summary>
        public string PartCaptionsLine
        {
            get { return GetPartCaptionLine(); }
            set { SetPartCaptionLine(value); }
        }
        //--------------------------------------------------------------------
        public void ShowEditPartCaptionDlg(MainForm m)
        {
            EditPartCaptionsDlg dlg = new EditPartCaptionsDlg(m);
            if (dlg.ShowDialog() == DialogResult.OK)
            {

                bool b = false;
                for ( int i=0; i<def.PartMaxCount;i++)
                {
                    string s = dlg.Captions(i);
                    if (_PartCaptions[i] != s)
                    {
                        _PartCaptions[i] = s;
                        b = true;
                    }
                }
                if (_IsPrintPartCaption != dlg.IsPrintPartCaption)
                {
                    _IsPrintPartCaption = dlg.IsPrintPartCaption;
                    b = true;
                }
                if (b == true)
                {
                    OnkomaChanged(new EventArgs());
                }
            }

        }
        //--------------------------------------------------------------------
        public string GetPartCaptions(int idx)
        {
            if ((idx < 0) || (idx >= def.PartMaxCount)) return string.Empty;

            return _PartCaptions[idx];
        }
        //--------------------------------------------------------------------
        public void SetPartCaptions(int idx,string value)
        {
            if ((idx < 0) || (idx >= def.PartMaxCount)) return;

            _PartCaptions[idx] = value.Trim();
        }
        //--------------------------------------------------------------------
        public int PartCount
        {
            get { return _PartCount; }
        }
        //--------------------------------------------------------------------
        public string DispPartCaption(int idx)
        {
            if ((idx < 0) || (idx >=_Items.Count)) return string.Empty;
            int v = _Items[idx].PartNumber;
            return _PartCaptions[v];

        }
        //--------------------------------------------------------------------
        public bool IsPrintPartCaption
        {
            get {
                bool b = _IsPrintPartCaption;
                return b; 
            }
            set
            {
                bool b = value;
                _IsPrintPartCaption = b; 
            }
        }
        //------------------------------------------------------
        public bool GetPartEnd(int idx)
        {
            if ((idx < 0) || (idx >= _Items.Count)) return false;
            if (_Items[idx].Empty == true) return false;
            int ii = idx;
            if (_Items[idx].IsContinuedNext == true)
            {
                if (idx < _Items.Count - 1)
                {
                    for (int i = idx + 1; i < _Items.Count; i++)
                    {

                        if (_Items[i].IsContinuedNext == false)
                        {
                            ii = i;
                            break;
                        }

                    }
                }
                else
                {
                    ii = _Items.Count - 1;
                }
            }
            return _Items[ii].IsPartEnd;
        }
        //------------------------------------------------------
        public void SetPartEnd(int idx, bool b)
        {
            if (_Locked == true) return;
            if ((idx < 0) || (idx >= _Items.Count)) return;
            if (_Items[idx].Empty == true) return;
            int ii = idx;
            if (_Items[idx].IsContinuedNext == true)
            {
                if (idx < _Items.Count - 1)
                {
                    for (int i = idx + 1; i < _Items.Count; i++)
                    {

                        if (_Items[i].IsContinuedNext == false)
                        {
                            ii = i;
                            break;
                        }

                    }
                }
                else
                {
                    ii = _Items.Count - 1;
                }
            }

            if (_Items[ii].IsPartEnd != b)
            {
                _Items[ii].IsPartEnd = b;
                _SelectedIndex = ii;
                ChkItems();
                CurrentPageChk();
                _changeFlag = true;
                OnkomaChanged(new EventArgs());
            }
        }
        //-------------------------------------------------------------------------------
        public bool IsPartEnd
        {
            get
            {
                ChkSelected();
                if (_SelectedIndex < 0)
                { return false; }
                else
                {
                    return GetPartEnd(_SelectedIndex);
                }
            }
            set
            {
                if (_Locked == true) return;
                ChkSelected();
                SetPartEnd(_SelectedIndex, value);

            }
        }
        //-------------------------------------------------------------------------------
        public void GoPartStart()
        {
            if (_PartCount <= 0) return;
            int idx = _SelectedIndex;
            if (idx <= 0) return;

			if (idx > 0)
			{
				if (_Items[idx - 1].IsPartEnd == true)
				{
					idx--;
				}
			}
			int g = 0;

			if (idx > 0)
			{

				for (int i = idx - 1; i >= 0; i--)
				{
					if (_Items[i].IsPartEnd == true)
					{
						g = i + 1;
						break;
					}
				}
			}
            if (g >= 0)
            {
                if (_SelectedIndex != g)
                {
                    _SelectedIndex = g;
                    CurrentPageChk();
                    OnkomaChanged(new EventArgs());
                }
            }
        }
        //-------------------------------------------------------------------------------
        public void GoPartEnd()
        {
            if (_PartCount <= 0) return;
            int idx = _SelectedIndex;
            if (idx < 0) idx = 0;
            else if (idx >= _Items.Count - 1) return;
            int g = _Items.Count -1;
            for (int i = idx + 1; i <_Items.Count; i++)
            {
                if (_Items[i].IsPartEnd == true)
                {
                    g = i;
                    break;
                }
            }
            if (g >= 0)
            {
                if (_SelectedIndex != g)
                {
                    _SelectedIndex = g;
                    CurrentPageChk();
                    OnkomaChanged(new EventArgs());
                }
            }
        }
		//-------------------------------------------------------------------------------
		public string GetPartDuration(int idx)
		{
			if ((idx < 0) || (idx >= _PartCount)) return DurationToSecFrame(0f);
			return DurationToSecFrame(_PartDuration[idx]);
		}
		//-------------------------------------------------------------------------------
		public string GetPartCount(int idx)
		{
			if ((idx < 0) || (idx >= _PartCount)) return "000";
			return Zero3(_PartCutCount[idx]);
		}

    }
}
