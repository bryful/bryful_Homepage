﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ContEditorNazoh
{
    public partial class MainForm : Form
    {
        /// <summary>
        /// 秒入力をフレームでやるか、秒+コマでやるかのフラグ
        /// </summary>
        private bool IsInputFrame = false;

        public ContPreviewForm cpf = null;
		public PartInfoForm pif = null;
        //---------------------------------------------------------------------------
        public MainForm()
        {
            InitializeComponent();
            PrefLoad();
        }
        //---------------------------------------------------------------------------
        private bool ChkOpenNaz(string path)
        {
            string p = path.Trim();
            if (Directory.Exists(path) == true) return true;
            if (File.Exists(path) == false) return false;
            string e = Path.GetExtension(p).ToLower();
            return (e == ".naz");
        }
        //---------------------------------------------------------------------------
        private void MainForm_Load(object sender, EventArgs e)
        {
            //ダブルクリックの処理
            string[] cmds;
            cmds = System.Environment.GetCommandLineArgs();
            string p = "";
            if (cmds.Length > 1)
            {
                for (int i = 1; i < cmds.Length; i++)
                {
                    if (ChkOpenNaz(cmds[i]) == true)
                    {
                        p = cmds[i].Trim();
                        break;
                    }
                }
            }

            if (p != string.Empty)
            {
                if (contDocument1.OpenNazFile(p) == false)
                {
                    p = "";
                }
            }
            if (p == string.Empty)
            {
                if (NazBrowser() == false)
                {
                    this.Close();
                }
            }
            ChkStstus();
            this.Text = contDocument1.NazCaption;
        }
		////////////////////////////////////////////////////////////////////////////////////
		/*
		 * イベント処理
		 */ 
		////////////////////////////////////////////////////////////////////////////////////
		//--------------------------------------------------------------------------------
        private void MainForm_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                //ドラッグされたデータ形式を調べ、ファイルのときはコピーとする
                e.Effect = DragDropEffects.Copy;
            else
                //ファイル以外は受け付けない
                e.Effect = DragDropEffects.None;
        }
        //--------------------------------------------------------------------------------
        private void MainForm_DragDrop(object sender, DragEventArgs e)
        {
            string[] fileNames = (string[])e.Data.GetData(DataFormats.FileDrop, false);

            if (fileNames.Length > 0)
            {
                for (int i = 0; i < fileNames.Length; i++)
                {
                    if (ChkOpenNaz(fileNames[i]) == true)
                    {
                        //セーブする
                        if (contDocument1.Locked == false)
                        {
                            memoAndWords1.ToContDocument();
                            if (contDocument1.SaveNaz() == true)
                            {
                            }
                        }
                        if (contDocument1.OpenNazFile(fileNames[i]) == true)
                        {
                            ChkStstus();
                            this.Text = contDocument1.NazCaption;
                            break;
                        }
                    }
                }
            }
        }
        //---------------------------------------------------------------------------
        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (contDocument1.NazDir != "")
            {
                NazSave();
            }
            PrefSave();
        }
        //---------------------------------------------------------------------------
        public ContDocument ContDocument
        {
            get { return contDocument1; }
            set { contDocument1 = value; }
        }
        //****************************************************************************
        /*
         * 機能追加
         */
        //****************************************************************************
        //---------------------------------------------------------------------------
        /// <summary>
        /// IsContinuedの設定
        /// </summary>
        private void SetIsContinued()
        {
            if (contDocument1.Locked == true) return;
            if (contDocument1.SelectedIndex < 0) return;

            bool b = !isContinuedMenu.Checked;
            if (contDocument1.IsContinued != b)
            {
                memoAndWords1.ToContDocument();
                contDocument1.IsContinued = b;
            }
        }
        //---------------------------------------------------------------------------
        /// <summary>
        /// IsNoneNumberの設定
        /// </summary>
        private void SetIsNoneNumber()
        {
            if (contDocument1.Locked == true) return;
            if (contDocument1.SelectedIndex < 0) return;

            bool b = !IsNoneNumberMenu.Checked;
            if (contDocument1.IsNoneNumber != b)
            {
                memoAndWords1.ToContDocument();
                contDocument1.IsNoneNumber = b;
            }
        }
        //---------------------------------------------------------------------------
        /// <summary>
        /// lockedの設定
        /// </summary>
        public void SetLoacked()
        {
            memoAndWords1.Enabled = !contDocument1.Locked;
            SaveBtn.Enabled = !contDocument1.Locked;
            saveMenu.Enabled = !contDocument1.Locked;
        }
        //---------------------------------------------------------------------------
        /// <summary>
        /// NazFileの上書き保存
        /// </summary>
        public void NazSave()
        {
            if (contDocument1.Locked == true) return;
            if (contDocument1.Enabled == false)
            {
                NazBrowser();
                return;
            }
            memoAndWords1.ToContDocument();
            if (contDocument1.SaveNaz() == true)
            {
            }
        }
        //****************************************************************************
        /*
         * ダイアログ処理
         */
        //****************************************************************************
        //---------------------------------------------------------------------------
        public bool NazBrowser()
        {
            memoAndWords1.ToContDocument();
			
			if (contDocument1.SaveNaz() == true)
			{
				this.Text = contDocument1.NazCaption;
			}

            if (contDocument1.OpenNazBrowser() == true)
            {
                ChkStstus();
                this.Text = contDocument1.NazCaption;
                return true;
            }
            else
            {
                this.Text = "ロ～ン！ブロ～ゾ～！！";
                return false;
            }

        }
        //---------------------------------------------------------------------------
        public void EditDuration()
        {
            if ( (contDocument1.Enabled == false)||(contDocument1.Locked == true)) return;
            if (contDocument1.SelectedIndex >= 0)
            {
                if ((contDocument1.IsNoneNumber == true) || (contDocument1.Empty == true)) return;
                EditDurationDlg dlg = new EditDurationDlg(contDocument1.fps);
                dlg.Duration = contDocument1.GetDuration(contDocument1.SelectedIndex);
                dlg.IsInputFrame = IsInputFrame;
                memoAndWords1.ToContDocument();
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    contDocument1.SetDuration(contDocument1.SelectedIndex, dlg.Duration);
                    IsInputFrame = dlg.IsInputFrame;
                }
            }

        }
        //---------------------------------------------------------------------------
        public void ShowPreviewForm()
        {
            memoAndWords1.ToContDocument();
            if (cpf == null)
            {
                cpf = new ContPreviewForm(this);
                cpf.Currentpage = contDocument1.CurrentPage;
                cpf.Show();
            }
            else
            {
                cpf.Show();
                cpf.Focus();

            }
        }
		//---------------------------------------------------------------------------
		public void ShowPartInfoForm()
		{
			if (pif == null)
			{
				pif = new PartInfoForm(this);
				pif.Show();
			}
			else
			{
				pif.Show();
				pif.Focus();

			}
		}
		//****************************************************************************
        /*
         * 表示関係
         */
        //****************************************************************************
        //---------------------------------------------------------------------------
        private void contDocument1_CurrentPageChanged(object sender, EventArgs e)
        {
            lbCurrentPage.Text = contDocument1.PageNavCaption;
            if (PageScrol.Value != contDocument1.CurrentPage)
            {
                if (contDocument1.CurrentPage > PageScrol.Maximum)
                {
                    ChkStstus();
                }
                PageScrol.Value = contDocument1.CurrentPage;
            }
            this.Invalidate();
        }
        //---------------------------------------------------------------------------
        public void DispTotalTime()
        {
            lbCutCount.Text = "カット数: " + contDocument1.CutCount.ToString();
            lbTotalSec.Text = "総秒数: " + contDocument1.SecKoma;
            lbParCutSec.Text = "平均カット秒: " + contDocument1.ParCutSec;
            lbTargetSec.Text = contDocument1.DurationInfo;
            lbCutAdd.Text = contDocument1.CutAddInfo;
            if (contDocument1.NoneDurationCut == 0)
            {
                lbNoneDurationCut.Text = "--";
            }
            else
            {
                lbNoneDurationCut.Text = "秒無指定:" + contDocument1.NoneDurationCut.ToString();
            }
			if (pif != null)
			{
				pif.DispInfo();
			}
        }
       
        //---------------------------------------------------------------------------
        private void ChkStstus()
        {
            btnTopPage.Enabled = false;
            btnPrevPage.Enabled = false;
            btnNextPage.Enabled = false;
            btnLastPage.Enabled = false;

            btnKomaUpto.Enabled = false;
            btnKomaDownto.Enabled = false;
			btnCutUpto.Enabled = false;
			btnCutDownto.Enabled = false;
            btnInputSec.Enabled = false;

            btnImport.Enabled = false;
            btnSelectPic.Enabled = false;
            btnAppendPage.Enabled = false;
            btnPageBreak.Enabled = false;
            btnPicOffset.Enabled = false;
            
            if (contDocument1.Enabled == false) return;
            
            btnAppendPage.Enabled = true;
            
            int si = contDocument1.SelectedIndex;

            if  ( (si >= 0)&&(contDocument1.GetEmpty(si)==false))
            {
                btnCutDownto.Enabled = true;
                btnCutUpto.Enabled = true;
                if (si > 0)
                {
                    btnKomaUpto.Enabled = true;
                }
                if (si < contDocument1.ItemsCount - 1)
                {
                    btnKomaDownto.Enabled = true;
                }

                if (contDocument1.Empty == false)
                {
                    if (contDocument1.IsNoneNumber == false)
                    {
                        btnInputSec.Enabled = true;
                    }
                    btnImport.Enabled = true;
                    btnSelectPic.Enabled = true;
                }
                btnPageBreak.Enabled = true;

                string s = contDocument1.GetPictureName(contDocument1.SelectedIndex);
                if (s == string.Empty)
                {
                    lbPictureName.Text = "no link";
                }
                else
                {
                    lbPictureName.Text = s;
                    btnPicOffset.Enabled = true;
                }


            }
            else
            {
                lbPictureName.Text = "Pict Name";
            }
            int pc = contDocument1.PageCount -1;
            int cp = contDocument1.CurrentPage;
            if (cp > 0)
            {
                btnTopPage.Enabled = true;
                btnPrevPage.Enabled = true;
            }
            if (cp < pc)
            {
                btnLastPage.Enabled = true;
                btnNextPage.Enabled = true;
            }

            //--------
            if (contDocument1.PageCount <= 1)
            {
                PageScrol.Enabled = false;
                if (PageScrol.Maximum != 0)
                {
                    PageScrol.Maximum = 0;
                }
                if (PageScrol.Value != 0)
                {
                    PageScrol.Value = 0;
                }
            }
            else
            {
                PageScrol.Enabled = true;
                if (PageScrol.Maximum != contDocument1.PageCount - 1)
                {
                    PageScrol.Maximum = contDocument1.PageCount - 1;
                }
                if (PageScrol.Value != contDocument1.CurrentPage)
                {
                    PageScrol.Value = contDocument1.CurrentPage;
                }
            }
            DispTotalTime();
            lbCurrentPage.Text = contDocument1.PageNavCaption;
            

        }
        //****************************************************************************
        /*
         * ファイル関係
         */
        //****************************************************************************
        //---------------------------------------------------------------------------
        public void ImportPicture()
        {
            if (contDocument1.Locked == true) return;
            if (contDocument1.SelectedIndex < 0) return;
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "Import Picture";
            dlg.Filter = "png|*.png|jpeg|*.jpg|all|*.*";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                memoAndWords1.ToContDocument();
                switch ( contDocument1.ImportPicture(dlg.FileName, contDocument1.SelectedIndex))
                {
                    case ImportErr.NoErr:
                        this.Invalidate();
                        break;
                    case ImportErr.DPIErr:
                        MessageBox.Show("解像度エラー");
                        break;
                    case ImportErr.EmptyKoma:
                        MessageBox.Show("Emptyなコマにはインポートできません。");
                        break;
                    case ImportErr.IndexErr:
                        MessageBox.Show("Index Error!");
                        break;
                    case ImportErr.LoadErr:
                        MessageBox.Show("Load Error!");
                        break;
                    case ImportErr.NoneFile:
                        MessageBox.Show("not Found. Error!");
                        break;
                    case ImportErr.SameFile:
                        MessageBox.Show("同じファイル名のファイルが既に登録されています");
                        break;
                    case ImportErr.ThumbErr:
                        MessageBox.Show("サムネイル作成できません。");
                        break;
                }
 
            }
        }
        //---------------------------------------------------------------------------
        public void SelectPicture()
        {
            if (contDocument1.Locked == true) return;
            if (contDocument1.SelectedIndex < 0) return;
            SelectPictureDlg dlg = new SelectPictureDlg(contDocument1);
            memoAndWords1.ToContDocument();
            dlg.ImportResize = contDocument1.ImportResize;
            switch (dlg.ShowDialog())
            {
                case DialogResult.OK:
                    contDocument1.ImportResize = dlg.ImportResize;
                    contDocument1.SetPictureName(contDocument1.SelectedIndex,dlg.FileName);
                    komaDraw1.DisposeThumb(contDocument1.SelectedIndex);
                    break;
                case DialogResult.Ignore:
                    contDocument1.ImportResize = dlg.ImportResize;
                    contDocument1.SetPictureName(contDocument1.SelectedIndex,"");
                    komaDraw1.DisposeThumb(contDocument1.SelectedIndex);
                    break;
            }
        }
        //---------------------------------------------------------------------------
        public void PrefSave()
        {
            string p = Path.ChangeExtension(Application.ExecutablePath, def.NazPrefExt);
            SaveFiles sv = new SaveFiles(def.PrefHeader);
            sv.SetInt("Left", this.Left);
            sv.SetInt("Top", this.Top);
            sv.SetInt("ImportResize", (int)contDocument1.ImportResize);
            sv.SaveToFile(p);
        }
        //---------------------------------------------------------------------------
        public void PrefLoad()
        {
            string p = Path.ChangeExtension(Application.ExecutablePath, def.NazPrefExt);
            SaveFiles sv = new SaveFiles(def.PrefHeader);
            sv.LoadFromFile(p);
            int l = sv.GetInt("Left", -1);
            int t = sv.GetInt("Top", -1);
            if ((l == -1) || (t == -1))
            {
                this.StartPosition = FormStartPosition.CenterScreen;
            }
            else
            {
                this.StartPosition = FormStartPosition.Manual;
                this.Left = l;
                this.Top = t;
            }
            int v = sv.GetInt("ImportResize", (int)ImportResize.none);
            if (v < 0) v = 0;
            else if (v >= (int)ImportResize.Count) v = 0;
            contDocument1.ImportResize = (ImportResize)v;
        }
        //---------------------------------------------------------------------------
        public void EditPicture()
        {
        }

        //****************************************************************************
        /*
         * イベント処理
         */
        //****************************************************************************
        private void KomaStatusMenu_Opening(object sender, CancelEventArgs e)
        {
            isContinuedMenu.Checked = contDocument1.IsContinued;
            IsNoneNumberMenu.Checked = contDocument1.IsNoneNumber;
            peastPictureLinkMenu2.Enabled = contDocument1.IsPictureLink;


        }
        //---------------------------------------------------------------------------
        private void isContinuedMenu_Click(object sender, EventArgs e)
        {
            SetIsContinued();
        }
        //---------------------------------------------------------------------------
        private void IsNoneNumberMenu_Click(object sender, EventArgs e)
        {
            SetIsNoneNumber();
        }

        //---------------------------------------------------------------------------
        private void nazBrowserMenu_Click(object sender, EventArgs e)
        {
            NazBrowser();
        }
        //---------------------------------------------------------------------------
        private void saveMenu_Click(object sender, EventArgs e)
        {
            NazSave();
        }
        //---------------------------------------------------------------------------
        private void cutSec1_DoubleClick(object sender, EventArgs e)
        {
            EditDuration();
        }
        //---------------------------------------------------------------------------
        private void appendPageMenu_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            memoAndWords1.ToContDocument();
            contDocument1.AppendPage();
            ChkStstus();
        }
        //---------------------------------------------------------------------------
        private void btnPrevPage_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            memoAndWords1.ToContDocument();
            contDocument1.PrevPage();
            ChkStstus();
        }
        //---------------------------------------------------------------------------
        private void btnNextPage_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            memoAndWords1.ToContDocument();
            contDocument1.NextPage();
            ChkStstus();
        }

        private void partEndMenu_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            memoAndWords1.ToContDocument();
            contDocument1.IsPartEnd = !contDocument1.IsPartEnd;
            ChkStstus();

        }

        //---------------------------------------------------------------------------
        private void btnPageBreak_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            memoAndWords1.ToContDocument();
            contDocument1.IsPageBreak = !contDocument1.IsPageBreak;
            ChkStstus();
        }
        //--------------------------------------------------------------------------------
        private void btnPreviewForm_Click(object sender, EventArgs e)
        {
            ShowPreviewForm();
        }
        //---------------------------------------------------------------------------
        private void btnImport_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            ImportPicture();
            ChkStstus();
        }
        //---------------------------------------------------------------------------
        private void btnSelectPic_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            SelectPicture();
            ChkStstus();
        }
        //---------------------------------------------------------------------------
        private void previewMenu_Click(object sender, EventArgs e)
        {
            ShowPreviewForm();
        }
        //---------------------------------------------------------------------------
        private void PageScrol_ValueChanged(object sender, EventArgs e)
        {
            if (contDocument1.CurrentPage != PageScrol.Value)
            {
                contDocument1.CurrentPage = PageScrol.Value;
            }
        }
        //---------------------------------------------------------------------------
        private void btnTopPage_Click(object sender, EventArgs e)
        {
            memoAndWords1.ToContDocument();
            contDocument1.TopPage();
            ChkStstus();
        }
        //---------------------------------------------------------------------------
        private void btnLastPage_Click(object sender, EventArgs e)
        {
            memoAndWords1.ToContDocument();
            contDocument1.LastPage();
            ChkStstus();
        }
        //---------------------------------------------------------------------------
        private void contDocument1_KomaCountChanged(object sender, EventArgs e)
        {
            ChkStstus();
        }
        //---------------------------------------------------------------------------
        private void renameTakeMenu_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            memoAndWords1.ToContDocument();
            contDocument1.NazFileNameRenameDlg();
            ChkStstus();
            this.Text = contDocument1.NazCaption;
        }
        //---------------------------------------------------------------------------
        private void newTakeTMenu_Click(object sender, EventArgs e)
        {
            memoAndWords1.ToContDocument();
            contDocument1.NazFileNameCreateDlg();
            ChkStstus();
            this.Text = contDocument1.NazCaption;
        }
        //---------------------------------------------------------------------------
        private void selectTakeMenu_Click(object sender, EventArgs e)
        {
            memoAndWords1.ToContDocument();
            if (contDocument1.NazFileNameSelectDlg() == true)
            {
                ChkStstus();
                this.Text = contDocument1.NazCaption;
                this.Invalidate();
            }
        }
        //---------------------------------------------------------------------------
        private void insertCutMenu_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            memoAndWords1.ToContDocument();
            contDocument1.InsertCut();
            ChkStstus();
        }
        //---------------------------------------------------------------------------
        private void incertContinedMenu_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            memoAndWords1.ToContDocument();
            contDocument1.InsertContinued();
            ChkStstus();
        }
        //---------------------------------------------------------------------------
        private void insertNoneNumberMenu_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            memoAndWords1.ToContDocument();
            contDocument1.InsertNoneNumber();
            ChkStstus();
        }
        //---------------------------------------------------------------------------
        private void contDocument1_komaChanged(object sender, EventArgs e)
        {
            ChkStstus();
            this.Invalidate();
        }
        //---------------------------------------------------------------------------
        private void contDocument1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ChkStstus();
        }
        //---------------------------------------------------------------------------
        private void MainForm_MouseDown(object sender, MouseEventArgs e)
        {
            int y = e.Y / def.PreviewKomaHeightP;
            if ((y >= 0) && (y < def.KomaCount))
            {
                int cp = contDocument1.CurrentPage; 
                int v =  cp * def.KomaCount + y;
                if ( contDocument1.SelectedIndex != v)
                {
                    //MessageBox.Show(v.ToString());
                    contDocument1.SelectedIndex = v;
                }
            }
        }
        //--------------------------------------------------------------------------------
        private void contDocument1_DurationChanged(object sender, EventArgs e)
        {
            DispTotalTime();
        }
        //--------------------------------------------------------------------------------
        private void clearKomaMenu_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            memoAndWords1.ToContDocument();
			NazSave();
			contDocument1.KomaClear();
            ChkStstus();
        }

        //--------------------------------------------------------------------------------
        private void contDocument1_komaChanged_1(object sender, EventArgs e)
        {
            SetLoacked();
            ChkStstus();
            this.Invalidate();
        }
        //--------------------------------------------------------------------------------
        private void deleteKomaMenu_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            memoAndWords1.ToContDocument();
            NazSave();
            contDocument1.KomaDelete();
            ChkStstus();
        }
		//--------------------------------------------------------------------------------
		private void deleteCutMenu_Click(object sender, EventArgs e)
		{
			if (contDocument1.Locked == true) return;
			memoAndWords1.ToContDocument();
			NazSave();
			contDocument1.DeleteCut();
			ChkStstus();

		}

        //--------------------------------------------------------------------------------
        private void MainForm_DoubleClick(object sender, EventArgs e)
        {
            if (contDocument1.SelectedIndex >= 0)
            {
                if (contDocument1.Locked == true) return;
                SelectPicture();
                ChkStstus();
            }
        }
        //--------------------------------------------------------------------------------
		private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
		{
			AboutDlg dlg = new AboutDlg();
			try
			{
				dlg.ShowDialog();
			}
			finally
			{
				dlg.Dispose();
			}
		}
        //--------------------------------------------------------------------------------
        private void helpToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			EasyHelp eh = new EasyHelp();
			try
			{
				eh.ShowDialog();
			}
			finally
			{
				eh.Dispose();
			}
		}
        //--------------------------------------------------------------------------------
        private void btnKomaUpto_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            memoAndWords1.ToContDocument();
            contDocument1.KomaUpto();
            ChkStstus();
        }
        //--------------------------------------------------------------------------------
        private void btnKomaDownto_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            memoAndWords1.ToContDocument();
            contDocument1.KomaDownto();
            ChkStstus();

        }
        //--------------------------------------------------------------------------------
        private void cutNumber1_DoubleClick(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            contDocument1.EditNumberStr();
            ChkStstus();
        }
        //--------------------------------------------------------------------------------
        private void copyPictureLink_Click(object sender, EventArgs e)
		{
            if (contDocument1.Locked == true) return;
            contDocument1.CopyPictureLink();
            ChkStstus();
        }

		//--------------------------------------------------------------------------------
		private void picturMenu_Click(object sender, EventArgs e)
		{
			peastPictureLinkMenu1.Enabled = contDocument1.IsPictureLink;
            ChkStstus();
        }
        //--------------------------------------------------------------------------------
        private void peastPictureLink_Click(object sender, EventArgs e)
		{
            if (contDocument1.Locked == true) return;
            contDocument1.PeastPictureLink();
            ChkStstus();
        }
        //--------------------------------------------------------------------------------
        private void unlinkPictureMenu_Click(object sender, EventArgs e)
		{
            if (contDocument1.Locked == true) return;
            contDocument1.DeletePictureLink();
            ChkStstus();
        }
        //--------------------------------------------------------------------------------
        private void contSettingMenu_Click(object sender, EventArgs e)
		{
			contDocument1.ShowContSettingDlg();
            ChkStstus();
            SetLoacked();
			this.Text = contDocument1.NazCaption;
		}

        private void cutSec1_Click(object sender, EventArgs e)
        {

        }

        private void trimPageMenu_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            memoAndWords1.ToContDocument();
            contDocument1.TrimItems();

        }

        private void btnPicOffset_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            contDocument1.ShowPictureOffsetDlg(this);

        }

        private void pictureImportMenu_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            contDocument1.ShowImportResize();

        }

		private void btnCutUpto_Click(object sender, EventArgs e)
		{
			if (contDocument1.Locked == true) return;
			memoAndWords1.ToContDocument();
			contDocument1.CutUpto();

		}

		private void btnCutDownto_Click(object sender, EventArgs e)
		{
			if (contDocument1.Locked == true) return;
			memoAndWords1.ToContDocument();
			contDocument1.CutDownto();

		}

        private void deletePictureFileMenu_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            memoAndWords1.ToContDocument();
            komaDraw1.IsNoDraw = true;
            contDocument1.DeletePictureFile();
            komaDraw1.IsNoDraw = false;
            this.Invalidate();
        }

        private void btnHideMemo_MouseDown(object sender, MouseEventArgs e)
        {
            memoAndWords1.Visible = false;
        }

        private void btnHideMemo_MouseUp(object sender, MouseEventArgs e)
        {
            memoAndWords1.Visible = true;
        }

        //--------------------------------------------------------------------------------
        private void pageSetupMenu_Click(object sender, EventArgs e)
        {
            contPrint1.ShowPageSetup();
        }

        //--------------------------------------------------------------------------------
        private void printPreviewMenu_Click(object sender, EventArgs e)
        {
            memoAndWords1.ToContDocument();
            contDocument1.SaveNaz();
            contPrint1.ShowPrintPreview();
        }
        //--------------------------------------------------------------------------------
        private void savePrintToolStripMenuItem_Click(object sender, EventArgs e)
        {
            contPrint1.SavePringImage();
        }
        //--------------------------------------------------------------------------------
        public void MemoToContDocument()
        {
            memoAndWords1.ToContDocument();
        }

        private void MainForm_Deactivate(object sender, EventArgs e)
        {
            memoAndWords1.ToContDocument();
        }

        private void memoAndWords1_MemoChanged(object sender, EventArgs e)
        {
            if (cpf != null)
            {
                cpf.Invalidate();
            }
        }

        private void printMenu_Click(object sender, EventArgs e)
        {
            memoAndWords1.ToContDocument();
            contPrint1.ShowPrint();
        }
        //--------------------------------------------------------------------------------
		public void MakeThumb()
		{
			if (contDocument1.SelectedIndex < 0) return;
			memoAndWords1.ToContDocument();
			string name = contDocument1.GetPictureName(contDocument1.SelectedIndex);
			if (contDocument1.MakeThumbFile(name) == ImportErr.NoErr)
			{
				komaDraw1.Clear();
				this.Invalidate();
			}
		}
		//--------------------------------------------------------------------------------
		public void MakeThumbALL()
		{
			memoAndWords1.ToContDocument();
			contDocument1.MakeThumbAll();
			komaDraw1.Clear();
			this.Invalidate();
		}
		//--------------------------------------------------------------------------------
		private void makeThumbMenu_Click(object sender, EventArgs e)
		{
			if (contDocument1.Locked == true) return;
			MakeThumb();
		}

		private void remakeThumbAllToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (contDocument1.Locked == true) return;
			MakeThumbALL();
		}

		//--------------------------------------------------------------------------------
		private void previewContMenu_Click(object sender, EventArgs e)
		{
			ShowPreviewForm();
		}
		//--------------------------------------------------------------------------------
		private void findNoneDurationMenu_Click(object sender, EventArgs e)
		{
			memoAndWords1.ToContDocument();
			contDocument1.FindNoneDurationCut();
		}

		private void cutNumberLockMenu_Click(object sender, EventArgs e)
		{
			contDocument1.NumberLocked();
		}

        private void extInstMenu_Click(object sender, EventArgs e)
        {
            ExtInstDlg dlg = new ExtInstDlg();
            dlg.ShowDialog();

        }

        private void editPartCaptionMenu_Click(object sender, EventArgs e)
        {
            memoAndWords1.ToContDocument();
            NazSave();
            contDocument1.ShowEditPartCaptionDlg(this);
        }

        private void partMenu_MouseEnter(object sender, EventArgs e)
        {
            bool b = contDocument1.IsPartEnd;
            if (b == true)
            {
                partEndMenu.Text = "パート終わりを解除";
            }
            else
            {
                partEndMenu.Text = "パート終わりに設定";
            }
            partEndMenu.Checked = contDocument1.IsPartEnd;
        }

        private void goPartStartToolStripMenuItem_Click(object sender, EventArgs e)
        {
            memoAndWords1.ToContDocument();
            contDocument1.GoPartStart();
        }

        private void goPartEndToolStripMenuItem_Click(object sender, EventArgs e)
        {
            memoAndWords1.ToContDocument();
            contDocument1.GoPartEnd();

        }

		private void partInfoMenu_Click(object sender, EventArgs e)
		{
			ShowPartInfoForm();
		}

		private void unlockedNumberMenu_Click(object sender, EventArgs e)
		{
			contDocument1.NumberUnlocked();

		}

        private void copyCutMenu_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            memoAndWords1.ToContDocument();
            contDocument1.CutToClip(false);
            ChkStstus();
        }

        private void cutMenu_MouseEnter(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            setCopyStartMenu.Text = contDocument1.ChkCopyStart();
            peastCutMenu.Enabled = contDocument1.ChkClip();
        }

        private void peastCutMenu_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            memoAndWords1.ToContDocument();
            contDocument1.ClipToCut(copyProgress1);
            ChkStstus();
        }

        private void setCopyStartMenu_Click(object sender, EventArgs e)
        {
            contDocument1.SetCopyStart();
            ChkStstus();
        }

        private void cutCutMenu_Click(object sender, EventArgs e)
        {
            if (contDocument1.Locked == true) return;
            memoAndWords1.ToContDocument();
            contDocument1.CutToClip(true);
            ChkStstus();
        }


       

 		//--------------------------------------------------------------------------------


    }
}
