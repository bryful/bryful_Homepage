﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ContEditorNazoh
{
    public partial class PartInfoForm : Form
    {
		private MainForm mf;
		private ContDocument _ContDocument;
		private int PartCount = 0;
		private TextBox[] tbs = new TextBox[def.PartMaxCount];
        public PartInfoForm(MainForm m)
        {
            InitializeComponent();
			mf = m;
			_ContDocument = mf.ContDocument;
			GetParams();
			PrefLoad();
        }
		//---------------------------------------------------------------------------
		private void PartInfoForm_FormClosed(object sender, FormClosedEventArgs e)
		{
			if (mf != null)
			{
				mf.pif = null;
			}
			PrefSave();
		}
		//---------------------------------------------------------------------------
		public void GetParams()
		{
			if (_ContDocument == null) return;
			PartCount = _ContDocument.PartCount;
			int inter = 18;
			for (int i = 0; i < def.PartMaxCount; i++)
			{
				tbs[i] = new TextBox();
				tbs[i].Name = "tb" + i.ToString();
				tbs[i].Text = "";
				tbs[i].Location = new Point(tbBase.Left, tbBase.Top + inter * i);
				tbs[i].Size = tbBase.Size;
				tbs[i].Font = tbBase.Font;
				tbs[i].TextAlign = tbBase.TextAlign;
				tbs[i].ReadOnly = tbBase.ReadOnly;
				tbs[i].Anchor = tbBase.Anchor;
				tbs[i].BorderStyle = tbBase.BorderStyle;
				if (i < PartCount)
				{
					tbs[i].Visible = true;
				}
				else
				{
					tbs[i].Visible = false;
				}
				panel1.Controls.Add(tbs[i]);
			}


		}
		//---------------------------------------------------------------------------
		private string Zero2(int v)
		{
			if (v <= 0)
			{
				return "00";
			}
			else if (v < 10)
			{
				return "0" + v.ToString();
			}
			else
			{
				return  v.ToString();
			}
		}
		//---------------------------------------------------------------------------
		public void DispInfo()
		{
			if (_ContDocument == null) return;
			tbTotal.Text = "総秒数:" + _ContDocument.SecKoma + " 総カット数:" + _ContDocument.CutCount.ToString();
			if (_ContDocument.PartCount != PartCount)
			{
				PartCount = _ContDocument.PartCount;
				for (int i = 0; i < def.PartMaxCount; i++)
				{
					if (i < PartCount)
					{
						tbs[i].Visible = true;
					}
					else
					{
						tbs[i].Visible = false;
					}
				}

			}
			for (int i = 0; i < PartCount; i++)
			{
				string s = Zero2(i + 1) +" [";
				s += _ContDocument.GetPartCaptions(i) +"] ";
				s += "カット数:" + _ContDocument.GetPartCount(i) +" ";
				s += "秒数:" + _ContDocument.GetPartDuration(i);
				tbs[i].Text = s;
			}
		}
		//---------------------------------------------------
		private void PrefSave()
		{
			string p = Path.ChangeExtension(Application.ExecutablePath, def.NazPrefPartExt);
			SaveFiles sv = new SaveFiles(def.PrefHeader);
			sv.SetInt("Left", this.Left);
			sv.SetInt("Top", this.Top);
			sv.SetInt("Width", this.Width);
			sv.SetInt("Height", this.Height);
			sv.SaveToFile(p);
		}
		//---------------------------------------------------------------------------
		public void PrefLoad()
		{
			string p = Path.ChangeExtension(Application.ExecutablePath, def.NazPrefPartExt);
			SaveFiles sv = new SaveFiles(def.PrefHeader);
			sv.LoadFromFile(p);
			int l = sv.GetInt("Left", -1);
			int t = sv.GetInt("Top", -1);
			int w = sv.GetInt("Width", -1);
			int h = sv.GetInt("Height", -1);
			if ((l == -1) || (t == -1) || (w == -1) || (h == -1))
			{
				this.StartPosition = FormStartPosition.CenterScreen;
			}
			else
			{
				this.StartPosition = FormStartPosition.Manual;
				this.Left = l;
				this.Top = t;
				this.Width = w;
				this.Height = h;
			}
		}

	}
}
