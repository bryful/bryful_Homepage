﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace ContEditorNazoh
{
    public class CutSec : Control
    {
        private ContDocument _ContDocument;
        private int _Index = -1;


        private StringFormat format = new StringFormat();
        public CutSec()
        {
            //ダブルバッファー表示
            this.SetStyle(ControlStyles.DoubleBuffer, true);
            this.SetStyle(ControlStyles.UserPaint, true);
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);

            this.SuspendLayout();
            this.SetStyle(ControlStyles.SupportsTransparentBackColor, true);
            this.BackColor = Color.Transparent;

            this.Width = def.PreviewSecWidthP;
            this.Height = def.PreviewKomaHeightP * def.KomaCount;
            this.MaximumSize = new Size(this.Width, this.Height);
            this.MinimumSize = new Size(this.Width, this.Height);

            format.Alignment = StringAlignment.Far;
            format.LineAlignment = StringAlignment.Far;

            this.ResumeLayout();
        }
        //----------------------------------------------------------------
        private void contDocument_DispChanged(object sender, EventArgs e)
        {
            this.Invalidate();
        }
        //-------------------------------------------------------------------------
        protected override void OnPaint(PaintEventArgs e)
        {
			_Index = _ContDocument.CurrentPage * def.KomaCount;
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.PageUnit = GraphicsUnit.Pixel;
            SolidBrush sb = new SolidBrush(Color.Transparent);
            Pen p = new Pen(Color.Black);
            try
            {
                g.FillRectangle(sb, new Rectangle(0, 0, this.Width, this.Height));

                if (_ContDocument != null)
                {
                    for (int i = 0; i < def.KomaCount; i++)
                    {
                        DrawSec(g, sb, p, i);
                    }
                }

            }
            finally
            {
                sb.Dispose();
                p.Dispose();
            }
        }
        //-------------------------------------------------------------------------
        private void DrawSec(Graphics g, SolidBrush sb, Pen p, int idx)
        {
            float pw = p.Width;
            Color c = sb.Color;
            int x0 = 0;
            int x1 = this.Width - 1;
            int y0 = idx * def.PreviewKomaHeightP;
            int y1 = y0 + def.PreviewKomaHeightP - 1;

            g.DrawLine(p, x0, y0, x1, y0);
            g.DrawLine(p, x0, y0, x0, y1);
            g.DrawLine(p, x1, y0, x1, y1);
            p.Width = 1;
            if (idx == def.KomaCount - 1)
            {
                g.DrawLine(p, x0, y1, x1, y1);
            }
            int ii = _Index + idx;
            KomaInfo ki = _ContDocument.GetItem(ii);
            if (ki != null)
            {
                if (ki.Empty == true)
                {
                    g.DrawLine(p, x0, y0, x1, y1);
                    g.DrawLine(p, x0, y1, x1, y0);
                }
                else
                {
                    Rectangle rct = new Rectangle(x0 + 5, y0 + 5, this.Width - 10, def.PreviewKomaHeightP - 10);
                    sb.Color = Color.Black;
                    if ((ki.Empty == true) || (ki.IsNoneNumber == true))
                    {
                    }
                    else
                    {
						string b = "";
						if ((ki.IsContinued == true) || (ki.IsContinuedNext == true))
						{
							b = _ContDocument.DispKomaSec(ii);
							if (b != string.Empty)
							{
								format.LineAlignment = StringAlignment.Center;
								g.DrawString(b, this.Font, sb, rct, format);
							}
						}
                        b = _ContDocument.DispCutSec(ii);
                        if (b != string.Empty)
                        {
                            format.Alignment = StringAlignment.Far;
                            format.LineAlignment = StringAlignment.Far;
                            g.DrawString(b, this.Font, sb, rct, format);
                        }
                    }
                }
                if (_ContDocument.SelectedPageIndex == idx)
                {
                    p.Width = 2;
                    x0 += 2;
                    y0 += 2;
                    g.DrawRectangle(p, new Rectangle(x0, y0, this.Width - 4, def.PreviewKomaHeightP - 3));

                }
                if (ki.IsPageBreak == true)
                {
                    p.Width = 4;
                    x0 = 1;
                    x1 = this.Width - 1;
                    y1 = (idx + 1) * def.PreviewKomaHeightP - 2;
                    g.DrawLine(p, x0, y1, x1, y1);

                }
            }
            p.Width = pw;
            sb.Color = c;



        }
        //***********************************************************
        /*
         * プロパティ
         */
        //***********************************************************
        public ContDocument ContDocument
        {
            get { return _ContDocument; }
            set
            {
                _Index = -1;
                _ContDocument = value;
                if (_ContDocument != null)
                {
                    _Index = _ContDocument.CurrentPage * def.KomaCount;
                    _ContDocument.SelectedIndexChanged += new EventHandler(contDocument_DispChanged);
                    _ContDocument.komaChanged += new EventHandler(contDocument_DispChanged);
				}
            }
        }
        //-------------------------------------------------------------------------
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (_ContDocument != null)
            {
                int v = (e.Y / def.PreviewKomaHeightP) + _Index;
                if (_ContDocument.SelectedIndex != v)
                {
                    _ContDocument.SelectedIndex = v;
                    //this.Invalidate();
                }
                
            }

        }
    }
}
