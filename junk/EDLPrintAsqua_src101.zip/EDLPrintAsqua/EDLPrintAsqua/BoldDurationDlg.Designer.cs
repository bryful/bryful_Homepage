﻿namespace EDLPrintAsqua
{
	partial class BoldDurationDlg
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
            this.rb_1_2 = new System.Windows.Forms.RadioButton();
            this.rb_1_3 = new System.Windows.Forms.RadioButton();
            this.rb_2_3 = new System.Windows.Forms.RadioButton();
            this.rb1Sec = new System.Windows.Forms.RadioButton();
            this.rbCust = new System.Windows.Forms.RadioButton();
            this.tbSec = new System.Windows.Forms.NumericUpDown();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbFrameRate = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbKoma = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.tbSec)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbKoma)).BeginInit();
            this.SuspendLayout();
            // 
            // rb_1_2
            // 
            this.rb_1_2.AutoSize = true;
            this.rb_1_2.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.rb_1_2.Location = new System.Drawing.Point(26, 54);
            this.rb_1_2.Name = "rb_1_2";
            this.rb_1_2.Size = new System.Drawing.Size(231, 16);
            this.rb_1_2.TabIndex = 2;
            this.rb_1_2.TabStop = true;
            this.rb_1_2.Tag = "1";
            this.rb_1_2.Text = "1/2秒　(12コマ:24fps / 15コマ:30fps)";
            this.rb_1_2.UseVisualStyleBackColor = true;
            this.rb_1_2.CheckedChanged += new System.EventHandler(this.rb_1_3_CheckedChanged);
            this.rb_1_2.VisibleChanged += new System.EventHandler(this.rbCust_VisibleChanged);
            // 
            // rb_1_3
            // 
            this.rb_1_3.AutoSize = true;
            this.rb_1_3.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.rb_1_3.Location = new System.Drawing.Point(26, 30);
            this.rb_1_3.Name = "rb_1_3";
            this.rb_1_3.Size = new System.Drawing.Size(224, 16);
            this.rb_1_3.TabIndex = 3;
            this.rb_1_3.TabStop = true;
            this.rb_1_3.Tag = "0";
            this.rb_1_3.Text = "1/3秒　(8コマ:24fps / 10コマ:30fps)";
            this.rb_1_3.UseVisualStyleBackColor = true;
            this.rb_1_3.CheckedChanged += new System.EventHandler(this.rb_1_3_CheckedChanged);
            this.rb_1_3.VisibleChanged += new System.EventHandler(this.rbCust_VisibleChanged);
            // 
            // rb_2_3
            // 
            this.rb_2_3.AutoSize = true;
            this.rb_2_3.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.rb_2_3.Location = new System.Drawing.Point(26, 78);
            this.rb_2_3.Name = "rb_2_3";
            this.rb_2_3.Size = new System.Drawing.Size(231, 16);
            this.rb_2_3.TabIndex = 4;
            this.rb_2_3.TabStop = true;
            this.rb_2_3.Tag = "2";
            this.rb_2_3.Text = "2/3秒　(16コマ:24fps / 20コマ:30fps)";
            this.rb_2_3.UseVisualStyleBackColor = true;
            this.rb_2_3.CheckedChanged += new System.EventHandler(this.rb_1_3_CheckedChanged);
            this.rb_2_3.VisibleChanged += new System.EventHandler(this.rbCust_VisibleChanged);
            // 
            // rb1Sec
            // 
            this.rb1Sec.AutoSize = true;
            this.rb1Sec.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.rb1Sec.Location = new System.Drawing.Point(26, 102);
            this.rb1Sec.Name = "rb1Sec";
            this.rb1Sec.Size = new System.Drawing.Size(227, 16);
            this.rb1Sec.TabIndex = 5;
            this.rb1Sec.TabStop = true;
            this.rb1Sec.Tag = "3";
            this.rb1Sec.Text = "  1秒　(24コマ:24fps / 30コマ:30fps)";
            this.rb1Sec.UseVisualStyleBackColor = true;
            this.rb1Sec.CheckedChanged += new System.EventHandler(this.rb_1_3_CheckedChanged);
            this.rb1Sec.VisibleChanged += new System.EventHandler(this.rbCust_VisibleChanged);
            // 
            // rbCust
            // 
            this.rbCust.AutoSize = true;
            this.rbCust.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.rbCust.Location = new System.Drawing.Point(26, 130);
            this.rbCust.Name = "rbCust";
            this.rbCust.Size = new System.Drawing.Size(63, 16);
            this.rbCust.TabIndex = 6;
            this.rbCust.TabStop = true;
            this.rbCust.Tag = "4";
            this.rbCust.Text = "カスタム";
            this.rbCust.UseVisualStyleBackColor = true;
            this.rbCust.CheckedChanged += new System.EventHandler(this.rb_1_3_CheckedChanged);
            this.rbCust.VisibleChanged += new System.EventHandler(this.rbCust_VisibleChanged);
            // 
            // tbSec
            // 
            this.tbSec.Enabled = false;
            this.tbSec.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbSec.Location = new System.Drawing.Point(96, 126);
            this.tbSec.Name = "tbSec";
            this.tbSec.Size = new System.Drawing.Size(60, 23);
            this.tbSec.TabIndex = 7;
            this.tbSec.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tbSec.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbFrameRate);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tbKoma);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.tbSec);
            this.groupBox1.Controls.Add(this.rb_1_3);
            this.groupBox1.Controls.Add(this.rbCust);
            this.groupBox1.Controls.Add(this.rb_1_2);
            this.groupBox1.Controls.Add(this.rb1Sec);
            this.groupBox1.Controls.Add(this.rb_2_3);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(281, 189);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ボールドの秒数";
            // 
            // tbFrameRate
            // 
            this.tbFrameRate.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbFrameRate.Location = new System.Drawing.Point(26, 156);
            this.tbFrameRate.Name = "tbFrameRate";
            this.tbFrameRate.ReadOnly = true;
            this.tbFrameRate.Size = new System.Drawing.Size(224, 19);
            this.tbFrameRate.TabIndex = 11;
            this.tbFrameRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label2.Location = new System.Drawing.Point(236, 132);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 12);
            this.label2.TabIndex = 10;
            this.label2.Text = "コマ";
            // 
            // tbKoma
            // 
            this.tbKoma.Enabled = false;
            this.tbKoma.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbKoma.Location = new System.Drawing.Point(186, 126);
            this.tbKoma.Name = "tbKoma";
            this.tbKoma.Size = new System.Drawing.Size(44, 23);
            this.tbKoma.TabIndex = 9;
            this.tbKoma.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label1.Location = new System.Drawing.Point(162, 132);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 12);
            this.label1.TabIndex = 8;
            this.label1.Text = "秒";
            // 
            // btnOK
            // 
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnOK.Location = new System.Drawing.Point(116, 216);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 9;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancel.Location = new System.Drawing.Point(208, 216);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // BoldDurationDlg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(306, 255);
            this.ControlBox = false;
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "BoldDurationDlg";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "ボールドの秒数";
            ((System.ComponentModel.ISupportInitialize)(this.tbSec)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbKoma)).EndInit();
            this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.RadioButton rb_1_2;
		private System.Windows.Forms.RadioButton rb_1_3;
		private System.Windows.Forms.RadioButton rb_2_3;
		private System.Windows.Forms.RadioButton rb1Sec;
		private System.Windows.Forms.RadioButton rbCust;
		private System.Windows.Forms.NumericUpDown tbSec;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TextBox tbFrameRate;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.NumericUpDown tbKoma;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
	}
}