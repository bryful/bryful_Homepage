﻿namespace EDLPrintAsqua
{
	partial class TimecodeEdit
	{
		/// <summary> 
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region コンポーネント デザイナーで生成されたコード

		/// <summary> 
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を 
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
            this.tbH = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbM = new System.Windows.Forms.TextBox();
            this.tbS = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbF = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tbH
            // 
            this.tbH.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbH.Location = new System.Drawing.Point(1, 0);
            this.tbH.Name = "tbH";
            this.tbH.Size = new System.Drawing.Size(24, 23);
            this.tbH.TabIndex = 0;
            this.tbH.Tag = "0";
            this.tbH.Text = "00";
            this.tbH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbH.TextChanged += new System.EventHandler(this.tbH_TextChanged);
            this.tbH.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbH_KeyPress);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label1.Location = new System.Drawing.Point(27, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(9, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "：";
            // 
            // tbM
            // 
            this.tbM.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbM.Location = new System.Drawing.Point(42, 0);
            this.tbM.Name = "tbM";
            this.tbM.Size = new System.Drawing.Size(24, 23);
            this.tbM.TabIndex = 2;
            this.tbM.Tag = "1";
            this.tbM.Text = "00";
            this.tbM.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbM.TextChanged += new System.EventHandler(this.tbH_TextChanged);
            this.tbM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbH_KeyPress);
            // 
            // tbS
            // 
            this.tbS.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbS.Location = new System.Drawing.Point(84, 0);
            this.tbS.Name = "tbS";
            this.tbS.Size = new System.Drawing.Size(24, 23);
            this.tbS.TabIndex = 4;
            this.tbS.Tag = "2";
            this.tbS.Text = "00";
            this.tbS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbS.TextChanged += new System.EventHandler(this.tbH_TextChanged);
            this.tbS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbH_KeyPress);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label2.Location = new System.Drawing.Point(69, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(9, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "：";
            // 
            // tbF
            // 
            this.tbF.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbF.Location = new System.Drawing.Point(126, 0);
            this.tbF.Name = "tbF";
            this.tbF.Size = new System.Drawing.Size(24, 23);
            this.tbF.TabIndex = 6;
            this.tbF.Tag = "3";
            this.tbF.Text = "00";
            this.tbF.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbF.TextChanged += new System.EventHandler(this.tbH_TextChanged);
            this.tbF.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbH_KeyPress);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label3.Location = new System.Drawing.Point(111, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(9, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "：";
            // 
            // TimecodeEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tbF);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbS);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbM);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbH);
            this.Name = "TimecodeEdit";
            this.Size = new System.Drawing.Size(152, 26);
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox tbH;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox tbM;
		private System.Windows.Forms.TextBox tbS;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox tbF;
		private System.Windows.Forms.Label label3;
	}
}
