﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EDLPrintAsqua
{
    public partial class FrameRateDlg : Form
    {
        public FrameRateDlg(FrameRates fps)
        {
            InitializeComponent();
            FrameRate = fps;
        }
        public FrameRates FrameRate
        {
            get
            {
                if (rb24.Checked == true)
                {
                    return FrameRates.fr24;
                }
                else
                {
                    return FrameRates.fr30;
                }

            }
            set
            {
                rb24.Checked = rb30.Checked = false;
                switch (value)
                {
                    case FrameRates.fr24: rb24.Checked = true; break;
                    case FrameRates.fr30: rb30.Checked = true; break;
                }
            }
        }
    }
}
