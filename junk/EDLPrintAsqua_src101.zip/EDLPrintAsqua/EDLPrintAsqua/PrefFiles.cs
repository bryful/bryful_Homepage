﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace EDLPrintAsqua
{
    public enum PrefID
    {
        left = 0,
        top,
        width,
        height,

        defFps,
        defBold,
        isPrintClipExt,
        isPrintInfo,
        isClearText,
        PrintScaler,

        Title,
        Memo1,
        Memo2,
        Date,
        Campany,
        ClearText,
 
        Count
    }
    public class PrefFiles
    {
        public string header = Properties.Resources.AppName + " His";

        private int _Left = -1;
        private int _Top = -1;
        private int _Width = 0;
        private int _Height = 0;

        private FrameRates _FrameRate = FrameRates.fr24;
        private double _BoldDuration = E.defBoldDuration;
        private bool _IsPrintClipExt = true;
        private bool _IsPrintInfo = true;
        private int _PrintScaler = 100;
        private bool _IsClearText = false;

        public string[] PrefIDstr = new string[(int)PrefID.Count]
        {
            "*left",
            "*top",
            "*width",
            "*height",

            "*defFps",
            "*defBold",
            "*isPrintClipExt",
            "*isPrintInfo",
            "*isClearText",
            "*PrintScaler",

            "*Title",
            "*Memo1",
            "*Memo2",
            "*Date",
            "*Campany",
            "*ClearText"
        };
        private AsquaForm afrm;
        //-----------------------------
        public PrefFiles(AsquaForm af)
        {
          
            afrm = af;
        }
        //-----------------------------
        public string GetCompItems(ComboBox cmb, PrefID id)
        {
            string ret = PrefIDstr[(int)id] +"\n";

            if (cmb.Text != string.Empty)
            {
                ret += "\t" + cmb.Text + "\n";
            }

            int cnt = cmb.Items.Count;
            if ( cnt <= 0) return ret;

            for (int i = 0; i < cnt; i++)
            {
                string s = cmb.Items[i].ToString().Trim();
                if (s != string.Empty)
                {
                    ret += s +"\n";
                 }
            }
            return ret;
        }
        //-----------------------------
        private string HisTag(PrefID id)
        {
            return PrefIDstr[(int)id];
        }
        //-----------------------------
        public void Save()
        {
            string p = System.IO.Path.ChangeExtension(Application.ExecutablePath, ".pref");
            Save(p);
        }
        //-----------------------------
        public void Save(string path)
        {
            if (afrm == null) return;
            string s = header + "\n";
            s += HisTag(PrefID.left) +"\n";
            s += afrm.Left.ToString() + "\n";

            s += HisTag(PrefID.top) + "\n";
            s += afrm.Top.ToString() + "\n";

            s += HisTag(PrefID.width) + "\n";
            s += afrm.Width.ToString() + "\n";

            s += HisTag(PrefID.height) + "\n";
            s += afrm.Height.ToString() + "\n";

            s += HisTag(PrefID.defFps) + "\n";
            s += ((int)afrm.FrameRate).ToString() + "\n";
            s += HisTag(PrefID.defBold) + "\n";
            s += ((double)afrm.BoldDuration).ToString() + "\n";
            s += HisTag(PrefID.isPrintClipExt) + "\n";
            s += (afrm.IsPrintClipExt).ToString() + "\n";
            s += HisTag(PrefID.isPrintInfo) + "\n";
            s += (afrm.IsPrintInfo).ToString() + "\n";
            s += HisTag(PrefID.isClearText) + "\n";
            s += (afrm.IsClearText).ToString() + "\n";

            s += HisTag(PrefID.PrintScaler) + "\n";
            s += (afrm.PrintScaler).ToString() + "\n";



            s += GetCompItems(afrm.RecTitle, PrefID.Title);
            s += GetCompItems(afrm.RecMemo1st, PrefID.Memo1);
            s += GetCompItems(afrm.RecMemo2nd, PrefID.Memo2);
            s += GetCompItems(afrm.RecDate, PrefID.Date);
            s += GetCompItems(afrm.RecCampany, PrefID.Campany);
            s += GetCompItems(afrm.ClearText, PrefID.ClearText);
            try
            {
                File.WriteAllText(path, s, Encoding.GetEncoding("utf-8"));
            }
            catch
            {
                return;
            }
        }
        //---------------------------------------------------------------------
        private int FindTag(string [] lines,PrefID id)
        {
            int ret = -2;
            int cnt = lines.Length;
            if (cnt <= 0) return ret;

            string tagS = HisTag(id);
            for (int i = 1; i < cnt; i++)
            {
                if (string.Compare(lines[i].Trim(), tagS, true) == 0)
                {
                    if (i != cnt - 1) return i; 
                }
            }

            return ret;
        }
        //---------------------------------------------------------------------
        private int toInt(string [] lines ,int idx , int def)
        {
            int ret = def;
            if ((idx <= 0) || (idx >= lines.Length)) return ret;
            int tmp = 0;
            if (int.TryParse(lines[idx], out tmp) == true) ret = tmp;
            return ret;
        }
        //---------------------------------------------------------------------
        private double toDouble(string[] lines, int idx, double def)
        {
            double ret = def;
            if ((idx <= 0) || (idx >= lines.Length)) return ret;
            double tmp = 0;
            if (double.TryParse(lines[idx], out tmp) == true) ret = tmp;
            return ret;
        }
        //---------------------------------------------------------------------
        private bool toBool(string[] lines, int idx, bool def)
        {
            bool ret = def;
            if ((idx <= 0) || (idx >= lines.Length)) return ret;
            bool tmp = false;
            if (bool.TryParse(lines[idx], out tmp) == true) ret = tmp;
            return ret;
        }
        //---------------------------------------------------------------------
        private void AddComb(ComboBox cmb, string s)
        {
            string ss = s.Trim();
            if ( ss == string.Empty) return;

            if (cmb.Items.Count <= 0)
            {
                for (int i = 0; i < cmb.Items.Count; i++)
                {
                    if (cmb.Items[i].ToString() == ss) return;
                }
                cmb.Items.Add(ss);
            }
        }
        //---------------------------------------------------------------------
        private void toComb(string[] lines, int idx,ComboBox cmb)
        {
            if (cmb == null) return;
            if ((idx <= 0) || (idx >= lines.Length)) return;

            int i = idx;
            int cnt = lines.Length;
            while (i < cnt)
            {
                string s = lines[i];
                if (s != "")
                {
                    if (s[0] == '*') return;
                    if (s[0] == '\t')
                    {
                        cmb.Text = s.Trim();
                    }
                    else
                    {
                        AddComb(cmb,s);
                    }

                }
                i++;
            }

        }
		//-----------------------------
		public void Load()
		{
			string p = System.IO.Path.ChangeExtension(Application.ExecutablePath, ".pref");
			Load(p);
		}      
		//---------------------------------------------------------------------
        public void Load(string path)
        {
			if (afrm == null) return;
            if (File.Exists(path) == false) { return; }

            try
            {
                string[] rd = System.IO.File.ReadAllLines(path, Encoding.GetEncoding("utf-8"));
                int cnt = rd.Length;
                if (cnt <= 1) return;
                if (string.Compare(header, rd[0].Trim()) != 0) return;

                _Left = toInt(rd, FindTag(rd, PrefID.left) + 1, 100);
                _Top = toInt(rd, FindTag(rd, PrefID.top) + 1, 100);
                _Width = toInt(rd, FindTag(rd, PrefID.width) + 1, 755);
                _Height = toInt(rd, FindTag(rd, PrefID.height) + 1, 699);

				if ((_Width != afrm.Width) || (_Height != afrm.Height))
				{
					afrm.Width = _Width;
					afrm.Height = _Height;
				}
				afrm.Left = _Left;
				afrm.Top = _Top;


                _FrameRate = (FrameRates)toInt(rd, FindTag(rd, PrefID.defFps) + 1, (int)FrameRates.fr24);
                _BoldDuration = toDouble(rd, FindTag(rd, PrefID.defBold) + 1, 8 / 24);
                _IsPrintClipExt = toBool(rd, FindTag(rd, PrefID.isPrintClipExt) + 1, true);
                _IsPrintInfo = toBool(rd, FindTag(rd, PrefID.isPrintInfo) + 1, true);
                _PrintScaler = toInt(rd, FindTag(rd, PrefID.PrintScaler) + 1, 100);
                _IsClearText = toBool(rd, FindTag(rd, PrefID.isClearText) + 1, false);
 

				if (afrm.FrameRate != _FrameRate) afrm.FrameRate = _FrameRate;
				if (afrm.BoldDuration != _BoldDuration) afrm.BoldDuration = _BoldDuration;
				if (afrm.IsPrintClipExt != _IsPrintClipExt) afrm.IsPrintClipExt = _IsPrintClipExt;
				if (afrm.IsPrintInfo != _IsPrintInfo) afrm.IsPrintInfo = _IsPrintInfo;
                if (afrm.PrintScaler != _PrintScaler) afrm.PrintScaler = _PrintScaler;
                if (afrm.IsClearText != _IsClearText) afrm.IsClearText = _IsClearText;


                toComb(rd, FindTag(rd, PrefID.Title) + 1, afrm.RecTitle);
                toComb(rd, FindTag(rd, PrefID.Memo1) + 1, afrm.RecMemo1st);
                toComb(rd, FindTag(rd, PrefID.Memo2) + 1, afrm.RecMemo2nd);
                toComb(rd, FindTag(rd, PrefID.Date) + 1, afrm.RecDate);
                toComb(rd, FindTag(rd, PrefID.Campany) + 1, afrm.RecCampany);
                toComb(rd, FindTag(rd, PrefID.ClearText) + 1, afrm.ClearText);
            }
            catch
            {
                return;
            }
        }
        //---------------------------------------------------------------------
        public int Left
        {
            get { return _Left; }
        }
        //---------------------------------------------------------------------
        public int Top
        {
            get { return _Top; }
        }
        //---------------------------------------------------------------------
        public int Width
        {
            get { return _Width; }
        }
        //---------------------------------------------------------------------
        public FrameRates FrameRate
        {
            get { return _FrameRate; }
        }
        //---------------------------------------------------------------------
        public double BoldDuration
        {
            get { return _BoldDuration; }
        }
        //---------------------------------------------------------------------
        public bool IsPrintClipExt
        {
            get { return _IsPrintClipExt; }
        }
        //---------------------------------------------------------------------
        public bool IsPrintInfo
        {
            get { return _IsPrintInfo; }
        }
        //---------------------------------------------------------------------
    }
}
