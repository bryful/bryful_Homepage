﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EDLPrintAsqua
{
	//****************************************************
	public enum FrameRates
	{
		fr24 = 24,
		fr30 = 30
	}
	//****************************************************
	public class Timecode
	{
		//------------------------------------------------
		private int hour = 0;
		private int min = 0;
		private int sec = 0;
		private int frame = 0;
		public FrameRates FrameRate = FrameRates.fr24;

		private bool _codeError = false;
		//------------------------------------------------
		public Timecode(FrameRates fr)
		{
			FrameRate = fr;
			_codeError = false;
		}
		//------------------------------------------------
		public void Clear()
		{
			hour = min = sec = frame = 0;
			_codeError = false;
		}
		//------------------------------------------------
		public void Assign(Timecode tc)
		{
			hour = tc.hour;
			min = tc.min;
			sec = tc.sec;
			frame = tc.frame;
			FrameRate = tc.FrameRate;
		}
		//------------------------------------------------
		private string zero2(int v)
		{
			if (v < 10) { return "0" + v.ToString(); }
			else { return v.ToString(); } 
		}
		//------------------------------------------------
		private string sp2(int v)
		{
			if (v < 10) { return " " + v.ToString(); }
			else { return v.ToString(); }
		}
		//------------------------------------------------
		public int Hour
		{
			get { return hour; }
			set { hour = value; }
		}
		//------------------------------------------------
		public int Min
		{
			get { return min; }
			set { min = value; }
		}
		//------------------------------------------------
		public int Sec
		{
			get { return sec; }
			set { sec = value; }
		}
        //------------------------------------------------
        public long SecALL
        {
            get 
            {
                return (long)(hour * E.HMS * E.HMS +
                       min * E.HMS +
                       sec);
            }
            set 
            {
                long v = value;
                if (v <= 0)
                {
                    hour = min = sec = 0;
                }
                else
                {
                    v = (v / (int)FrameRate);
                    sec = (int)( v % E.HMS);
                    v = v / E.HMS;
                    min = (int)(v % E.HMS);
                    hour = (int)(v / E.HMS);
  
                }
            }
        }
        //------------------------------------------------
		public int Frame
		{
			get { return frame; }
            set { frame = value; }
		}
		//------------------------------------------------
		public bool CodeError
		{
			get { return _codeError; }
		}
		//------------------------------------------------
		public string HourS
		{
			get { return zero2(hour); }
			set
			{
				int v = -1;
				hour = -1;
				_codeError = true;
				if (int.TryParse(value, out v) == true)
				{
					hour = v;
					_codeError = false;
				}
			}
		}
		//------------------------------------------------
		public string MinS
		{
			get { return zero2(min); }
			set
			{
				_codeError = true;
				int v = -1;
				min = -1;
				if (int.TryParse(value, out v) == true)
				{
					min = v;
					_codeError = false;
				}
			}
		}
		//------------------------------------------------
		public string SecS
		{
			get { return zero2(sec); }
			set
			{
				_codeError = true;
				int v = -1;
				sec = -1;
				if (int.TryParse(value, out v) == true)
				{
					_codeError = false;
					sec = v;
				}
			}
		}
		//------------------------------------------------
		public string FrameS
		{
			get { return zero2(frame); }
			set
			{
				int v = -1;
				_codeError = true;
				frame = -1;
				if (int.TryParse(value, out v) == true)
				{
					_codeError = false;
					frame = v;
				}

			}
		}
		//------------------------------------------------
		private long ToToalFrame(int h, int m,int s, int f,FrameRates fps)
		{
			return h * E.HMS * E.HMS * (long)fps +
					m * E.HMS * (long)fps +
					s * (long)fps +
					f;
		}
		//------------------------------------------------
		private double ToToalDuration(int h, int m, int s, int f, FrameRates fps)
		{
			return h * E.HMS * E.HMS +
					m * E.HMS +
					s +
					(double)f / (double)fps;
		}
		//------------------------------------------------
		private void FromTotalFrame(long value, FrameRates fps, ref int h, ref int m, ref int s, ref int f)
		{
			if (value <= 0)
			{
				f = s = m = h = 0;
				return;
			}

			long v = value;
			f = (int)(v % (long)FrameRate);
			v /= (long)FrameRate;
			s = (int)(v % E.HMS);
			v /= E.HMS;
			m = (int)(v % E.HMS);
			h = (int)(v / E.HMS);
		}
		//------------------------------------------------
		private void FromTotalDuration(double value, FrameRates fps, ref int h, ref int m, ref int s, ref int f)
		{
			if (value <= 0)
			{
				f = s = m = h = 0;
				return;
			}

			long v = (long)Math.Round(value * (long)FrameRate);
			f = (int)(v % (long)FrameRate);
			v /= (long)FrameRate;
			s = (int)(v % E.HMS);
			v /= E.HMS;
			m = (int)(v % E.HMS);
			h = (int)(v / E.HMS);
		}
		//------------------------------------------------
		public long TotalFrame
		{
			get { return ToToalFrame(this.hour,this.min,this.sec,this.frame,this.FrameRate); }
			set { FromTotalFrame(value, this.FrameRate, ref hour, ref min, ref sec, ref frame); }
		}
		//------------------------------------------------
		public double TotalDuration
		{
			get { return ToToalDuration(this.hour, this.min, this.sec, this.frame, this.FrameRate); }
			set { FromTotalDuration(value, this.FrameRate, ref hour, ref min, ref sec, ref frame); }
		}
		//------------------------------------------------
		public string Code
		{
			get { return zero2(hour) + E.COLON + zero2(min) + E.COLON + zero2(sec) + E.COLON + zero2(frame); }

			set
			{
				_codeError = true;
				hour = min = sec = frame = -1;
				string[] sa = value.Split(E.COLON);
				if (sa.Length == 4)
				{
					int h = -1;
					int m = -1;
					int s = -1;
					int f = -1;
					int v =0;
					if ( int.TryParse(sa[0],out v) ) h = v; 
					if ( int.TryParse(sa[1],out v) ) m = v; 
					if ( int.TryParse(sa[2],out v) ) s = v; 
					if ( int.TryParse(sa[3],out v) ) f = v;
					if ( (h !=-1)&&(m !=-1)&&(s !=-1)&&(s !=-1) )
					{
						hour = h; min = m; sec = s; frame =f;
 						_codeError = false;
					}
 
				}
			}
		}
		//------------------------------------------------
		public void Add(Timecode tc)
		{
			if (tc.FrameRate == this.FrameRate)
			{
				long o = ToToalFrame(this.hour, this.min, this.sec, this.frame, this.FrameRate);
				long a = ToToalFrame(tc.hour, tc.min, tc.sec, tc.frame, tc.FrameRate);
				FromTotalFrame(o + a, FrameRate, ref hour, ref min, ref sec, ref frame);
			}
			else
			{
				double o = ToToalDuration(this.hour, this.min, this.sec, this.frame, this.FrameRate);
				double a = ToToalDuration(tc.hour, tc.min, tc.sec, tc.frame, tc.FrameRate);
				FromTotalDuration(o + a, FrameRate, ref hour, ref min, ref sec, ref frame);
			}
		}
		//------------------------------------------------
		public void Sub(Timecode tc)
		{
			if (tc.FrameRate == this.FrameRate)
			{
				long o = ToToalFrame(this.hour, this.min, this.sec, this.frame, this.FrameRate);
				long a = ToToalFrame(tc.hour, tc.min, tc.sec, tc.frame, tc.FrameRate);
				FromTotalFrame(o - a, FrameRate, ref hour, ref min, ref sec, ref frame);
			}
			else
			{
				double o = ToToalDuration(this.hour, this.min, this.sec, this.frame, this.FrameRate);
				double a = ToToalDuration(tc.hour, tc.min, tc.sec, tc.frame, tc.FrameRate);
				FromTotalDuration(o - a, FrameRate, ref hour, ref min, ref sec, ref frame);
			}
		}
		//------------------------------------------------
		public int Compare(Timecode s, Timecode d)
		{
			double ss = ToToalDuration(s.hour, s.min, s.sec, s.frame, s.FrameRate);
			double dd = ToToalDuration(d.hour, d.min, d.sec, d.frame, d.FrameRate);
			if (ss == dd) { return 0; }
			else if (ss < dd) { return -1; }
			else { return 1; }
		}
		//------------------------------------------------
        public string SecFrame
        {
            get
            {
                return sp2((int)SecALL) + "+" + FrameS;
            }
        }
        //------------------------------------------------

	}
}
