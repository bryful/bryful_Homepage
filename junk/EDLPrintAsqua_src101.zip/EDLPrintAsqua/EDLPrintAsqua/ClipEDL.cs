﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EDLPrintAsqua
{
	public enum ClipStatus
	{
		None = 0,
		Mov,
		MoveWithBold,
		Still,
		CutBold,
		RollBold,
		Count
	}
	public class ClipEDL
    {
        //-------------------------------------
		public string _ClipName = "";
        private int _num = 0;
		public Timecode ClipIn = new Timecode(FrameRates.fr24);
		public Timecode ClipOut = new Timecode(FrameRates.fr24);
		public Timecode TimeIn = new Timecode(FrameRates.fr24);
		public Timecode TimeOut = new Timecode(FrameRates.fr24);

        private double _BoldDuraton = E.defBoldDuration;

		private ClipStatus _ClipStatus = ClipStatus.None;
		private bool _IsStill = false;

        public ClipStatus DefClipStatusMov = ClipStatus.MoveWithBold;
 
		public string [] ClipStatusStr = new string[(int)ClipStatus.Count] 
		{
			"無効",
			"ボールドなしClip",
			"ボールド付きClip",
			"静止画",
			"ボールド",
			"ロールボールド",
		};

        //-------------------------------------
		public ClipEDL(FrameRates fps)
        {
            FrameRate = fps;
        }
        //-------------------------------------
		public FrameRates FrameRate
		{
			get { return ClipIn.FrameRate; }
			set {
				ClipIn.FrameRate =
				ClipOut.FrameRate =
				TimeIn.FrameRate =
				TimeOut.FrameRate = 
				value;
			}
		}
		//-------------------------------------
		public double BoldDuration
		{
			get { return _BoldDuraton; }
			set { _BoldDuraton = value; }
		}

		//-------------------------------------
		public string ClipName
		{
			get { return _ClipName; }
			set
			{
				_ClipName = value;
			}
		}
		//-------------------------------------
		//プロパティーをコピー
		public void Assign(ClipEDL ce)
		{
			this._ClipName = ce._ClipName;
			this._num = ce._num;
			this.ClipIn.Assign(ce.ClipIn);
			this.ClipOut.Assign(ce.ClipOut);
			this.TimeIn.Assign(ce.TimeIn);
			this.TimeOut.Assign(ce.TimeOut);
			this._ClipStatus = ce._ClipStatus;
            this._IsStill = ce._IsStill;
            this._BoldDuraton = ce._BoldDuraton;
		}
		//-------------------------------------
		public int TCCompare(Timecode s, Timecode d)
		{
			double ss = s.TotalDuration;
			double dd = d.TotalDuration;
			if (ss == dd) { return 0; }
			else if (ss > dd) { return 1; }
			else { return -1; }
		}
		//-------------------------------------
		private string zero3(int v)
		{
			if (v < 10) { return "00" + v.ToString(); }
			else if (v < 100) { return "0" + v.ToString(); }
			else  { return  v.ToString(); }
		}
		//-------------------------------------
        public int Num
        {
            get { return _num; }
            set 
            {
                if (value <= 0) { _num = -1; }
                else { _num = value; } 
            }
        }
        //-------------------------------------
        public string NumS
        {
            get { return zero3(_num); }
            set 
            {
                int v = -1;
				if ( int.TryParse(value, out v) ==true)
				{
					_num = v;
				}
				else
				{
					Num = -1;
				}
            }
        }
		//-------------------------------------
		public ClipStatus ClipStatus
		{
			get { return _ClipStatus; }
			set
			{
				if (_IsStill == true)
				{
					switch (value)
					{
						case EDLPrintAsqua.ClipStatus.CutBold:
						case EDLPrintAsqua.ClipStatus.RollBold:
						case EDLPrintAsqua.ClipStatus.Still:
							_ClipStatus = value;
							break;
					}
				}
				else
				{
					switch (value)
					{
						case EDLPrintAsqua.ClipStatus.Mov:
						case EDLPrintAsqua.ClipStatus.MoveWithBold:
							_ClipStatus = value;
							break;
					}
				}

			}
		}
		//-------------------------------------
		public string ClipStatusInfo
		{
			get { return ClipStatusStr[(int)_ClipStatus]; }
		}
		//-------------------------------------
		public void SetClipStatus(ClipStatus s)
		{
			_ClipStatus = s;
		}
		//-------------------------------------
		public bool IsStill
		{
			get { return _IsStill; }
		}
		//-------------------------------------
		public void SetIsStill(bool b)
		{
			_IsStill = b;
		}
        //-------------------------------------
        private string GetExt(string s)
        {
            int idx = -1;
            if ( s== string.Empty) return "";
            for (int i = s.Length - 1; i >= 0; i--)
            {
                if (s[i] == '.')
                {
                    idx = i;
                    break;
                }
            }
            if (idx < 0) return "";
            return s.Substring(idx);
        }
        //-------------------------------------
        public void ChkIsStill()
		{
			string e = GetExt(_ClipName).ToLower();


            _IsStill = (!((e == ".qt") || (e == ".mov") || (e == ".avi") || (e == ".mpg") || (e == ".mpeg") || (e == ".vob")));

            if (_IsStill == true)
            {
                if (ClipIn.TotalDuration == 0) _IsStill = false;
            }

			if (_IsStill)
			{
				_ClipStatus = ClipStatus.CutBold;
			}
			else
			{
				_ClipStatus = DefClipStatusMov;
			}

		}
		
		//-------------------------------------
		public int ClipFrameWithoutBold
		{
			get
			{
				Timecode t = new Timecode(FrameRate);
				t.Assign(TimeOut);
				t.Sub(TimeIn);
				if (_ClipStatus == ClipStatus.MoveWithBold)
				{
					return (int)(t.TotalFrame - BoldFrame);
				}else{
					return (int)(t.TotalFrame);
				}
			}
		}
		//-------------------------------------
		public int ClipFrame
		{
			get
			{
				Timecode t = new Timecode(FrameRate);
				t.Assign(TimeOut);
				t.Sub(TimeIn);
				return (int)(t.TotalFrame);
			}
		}
		//-------------------------------------
		public double ClipDuration
		{
			get
			{
				Timecode t = new Timecode(FrameRate);
				t.Assign(TimeOut);
				t.Sub(TimeIn);
				return (double)(t.TotalDuration);
			}
		}
		//-------------------------------------
		public int BoldFrame
		{
			get
			{
				if (_ClipStatus == ClipStatus.MoveWithBold)
				{
					return (int)Math.Round(_BoldDuraton * (double)FrameRate);
				}
				else
				{
					return 0;
				}
			}
            set { _BoldDuraton = (double)value / (double)FrameRate; }
		}
		
		//-------------------------------------

    }
    //-------------------------------------
}
