﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EDLPrintAsqua
{
	public class ClipKYP
	{
		public string ClipName = "";
		private double _inPoint = 0;
		private double _BoldDuration = 0;
		private double _Duration = 0;
        public string Comment = "";
		private FrameRates _FrameRate = FrameRates.fr24;
		//************************************************************
		public ClipKYP()
		{
            _FrameRate = FrameRates.fr24;
		}
        //************************************************************
        public ClipKYP(FrameRates fps)
        {
            _FrameRate = fps;
        }
        //************************************************************
        public FrameRates FrameRate
        {
            get { return _FrameRate; }
            set { _FrameRate = value; }
        }
        //************************************************************
		public ClipKYP(FrameRates fps,double bl, double d)
		{
			_FrameRate = fps;
			_BoldDuration = bl;
			_Duration = d;
		}
		//************************************************************
		public void SetInPoint(Timecode t)
		{
			_inPoint = t.TotalDuration;
		}
		//************************************************************
		public double inPointDuration
		{
			get { return _inPoint; }
			set { _inPoint = value; }
		}
		//************************************************************
		public Timecode inPoint
		{
			get
			{
                Timecode tc = new Timecode(_FrameRate);
				tc.TotalDuration = _inPoint;
				return tc;
			}
			set 
			{
                Timecode tc = new Timecode(_FrameRate);
                tc.Assign(value);
				_inPoint = tc.TotalDuration; 
			}
		}
       
		//************************************************************
		public double outPointDuration
		{
			get { return _inPoint + Duration + BoldDuration; }
		}
		//************************************************************
		public Timecode outPoint
		{
			get 
			{
                Timecode tc = new Timecode(_FrameRate);
                tc.TotalDuration = _inPoint + Duration + BoldDuration;
				return tc; 
			}
		}
		
		//************************************************************
		public double BoldOutPointDuration
		{
			get
			{
				return _inPoint + BoldDuration;
			}
		}
		//************************************************************
		public Timecode BoldOutPoint
		{
			get
			{
                Timecode tc = new Timecode(_FrameRate);
                tc.TotalDuration = _inPoint + BoldDuration;
				return tc;
			}
		}
		//************************************************************
        public bool WithBold
        {
            get { return ( ( _Duration != 0)&&(_BoldDuration>0)); }
        }
        //************************************************************
        public double BoldDuration
		{
			get{return _BoldDuration;}
			set { _BoldDuration = value; }
		}
		//************************************************************
		public double Duration
		{
			get{return _Duration;}
			set { _Duration = value; }
		}
        //************************************************************
		public double TotalDuration
		{
			get{return Duration + BoldDuration;}
		}
		//************************************************************
		public long TotalFrame
		{
			get
			{
                Timecode tc = new Timecode(_FrameRate);
                tc.TotalDuration = Duration + BoldDuration; 
				return tc.TotalFrame;
			}
		}
	
		
        //************************************************************
        public string[] Info
        {
            get
            {
                Timecode tc = new Timecode(_FrameRate);
                string[] s = new string[6];
                //clipname
                s[0] = ClipName;
                //inPoint
                tc.TotalDuration = _inPoint;
                s[1] = tc.Code;
                //boldOutPoint
                if ( ( _Duration != 0)&&(_BoldDuration>0))
                {
                    tc.TotalDuration = _BoldDuration + _inPoint;
                    s[2] = tc.Code;
                }
                else
                {
                    s[2] = "";
                }
                tc.TotalDuration = _Duration + _BoldDuration + _inPoint;
                s[3] = tc.Code;

				if (_Duration != 0)
				{
					tc.TotalDuration = _Duration;
					s[4] = tc.TotalFrame.ToString() + "(" + tc.SecFrame + ")";
				}
				else
				{
					tc.TotalDuration = _BoldDuration;
					s[4] = tc.TotalFrame.ToString() + "(" + tc.SecFrame + ")";
				}

                s[5] = Comment;
                return s;
            }
        }
        //************************************************************
    }
}
