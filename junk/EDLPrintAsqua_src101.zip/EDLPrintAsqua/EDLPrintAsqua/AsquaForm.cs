﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;

using System.Windows.Forms;

namespace EDLPrintAsqua
{
	public partial class AsquaForm : Form
	{
        private DispMode _DispMode = DispMode.EDL;
		public string FilePath = "";
		public EDL edl = new EDL();
		public EDLPrint edp;

		//***************************************************************************
		public AsquaForm()
		{
			InitializeComponent();
			Clear();
            cmbDate.Text = NowDay();

			EditModeEDL.Tag =DispMode.EDL;
			EditModePrint.Tag =DispMode.PRINT;
			EditModeEdlPrint.Tag = DispMode.EdlPrint;
			EditModeEdlTop.Tag = DispMode.EelTopPrintBottom;
			SetDispMode(DispMode.EDL);


            cbIsPrintClipExt.Checked = true;
            edl.IsPrintClipExt = true;
            edl.BoldDuration = (double)1 / (double)3;
            edl.FrameRate = FrameRates.fr24;

			PrefFiles pref = new PrefFiles(this);
			pref.Load();
            

            FromEDL();
			edp = new EDLPrint(edl, printDocument1);
			edp.PageSetupDialog = pageSetupDialog1;
			edp.PrintDialog = printDialog1;
			edp.PrintPreviewDialog = printPreviewDialog1;
		}
        //***************************************************************************
        private void AsquaForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            chkComb();
            PrefFiles his = new PrefFiles(this);
            his.Save();

        }
        //***************************************************************************
        public void Reload()
        {
            if (System.IO.File.Exists(FilePath) == true)
            {
                OpenEDL(FilePath);
            }
        }
        //***************************************************************************
		public bool OpenEDL(string path)
		{
            chkComb();
			if (File.Exists(path) == false) return false;
			Clear();

            if (edl.LoadFromFile(path, edl.FrameRate,edl.BoldDuration) == true)
			{
				if (edl.EDLCount > 0)
				{
					this.Text = Path.GetFileName(path);
					FilePath = path;
                    FromEDL();
				}
			}

			return true;
		}
        //***************************************************************************
        public void FromEDL()
        {
            grd1.Rows.Clear();
            tbEDL_Title.Text = edl.Title;
            SetFrameRate(edl.FrameRate);
            SetPrintFrameRate(edl.PrintFrameRate);
            tbStart_TC.Text = edl.StartTimeOrg.Code;
            tbNew_TC.Text = edl.StartTime.Code;
            SetBoldDuration(edl.BoldDuration);
            if (edl.EDLCount > 0)
            {
                for (int i = 0; i < edl.EDLCount; i++)
                {
                    grd1.Rows.Add(edl.ClipInfo(i));
                    grd1.Rows[i].Tag = i;
                    grd1.Rows[i].HeaderCell.Value = (i + 1).ToString();
                }
                
            }
            ToPrintList();
        }
        //***************************************************************************
		public void OpenEDLDialog()
		{
			if ( openFileDialog1.ShowDialog() == DialogResult.OK)
			{
				OpenEDL(openFileDialog1.FileName);
			}
		}
		//***************************************************************************
		public void ToPrintList()
		{
            grdPrint1.Rows.Clear();
            if (edl.KYPItems.Count > 0)
            {
                edl.IsClearText = cbClearText.Checked;
                if (edl.IsClearText == true)
                {
                    edl.ClearText = cmbClearText.Text;
                }
                else
                {
                    edl.ClearText = "";
                }

                for (int i = 0; i < edl.KYPItems.Count; i++)
                {
                    grdPrint1.Rows.Add(edl.KYPInfo(i));
                    grdPrint1.Rows[i].Tag = i;
                    grdPrint1.Rows[i].HeaderCell.Value = (i + 1).ToString();
                }
                string s = "";
                s += "収録時間:" + edl.KPYlastTime.SecFrame;
                s += " Clip数:" + edl.ClipCount.ToString() + ", " + edl.ClipTime.SecFrame.ToString() + " bold("+edl.BoldTime.SecFrame+")";
                s += " Rollボールド:" + edl.RollCount.ToString() + ", " + edl.RollTime.SecFrame.ToString();
                lbRollStatus.Text = s;
            }
            else
            {
                lbRollStatus.Text = "";
            }
		}
		//***************************************************************************
		public void Clear()
		{
			this.Text = Properties.Resources.AppName + " " + Properties.Resources.VersionStr;
			FilePath = "";

			tbEDL_Title.Text = "";
			int cnt = grd1.Rows.Count;
			if (cnt > 0)
			{
				grd1.Rows.Clear();
			}
		}
		//***************************************************************************

		private void MenuFileOpen_Click(object sender, EventArgs e)
		{
			OpenEDLDialog();
		}

		//***************************************************************************
		private void btnOpenEDL_Click(object sender, EventArgs e)
		{
			OpenEDLDialog();
		}
		//***************************************************************************
		public void SetBoldDuration(double d)
		{
			tbBoldSec.Text = Math.Round(d * (double)edl.FrameRate).ToString();
		}
		//***************************************************************************
		public void SetFrameRate(FrameRates fps)
		{
			string s = "";
			if (fps == FrameRates.fr24)
			{
				s = "24p(23.976fps)";
			}
			else
			{
				s = "60i(29.97fps)";
			}
			tbFrameRate.Text = s;

		}
        //***************************************************************************
        public void SetPrintFrameRate(FrameRates fps)
        {
            string s = "";
            if (fps == FrameRates.fr24)
            {
                s = "24p(24/23.976fps)";
            }
            else
            {
                s = "60i(30/29.97fps)";
            }
            tbPFrameRate.Text = s;
        }
        //***************************************************************************
		public void SetupBoldDuration()
		{
            chkComb();
            BoldDurationDlg bd = new BoldDurationDlg(edl.FrameRate);

			bd.Duration = edl.BoldDuration;
			if (bd.ShowDialog() == DialogResult.OK)
			{
                if (edl.BoldDuration != bd.Duration)
                {
                    edl.BoldDuration = bd.Duration;
                    edl.PrintListup();
                    FromEDL();
                }

			}

		}
        //***************************************************************************
        public void SetupFrameRate()
        {
            chkComb();
            FrameRateDlg frd = new FrameRateDlg(edl.FrameRate);
            frd.Text = "収録時のFrameRateの設定";
            if (frd.ShowDialog() == DialogResult.OK)
            {
                if (edl.FrameRate != frd.FrameRate)
                {
                    edl.FrameRate = frd.FrameRate;
					edl.PrintFrameRate = frd.FrameRate;
                    edl.PrintListup();
                    FromEDL();
                }
            }
        }
        //***************************************************************************
        public void SetupPrintFrameRate()
        {
            chkComb();
            FrameRateDlg frd = new FrameRateDlg(edl.PrintFrameRate);
            frd.Text = "印刷時のFrameRateの設定";
            if (frd.ShowDialog() == DialogResult.OK)
            {
                if (edl.PrintFrameRate != frd.FrameRate)
                {
                    edl.PrintFrameRate = frd.FrameRate;
                    //edl.PrintListup();
                    ToPrintList();
                    FromEDL();
                }
            }
        }
        //***************************************************************************
        public void SetupStartTime()
        {
            chkComb();
            StartTimeDlg std = new StartTimeDlg();
            std.StartTime = edl.StartTime;
            std.StartTimeOrg = edl.StartTimeOrg;
            if (std.ShowDialog() == DialogResult.OK)
            {
                if (edl.StartTime.TotalFrame != std.StartTime.TotalFrame)
                {
                    edl.StartTime = std.StartTime;
                    edl.PrintListup();
                    FromEDL();
                    ToPrintList();
                }
                
            }
        }
        //***************************************************************************
		private void btnBoldSec_Click(object sender, EventArgs e)
		{
			SetupBoldDuration();
		}
        //***************************************************************************
        private void btnFrameRate_Click(object sender, EventArgs e)
        {
            SetupFrameRate();
        }
        //***************************************************************************
        private void btnStartTime_Click(object sender, EventArgs e)
        {
            SetupStartTime();
        }
		//***************************************************************************
        public void SetDispMode(DispMode dm)
        {
            this.SuspendLayout();
            int l = btnDispModeChange.Left;
            int t = btnDispModeChange.Top + btnDispModeChange.Height + 4;
            int wNew = ClientSize.Width - l * 2;
            int hNew = ClientSize.Height - t - statusStrip1.Height -2;

            grd1.Anchor = grdPrint1.Anchor = AnchorStyles.None;
            //btnModeEdlPrint.Checked = btnModeEDL.Checked = btnModePrint.Checked = false;
            EditModeEdlTop.Checked =
            EditModeEDL.Checked = EditModePrint.Checked = EditModeEdlPrint.Checked = false; 
            switch (dm)
            {
				case DispMode.EelTopPrintBottom:
					grd1.Top = t;
					grd1.Height = (hNew -2) /2;
					grd1.Width = wNew;
					grd1.Left = l;
					grdPrint1.Left = l;
					grdPrint1.Top = t + grd1.Height + 2;
					grdPrint1.Width = wNew;
					grdPrint1.Height = grd1.Height;
					grd1.Visible =
					grdPrint1.Visible = true;
					EditModeEdlTop.Checked = true;
					lbDispMode.Text = "EDL項目/プリント項目両方を上下表示";
					break;
				case DispMode.EdlPrint:
                    grd1.Top = grdPrint1.Top = t;
                    grd1.Height = grdPrint1.Height = hNew;
                    grd1.Width = (wNew - 4) / 2;
                    grd1.Left = l;
                    grdPrint1.Left = grd1.Left + grd1.Width + 4;
                    grdPrint1.Width = grd1.Width;
                    grd1.Visible = 
                    grdPrint1.Visible = true;
					EditModeEdlPrint.Checked = true;
                    lbDispMode.Text = "EDL項目/プリント項目両方を左右表示";
                    break;
                case DispMode.PRINT:
                    grdPrint1.Left = l;
                    grdPrint1.Top = t;
                    grdPrint1.Width = wNew;
                    grdPrint1.Height = hNew;
                    grd1.Visible = false;
                    grdPrint1.Visible = true;
					EditModePrint.Checked = true;
                    grdPrint1.Anchor = AnchorStyles.Bottom | AnchorStyles.Top | AnchorStyles.Right | AnchorStyles.Left;
                    lbDispMode.Text = "プリント項目を表示";
                    break;
                case DispMode.EDL:
                default:
                    grd1.Left = l;
                    grd1.Top = t;
                    grd1.Width = wNew;
                    grd1.Height = hNew;
                    grd1.Visible = true;
                    grdPrint1.Visible = false;
					EditModeEDL.Checked = true;
                    lbDispMode.Text = "EDL項目を表示";
                    grd1.Anchor = AnchorStyles.Bottom | AnchorStyles.Top | AnchorStyles.Right | AnchorStyles.Left;
                    break;
            }
            _DispMode = dm;
            this.ResumeLayout();

        }

        //***************************************************************************
        private void btnDispMode_Click(object sender, EventArgs e)
        {
            SetDispMode( (DispMode)((ToolStripButton)sender).Tag );
        }
        //***************************************************************************
        private void EditModeEDL_Click(object sender, EventArgs e)
        {
            SetDispMode((DispMode)((ToolStripMenuItem)sender).Tag);

        }
        //***************************************************************************

        private void btnDispModeChange_Click(object sender, EventArgs e)
        {
            int v = (int)_DispMode;
            v++;
            if (v >= (int)DispMode.Count) v = 0;
            SetDispMode((DispMode)v);
        }
        //***************************************************************************
        private void AsquaForm_Resize(object sender, EventArgs e)
        {
            if (_DispMode == DispMode.EdlPrint)
            {
                int l = btnDispModeChange.Left;
                int t = btnDispModeChange.Top + btnDispModeChange.Height + 4;
                int wNew = ClientSize.Width - l * 2;
                int hNew = ClientSize.Height - t - statusStrip1.Height - 2;
                grd1.Top = grdPrint1.Top = t;
                grd1.Height = grdPrint1.Height = hNew;
                grd1.Width = (wNew - 4) / 2;
                grd1.Left = l;
                grdPrint1.Left = grd1.Left + grd1.Width + 4;
                grdPrint1.Width = grd1.Width;
			}
			else if (_DispMode == DispMode.EelTopPrintBottom)
			{
				int l = btnDispModeChange.Left;
				int t = btnDispModeChange.Top + btnDispModeChange.Height + 4;
				int wNew = ClientSize.Width - l * 2;
				int hNew = ClientSize.Height - t - statusStrip1.Height - 2;
				grd1.Top = grdPrint1.Top = t;
				grd1.Height = grdPrint1.Height = (hNew-2)/2  ;
				grd1.Width =
				grdPrint1.Width = wNew;
				grd1.Left = l;
				grdPrint1.Left = l;
				grdPrint1.Top = t + grd1.Height + 2;
			}
        }

        //***************************************************************************
        private void cbIsPrintClipExt_CheckedChanged(object sender, EventArgs e)
        {

            if (edl.IsPrintClipExt != cbIsPrintClipExt.Checked)
            {
                edl.IsPrintClipExt = cbIsPrintClipExt.Checked;
                ToPrintList();
                //lbRollStatus.Text = "IsPrintClipExt:" + edl.IsPrintClipExt.ToString();
            }
        }
        //***************************************************************************
        public ComboBox RecTitle
        {
            get { return cmbTitle; }
            set { cmbTitle = value; }
        }
        //***************************************************************************
        public ComboBox RecMemo1st
        {
            get { return cmbMemo1; }
            set { cmbMemo1 = value; }
        }
        //***************************************************************************
        public ComboBox RecMemo2nd
        {
            get { return cmbMemo2; }
            set { cmbMemo2 = value; }
        }
        //***************************************************************************
        public ComboBox RecDate
        {
            get { return cmbDate; }
            set { cmbDate = value; }
        }
        //***************************************************************************
        public ComboBox RecCampany
        {
            get { return cmbCampany; }
            set { cmbCampany = value; }
        }
        //***************************************************************************
        public ComboBox ClearText
        {
            get { return cmbClearText; }
            set { cmbClearText = value; }
        }
        //***************************************************************************
        public FrameRates FrameRate
        {
            get { return edl.FrameRate; }
            set
            {
                edl.FrameRate = edl.PrintFrameRate = value;
                SetFrameRate(value);
                SetPrintFrameRate(value);
            }
        }
        //***************************************************************************
        public int PrintScaler
        {
            get { return (int)tbPrintScaler.Value; }
            set
            {
                tbPrintScaler.Value = value;
            }
        }
        //***************************************************************************
        public double BoldDuration
        {
            get { return edl.BoldDuration; }
            set
            {
                edl.BoldDuration = value;
                SetBoldDuration(edl.BoldDuration);
            }
        }
        public bool IsPrintClipExt
        {
            get { return edl.IsPrintClipExt; }
            set
            {
                edl.IsPrintClipExt = value;
                cbIsPrintClipExt.Checked = value;

            }
        }
        public bool IsPrintInfo
        {
            get { return edl.IsPrintInfo; }
            set
            {
                cbIsPrintInfo.Checked =
                edl.IsPrintInfo = value;
            }
        }
        public bool IsClearText
        {
            get { return edl.IsClearText; }
            set
            {
                cbClearText.Checked =
                edl.IsClearText = value;
            }
        }
        //***************************************************************************
        private void btnPFrameRate_Click(object sender, EventArgs e)
        {
            SetupPrintFrameRate();
        }
        //***************************************************************************
        public void ChkHistryComp(ComboBox cmb)
        {
            if (cmb.Text == string.Empty) return;

            string t = cmb.Text.Trim();
            if (cmb.Items.Count <= 0)
            {
                cmb.Items.Add(t);
            }else{
                int v =-1;
                for ( int i=0; i<cmb.Items.Count; i++)
                {
                    if (cmb.Items[i].ToString() == t)
                    {
                        v = i;
                        break;
                    }
                }
                if (v >= 0)
                {
                    cmb.Items.RemoveAt(v);
                }
                cmb.Items.Insert(0, t);
				if (cmb.Items.Count > 15)
				{
					cmb.Items.RemoveAt(cmb.Items.Count - 1);
				}
            }
        }
        //***************************************************************************
        private void AddComp(ComboBox cmb, string s)
        {

        }
        //***************************************************************************
        public void ChkDateComp(ComboBox cmb)
        {
            if (cmb.Text == string.Empty) return;

            string s = NowDay();
            string t = cmb.Text.Trim();
            t = t.Replace(s, "").Trim();
            if (t == "") return;
            if (cmb.Items.Count <= 0)
            {
                cmb.Items.Add(t);
            }
            else
            {
                int v = -1;
                for (int i = 0; i < cmb.Items.Count; i++)
                {
                    if (cmb.Items[i].ToString() == t)
                    {
                        v = i;
                        break;
                    }
                }
                if (v >= 0)
                {
                    cmb.Items.RemoveAt(v);
                }
                cmb.Items.Insert(0, t);
				if (cmb.Items.Count > 15)
				{
					cmb.Items.RemoveAt(cmb.Items.Count -1);
				}
            }
        }
        //***************************************************************************
        public void chkComb()
        {
            ChkHistryComp(cmbTitle);
            ChkHistryComp(cmbMemo1);
            ChkHistryComp(cmbMemo2);
            ChkDateComp(cmbDate);
            ChkHistryComp(cmbCampany);
            ChkHistryComp(cmbClearText);
        }
        //***************************************************************************
        public string NowDay()
        {
            DateTime now = DateTime.Now;

            string s = "";
            s += now.Year.ToString() + "年";
            s += now.Month.ToString() + "月";
            s += now.Day.ToString() + "日";
            return s;
        }
        //***************************************************************************
        private void btnData_Click(object sender, EventArgs e)
        {
            DaySelectDlg dsd = new DaySelectDlg();
            if (dsd.ShowDialog() == DialogResult.OK)
            {
                string s = cmbDate.Text.Trim();
                cmbDate.Text = dsd.DayStr;
            }

        }
        //***************************************************************************
		public void PreviewDialog()
		{
			edp.TextSet(PrintText.title, cmbTitle.Text);
			edp.TextSet(PrintText.memo1, cmbMemo1.Text);
			edp.TextSet(PrintText.memo2, cmbMemo2.Text);
			edp.TextSet(PrintText.date, cmbDate.Text);
			edp.TextSet(PrintText.campany, cmbCampany.Text);
            edl.PrintScaler = (int)tbPrintScaler.Value;
			edp.ShowPreviewtDialog();

		}
        //***************************************************************************
        public void PrintDialog()
        {
            edp.TextSet(PrintText.title, cmbTitle.Text);
            edp.TextSet(PrintText.memo1, cmbMemo1.Text);
            edp.TextSet(PrintText.memo2, cmbMemo2.Text);
            edp.TextSet(PrintText.date, cmbDate.Text);
            edp.TextSet(PrintText.campany, cmbCampany.Text);
            edl.PrintScaler = (int)tbPrintScaler.Value;
            edp.ShowPrint();

        }
		//***************************************************************************
		public void PageSetupDialog()
		{
			edp.ShowPageSetup();

		}
		//***************************************************************************
		private void btnPrintPreview_Click(object sender, EventArgs e)
		{
			PreviewDialog();
		}
		//***************************************************************************
		private void btnPageSetup_Click(object sender, EventArgs e)
		{
			PageSetupDialog();
		}
        //***************************************************************************
        private void cbIsPrintInfo_Click(object sender, EventArgs e)
        {
            edl.IsPrintInfo = cbIsPrintInfo.Checked;
        }
        //***************************************************************************
        private void tbPrintScaler_ValueChanged(object sender, EventArgs e)
        {
            edl.PrintScaler = (int)tbPrintScaler.Value;
        }
        //***************************************************************************
        private void FilePrintPreview_Click(object sender, EventArgs e)
        {
            PreviewDialog();
        }
        //***************************************************************************
        private void FilePageSetup_Click(object sender, EventArgs e)
        {
            PageSetupDialog();
        }
        //***************************************************************************
        private void btnPrint_Click(object sender, EventArgs e)
        {
            PrintDialog();
        }
        //***************************************************************************
        private void FilePrint_Click(object sender, EventArgs e)
        {
            PrintDialog();
        }

        private void btnReload_Click(object sender, EventArgs e)
        {
            Reload();
        }

        private void FileReload_Click(object sender, EventArgs e)
        {
            Reload();
        }

        //***************************************************************************
        private void cbClearText_CheckedChanged(object sender, EventArgs e)
        {
            if (edl.IsClearText != cbClearText.Checked)
            {
                edl.IsClearText = cbClearText.Checked;
                if (edl.IsClearText == true)
                {
                    edl.ClearText = cmbClearText.Text;
                }
                else
                {
                    edl.ClearText = "";
                }
                ToPrintList();
            }
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            edl.IsClearText = cbClearText.Checked;
            if (edl.IsClearText == true)
            {
                edl.ClearText = cmbClearText.Text;
            }
            else
            {
                edl.ClearText = "";
            }
            ToPrintList();

        }

        //***************************************************************************
        private void AsquaForm_DragEnter(object sender, DragEventArgs e)
        {
            //コントロール内にドラッグされたとき実行される
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                //ドラッグされたデータ形式を調べ、ファイルのときはコピーとする
                e.Effect = DragDropEffects.Copy;
            else
                //ファイル以外は受け付けない
                e.Effect = DragDropEffects.None;

        }

        private void AsquaForm_DragDrop(object sender, DragEventArgs e)
        {
            //OpenEDL
            string[] fileNames = (string[])e.Data.GetData(DataFormats.FileDrop, false);

            if (fileNames.Length > 0)
            {
                for (int i = 0; i < fileNames.Length; i++)
                {
                    if (File.Exists(fileNames[i]) == true)
                    {
                        OpenEDL(fileNames[i]);
                        break;
                    }
                }
            }
        }

        //***************************************************************************
        private void AsquaForm_Load(object sender, EventArgs e)
        {
            string[] cmds;
            cmds = System.Environment.GetCommandLineArgs();
            //MessageBox.Show(System.Environment.CommandLine);
            //コマンドライン引数の表示
            if (cmds.Length > 1)
            {
                for (int i = 1; i < cmds.Length; i++)
                {
                    string cmd = cmds[i];
                    if ((cmd != "") && (cmd[0] != '-') && (cmd[0] != '/'))
                    {
                        string s = cmd;
                        string ext = Path.GetExtension(s);
                        if (ext == "") s += ".edl";
                        if (File.Exists(s))
                        {
                            if (OpenEDL(s))
                            {
                                break;
                            }
                        }
                    }
                }
            }

        }
		//***************************************************************************

     }

    public enum DispMode
    {
        EDL =0,
        PRINT,
        EdlPrint,
		EelTopPrintBottom,
        Count
    }
}
