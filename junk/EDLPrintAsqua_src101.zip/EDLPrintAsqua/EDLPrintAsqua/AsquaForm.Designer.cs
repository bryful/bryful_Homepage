﻿namespace EDLPrintAsqua
{
	partial class AsquaForm
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AsquaForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuFileOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.FileReload = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.FilePrint = new System.Windows.Forms.ToolStripMenuItem();
            this.FilePageSetup = new System.Windows.Forms.ToolStripMenuItem();
            this.FilePrintPreview = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.quitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditModeEDL = new System.Windows.Forms.ToolStripMenuItem();
            this.EditModePrint = new System.Windows.Forms.ToolStripMenuItem();
            this.EditModeEdlPrint = new System.Windows.Forms.ToolStripMenuItem();
            this.EditModeEdlTop = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.lbRollStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnFrameRate = new System.Windows.Forms.Button();
            this.btnBoldSec = new System.Windows.Forms.Button();
            this.tbBoldSec = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbFrameRate = new System.Windows.Forms.TextBox();
            this.tbEDL_Title = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnStartTime = new System.Windows.Forms.Button();
            this.tbNew_TC = new System.Windows.Forms.TextBox();
            this.tbStart_TC = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnData = new System.Windows.Forms.Button();
            this.cmbCampany = new System.Windows.Forms.ComboBox();
            this.cmbDate = new System.Windows.Forms.ComboBox();
            this.cmbMemo2 = new System.Windows.Forms.ComboBox();
            this.cmbMemo1 = new System.Windows.Forms.ComboBox();
            this.cmbTitle = new System.Windows.Forms.ComboBox();
            this.cbIsPrintInfo = new System.Windows.Forms.CheckBox();
            this.cbIsPrintClipExt = new System.Windows.Forms.CheckBox();
            this.grd1 = new System.Windows.Forms.DataGridView();
            this.clmClipName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmInPoint = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmOutPoint = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmDuration = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmComment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cmBold = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cmBoldSetting = new System.Windows.Forms.ToolStripMenuItem();
            this.grdPrint1 = new System.Windows.Forms.DataGridView();
            this.pClipName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pInPoint = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pInPoint2nd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pOutPoint = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pDuration = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pComment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnGo = new System.Windows.Forms.Button();
            this.cmbClearText = new System.Windows.Forms.ComboBox();
            this.cbClearText = new System.Windows.Forms.CheckBox();
            this.tbPrintScaler = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.btnPFrameRate = new System.Windows.Forms.Button();
            this.tbPFrameRate = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnOpenEDL = new System.Windows.Forms.ToolStripButton();
            this.btnReload = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.btnPageSetup = new System.Windows.Forms.ToolStripButton();
            this.btnPrintPreview = new System.Windows.Forms.ToolStripButton();
            this.btnPrint = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.btnDispModeChange = new System.Windows.Forms.Button();
            this.lbDispMode = new System.Windows.Forms.Label();
            this.pageSetupDialog1 = new System.Windows.Forms.PageSetupDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grd1)).BeginInit();
            this.cmBold.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdPrint1)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbPrintScaler)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.DefaultExt = "edl";
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "EDL Files(*.edl)|*.edl|All Files(*.*)|*.*";
            this.openFileDialog1.Title = "EDLファイルの読み込み";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(747, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuFileOpen,
            this.FileReload,
            this.toolStripSeparator1,
            this.FilePrint,
            this.FilePageSetup,
            this.FilePrintPreview,
            this.toolStripSeparator2,
            this.quitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(36, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // MenuFileOpen
            // 
            this.MenuFileOpen.Image = ((System.Drawing.Image)(resources.GetObject("MenuFileOpen.Image")));
            this.MenuFileOpen.Name = "MenuFileOpen";
            this.MenuFileOpen.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.MenuFileOpen.Size = new System.Drawing.Size(155, 22);
            this.MenuFileOpen.Text = "OpenEDL";
            this.MenuFileOpen.Click += new System.EventHandler(this.MenuFileOpen_Click);
            // 
            // FileReload
            // 
            this.FileReload.Image = ((System.Drawing.Image)(resources.GetObject("FileReload.Image")));
            this.FileReload.Name = "FileReload";
            this.FileReload.Size = new System.Drawing.Size(155, 22);
            this.FileReload.Text = "Reload";
            this.FileReload.Click += new System.EventHandler(this.FileReload_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(152, 6);
            // 
            // FilePrint
            // 
            this.FilePrint.Image = ((System.Drawing.Image)(resources.GetObject("FilePrint.Image")));
            this.FilePrint.Name = "FilePrint";
            this.FilePrint.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.FilePrint.Size = new System.Drawing.Size(155, 22);
            this.FilePrint.Text = "Print";
            this.FilePrint.Click += new System.EventHandler(this.FilePrint_Click);
            // 
            // FilePageSetup
            // 
            this.FilePageSetup.Image = ((System.Drawing.Image)(resources.GetObject("FilePageSetup.Image")));
            this.FilePageSetup.Name = "FilePageSetup";
            this.FilePageSetup.Size = new System.Drawing.Size(155, 22);
            this.FilePageSetup.Text = "PageSetup";
            this.FilePageSetup.Click += new System.EventHandler(this.FilePageSetup_Click);
            // 
            // FilePrintPreview
            // 
            this.FilePrintPreview.Image = ((System.Drawing.Image)(resources.GetObject("FilePrintPreview.Image")));
            this.FilePrintPreview.Name = "FilePrintPreview";
            this.FilePrintPreview.Size = new System.Drawing.Size(155, 22);
            this.FilePrintPreview.Text = "PrintPreview";
            this.FilePrintPreview.Click += new System.EventHandler(this.FilePrintPreview_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(152, 6);
            // 
            // quitToolStripMenuItem
            // 
            this.quitToolStripMenuItem.Name = "quitToolStripMenuItem";
            this.quitToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Q)));
            this.quitToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.quitToolStripMenuItem.Text = "Quit";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.EditModeEDL,
            this.EditModePrint,
            this.EditModeEdlPrint,
            this.EditModeEdlTop,
            this.toolStripMenuItem1});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // EditModeEDL
            // 
            this.EditModeEDL.Checked = true;
            this.EditModeEDL.CheckState = System.Windows.Forms.CheckState.Checked;
            this.EditModeEDL.Name = "EditModeEDL";
            this.EditModeEDL.Size = new System.Drawing.Size(157, 22);
            this.EditModeEDL.Text = "EditModeEDL";
            this.EditModeEDL.Click += new System.EventHandler(this.EditModeEDL_Click);
            // 
            // EditModePrint
            // 
            this.EditModePrint.Name = "EditModePrint";
            this.EditModePrint.Size = new System.Drawing.Size(157, 22);
            this.EditModePrint.Text = "EditModePrint";
            this.EditModePrint.Click += new System.EventHandler(this.EditModeEDL_Click);
            // 
            // EditModeEdlPrint
            // 
            this.EditModeEdlPrint.Name = "EditModeEdlPrint";
            this.EditModeEdlPrint.Size = new System.Drawing.Size(157, 22);
            this.EditModeEdlPrint.Text = "EditModeEdlPrint";
            this.EditModeEdlPrint.Click += new System.EventHandler(this.EditModeEDL_Click);
            // 
            // EditModeEdlTop
            // 
            this.EditModeEdlTop.Name = "EditModeEdlTop";
            this.EditModeEdlTop.Size = new System.Drawing.Size(157, 22);
            this.EditModeEdlTop.Text = "EditModeEdlTop";
            this.EditModeEdlTop.Click += new System.EventHandler(this.EditModeEDL_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(154, 6);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lbRollStatus});
            this.statusStrip1.Location = new System.Drawing.Point(0, 563);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(747, 22);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // lbRollStatus
            // 
            this.lbRollStatus.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbRollStatus.Name = "lbRollStatus";
            this.lbRollStatus.Size = new System.Drawing.Size(79, 17);
            this.lbRollStatus.Text = "lbRollStatus";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnFrameRate);
            this.groupBox1.Controls.Add(this.btnBoldSec);
            this.groupBox1.Controls.Add(this.tbBoldSec);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.tbFrameRate);
            this.groupBox1.Controls.Add(this.tbEDL_Title);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.btnStartTime);
            this.groupBox1.Controls.Add(this.tbNew_TC);
            this.groupBox1.Controls.Add(this.tbStart_TC);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(8, 52);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(227, 185);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "タイムコード";
            // 
            // btnFrameRate
            // 
            this.btnFrameRate.Location = new System.Drawing.Point(192, 128);
            this.btnFrameRate.Name = "btnFrameRate";
            this.btnFrameRate.Size = new System.Drawing.Size(29, 23);
            this.btnFrameRate.TabIndex = 29;
            this.btnFrameRate.Text = "set";
            this.btnFrameRate.UseVisualStyleBackColor = true;
            this.btnFrameRate.Click += new System.EventHandler(this.btnFrameRate_Click);
            // 
            // btnBoldSec
            // 
            this.btnBoldSec.Location = new System.Drawing.Point(191, 153);
            this.btnBoldSec.Name = "btnBoldSec";
            this.btnBoldSec.Size = new System.Drawing.Size(29, 23);
            this.btnBoldSec.TabIndex = 28;
            this.btnBoldSec.Text = "set";
            this.btnBoldSec.UseVisualStyleBackColor = true;
            this.btnBoldSec.Click += new System.EventHandler(this.btnBoldSec_Click);
            // 
            // tbBoldSec
            // 
            this.tbBoldSec.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbBoldSec.Location = new System.Drawing.Point(102, 157);
            this.tbBoldSec.Name = "tbBoldSec";
            this.tbBoldSec.ReadOnly = true;
            this.tbBoldSec.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbBoldSec.Size = new System.Drawing.Size(72, 19);
            this.tbBoldSec.TabIndex = 27;
            this.tbBoldSec.Text = "8";
            this.tbBoldSec.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 12);
            this.label3.TabIndex = 26;
            this.label3.Text = "ボールドの長さ";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbFrameRate
            // 
            this.tbFrameRate.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbFrameRate.Location = new System.Drawing.Point(49, 132);
            this.tbFrameRate.Name = "tbFrameRate";
            this.tbFrameRate.ReadOnly = true;
            this.tbFrameRate.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbFrameRate.Size = new System.Drawing.Size(129, 19);
            this.tbFrameRate.TabIndex = 25;
            this.tbFrameRate.Text = "24p(23.976fps)";
            this.tbFrameRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbEDL_Title
            // 
            this.tbEDL_Title.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbEDL_Title.Location = new System.Drawing.Point(102, 21);
            this.tbEDL_Title.Name = "tbEDL_Title";
            this.tbEDL_Title.ReadOnly = true;
            this.tbEDL_Title.Size = new System.Drawing.Size(118, 19);
            this.tbEDL_Title.TabIndex = 24;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(36, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(61, 12);
            this.label9.TabIndex = 23;
            this.label9.Text = "EDLタイトル";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnStartTime
            // 
            this.btnStartTime.Location = new System.Drawing.Point(192, 82);
            this.btnStartTime.Name = "btnStartTime";
            this.btnStartTime.Size = new System.Drawing.Size(29, 23);
            this.btnStartTime.TabIndex = 21;
            this.btnStartTime.Text = "set";
            this.btnStartTime.UseVisualStyleBackColor = true;
            this.btnStartTime.Click += new System.EventHandler(this.btnStartTime_Click);
            // 
            // tbNew_TC
            // 
            this.tbNew_TC.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbNew_TC.Location = new System.Drawing.Point(102, 86);
            this.tbNew_TC.Name = "tbNew_TC";
            this.tbNew_TC.ReadOnly = true;
            this.tbNew_TC.Size = new System.Drawing.Size(76, 19);
            this.tbNew_TC.TabIndex = 16;
            this.tbNew_TC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbStart_TC
            // 
            this.tbStart_TC.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbStart_TC.Location = new System.Drawing.Point(102, 51);
            this.tbStart_TC.Name = "tbStart_TC";
            this.tbStart_TC.ReadOnly = true;
            this.tbStart_TC.Size = new System.Drawing.Size(76, 19);
            this.tbStart_TC.TabIndex = 15;
            this.tbStart_TC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 12);
            this.label4.TabIndex = 14;
            this.label4.Text = "収録時のフレームレート";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 12);
            this.label2.TabIndex = 11;
            this.label2.Text = "新規開始フレーム";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 12);
            this.label1.TabIndex = 10;
            this.label1.Text = "開始フレーム";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.btnData);
            this.groupBox2.Controls.Add(this.cmbCampany);
            this.groupBox2.Controls.Add(this.cmbDate);
            this.groupBox2.Controls.Add(this.cmbMemo2);
            this.groupBox2.Controls.Add(this.cmbMemo1);
            this.groupBox2.Controls.Add(this.cmbTitle);
            this.groupBox2.Location = new System.Drawing.Point(247, 52);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(296, 185);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "項目";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(26, 139);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 9;
            this.label8.Text = "社名";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(26, 109);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 8;
            this.label7.Text = "日付";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(33, 51);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(22, 12);
            this.label6.TabIndex = 7;
            this.label6.Text = "メモ";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 12);
            this.label5.TabIndex = 6;
            this.label5.Text = "タイトル";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnData
            // 
            this.btnData.Location = new System.Drawing.Point(218, 104);
            this.btnData.Name = "btnData";
            this.btnData.Size = new System.Drawing.Size(41, 23);
            this.btnData.TabIndex = 5;
            this.btnData.Text = "日付";
            this.btnData.UseVisualStyleBackColor = true;
            this.btnData.Click += new System.EventHandler(this.btnData_Click);
            // 
            // cmbCampany
            // 
            this.cmbCampany.FormattingEnabled = true;
            this.cmbCampany.Location = new System.Drawing.Point(62, 135);
            this.cmbCampany.Name = "cmbCampany";
            this.cmbCampany.Size = new System.Drawing.Size(150, 20);
            this.cmbCampany.TabIndex = 4;
            // 
            // cmbDate
            // 
            this.cmbDate.FormattingEnabled = true;
            this.cmbDate.Location = new System.Drawing.Point(61, 105);
            this.cmbDate.Name = "cmbDate";
            this.cmbDate.Size = new System.Drawing.Size(151, 20);
            this.cmbDate.TabIndex = 3;
            // 
            // cmbMemo2
            // 
            this.cmbMemo2.FormattingEnabled = true;
            this.cmbMemo2.Location = new System.Drawing.Point(62, 77);
            this.cmbMemo2.Name = "cmbMemo2";
            this.cmbMemo2.Size = new System.Drawing.Size(224, 20);
            this.cmbMemo2.TabIndex = 2;
            // 
            // cmbMemo1
            // 
            this.cmbMemo1.FormattingEnabled = true;
            this.cmbMemo1.Location = new System.Drawing.Point(62, 48);
            this.cmbMemo1.Name = "cmbMemo1";
            this.cmbMemo1.Size = new System.Drawing.Size(224, 20);
            this.cmbMemo1.TabIndex = 1;
            // 
            // cmbTitle
            // 
            this.cmbTitle.FormattingEnabled = true;
            this.cmbTitle.Items.AddRange(new object[] {
            "レコーディング記録表"});
            this.cmbTitle.Location = new System.Drawing.Point(62, 19);
            this.cmbTitle.Name = "cmbTitle";
            this.cmbTitle.Size = new System.Drawing.Size(131, 20);
            this.cmbTitle.TabIndex = 0;
            this.cmbTitle.Text = "レコーディング記録表";
            // 
            // cbIsPrintInfo
            // 
            this.cbIsPrintInfo.AutoSize = true;
            this.cbIsPrintInfo.Location = new System.Drawing.Point(6, 38);
            this.cbIsPrintInfo.Name = "cbIsPrintInfo";
            this.cbIsPrintInfo.Size = new System.Drawing.Size(106, 16);
            this.cbIsPrintInfo.TabIndex = 12;
            this.cbIsPrintInfo.Text = "収録情報の印刷";
            this.cbIsPrintInfo.UseVisualStyleBackColor = true;
            this.cbIsPrintInfo.Click += new System.EventHandler(this.cbIsPrintInfo_Click);
            // 
            // cbIsPrintClipExt
            // 
            this.cbIsPrintClipExt.AutoSize = true;
            this.cbIsPrintClipExt.Checked = true;
            this.cbIsPrintClipExt.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbIsPrintClipExt.Location = new System.Drawing.Point(6, 18);
            this.cbIsPrintClipExt.Name = "cbIsPrintClipExt";
            this.cbIsPrintClipExt.Size = new System.Drawing.Size(160, 16);
            this.cbIsPrintClipExt.TabIndex = 11;
            this.cbIsPrintClipExt.Text = "ムービーの拡張子を印刷する";
            this.cbIsPrintClipExt.UseVisualStyleBackColor = true;
            this.cbIsPrintClipExt.CheckedChanged += new System.EventHandler(this.cbIsPrintClipExt_CheckedChanged);
            // 
            // grd1
            // 
            this.grd1.AllowUserToAddRows = false;
            this.grd1.AllowUserToDeleteRows = false;
            this.grd1.AllowUserToResizeRows = false;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grd1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.grd1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clmClipName,
            this.clmInPoint,
            this.clmOutPoint,
            this.clmDuration,
            this.clmStatus,
            this.clmComment});
            this.grd1.ContextMenuStrip = this.cmBold;
            this.grd1.Location = new System.Drawing.Point(8, 269);
            this.grd1.MultiSelect = false;
            this.grd1.Name = "grd1";
            this.grd1.ReadOnly = true;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle34.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grd1.RowHeadersDefaultCellStyle = dataGridViewCellStyle34;
            this.grd1.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.grd1.RowTemplate.Height = 21;
            this.grd1.RowTemplate.ReadOnly = true;
            this.grd1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grd1.Size = new System.Drawing.Size(729, 291);
            this.grd1.TabIndex = 10;
            // 
            // clmClipName
            // 
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.clmClipName.DefaultCellStyle = dataGridViewCellStyle28;
            this.clmClipName.HeaderText = "ClipName";
            this.clmClipName.Name = "clmClipName";
            this.clmClipName.ReadOnly = true;
            this.clmClipName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clmClipName.Width = 170;
            // 
            // clmInPoint
            // 
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.clmInPoint.DefaultCellStyle = dataGridViewCellStyle29;
            this.clmInPoint.HeaderText = "in点";
            this.clmInPoint.Name = "clmInPoint";
            this.clmInPoint.ReadOnly = true;
            this.clmInPoint.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clmInPoint.Width = 75;
            // 
            // clmOutPoint
            // 
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.clmOutPoint.DefaultCellStyle = dataGridViewCellStyle30;
            this.clmOutPoint.HeaderText = "out点";
            this.clmOutPoint.Name = "clmOutPoint";
            this.clmOutPoint.ReadOnly = true;
            this.clmOutPoint.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clmOutPoint.Width = 75;
            // 
            // clmDuration
            // 
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.clmDuration.DefaultCellStyle = dataGridViewCellStyle31;
            this.clmDuration.HeaderText = "Duration";
            this.clmDuration.Name = "clmDuration";
            this.clmDuration.ReadOnly = true;
            this.clmDuration.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clmDuration.Width = 60;
            // 
            // clmStatus
            // 
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.clmStatus.DefaultCellStyle = dataGridViewCellStyle32;
            this.clmStatus.HeaderText = "status";
            this.clmStatus.Name = "clmStatus";
            this.clmStatus.ReadOnly = true;
            this.clmStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clmStatus.Width = 130;
            // 
            // clmComment
            // 
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.clmComment.DefaultCellStyle = dataGridViewCellStyle33;
            this.clmComment.HeaderText = "コメント";
            this.clmComment.Name = "clmComment";
            this.clmComment.ReadOnly = true;
            this.clmComment.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clmComment.Width = 75;
            // 
            // cmBold
            // 
            this.cmBold.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmBoldSetting});
            this.cmBold.Name = "cmBold";
            this.cmBold.Size = new System.Drawing.Size(151, 26);
            // 
            // cmBoldSetting
            // 
            this.cmBoldSetting.Name = "cmBoldSetting";
            this.cmBoldSetting.Size = new System.Drawing.Size(150, 22);
            this.cmBoldSetting.Text = "ボールド切り替え";
            // 
            // grdPrint1
            // 
            this.grdPrint1.AllowUserToAddRows = false;
            this.grdPrint1.AllowUserToDeleteRows = false;
            this.grdPrint1.AllowUserToResizeRows = false;
            this.grdPrint1.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.grdPrint1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.pClipName,
            this.pInPoint,
            this.pInPoint2nd,
            this.pOutPoint,
            this.pDuration,
            this.pComment});
            this.grdPrint1.Location = new System.Drawing.Point(16, 331);
            this.grdPrint1.MultiSelect = false;
            this.grdPrint1.Name = "grdPrint1";
            this.grdPrint1.ReadOnly = true;
            this.grdPrint1.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.grdPrint1.RowTemplate.DefaultCellStyle.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.grdPrint1.RowTemplate.Height = 21;
            this.grdPrint1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grdPrint1.Size = new System.Drawing.Size(635, 182);
            this.grdPrint1.TabIndex = 15;
            // 
            // pClipName
            // 
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.pClipName.DefaultCellStyle = dataGridViewCellStyle15;
            this.pClipName.HeaderText = "ClipName";
            this.pClipName.Name = "pClipName";
            this.pClipName.ReadOnly = true;
            this.pClipName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.pClipName.Width = 170;
            // 
            // pInPoint
            // 
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.pInPoint.DefaultCellStyle = dataGridViewCellStyle22;
            this.pInPoint.HeaderText = "in点";
            this.pInPoint.Name = "pInPoint";
            this.pInPoint.ReadOnly = true;
            this.pInPoint.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.pInPoint.Width = 75;
            // 
            // pInPoint2nd
            // 
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.pInPoint2nd.DefaultCellStyle = dataGridViewCellStyle35;
            this.pInPoint2nd.HeaderText = "画頭のin点";
            this.pInPoint2nd.Name = "pInPoint2nd";
            this.pInPoint2nd.ReadOnly = true;
            this.pInPoint2nd.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.pInPoint2nd.Width = 90;
            // 
            // pOutPoint
            // 
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.pOutPoint.DefaultCellStyle = dataGridViewCellStyle36;
            this.pOutPoint.HeaderText = "out点";
            this.pOutPoint.Name = "pOutPoint";
            this.pOutPoint.ReadOnly = true;
            this.pOutPoint.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.pOutPoint.Width = 75;
            // 
            // pDuration
            // 
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.pDuration.DefaultCellStyle = dataGridViewCellStyle37;
            this.pDuration.HeaderText = "Duration";
            this.pDuration.Name = "pDuration";
            this.pDuration.ReadOnly = true;
            this.pDuration.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.pDuration.Width = 75;
            // 
            // pComment
            // 
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.pComment.DefaultCellStyle = dataGridViewCellStyle38;
            this.pComment.HeaderText = "コメント";
            this.pComment.Name = "pComment";
            this.pComment.ReadOnly = true;
            this.pComment.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.pComment.Width = 80;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnGo);
            this.groupBox3.Controls.Add(this.cmbClearText);
            this.groupBox3.Controls.Add(this.cbClearText);
            this.groupBox3.Controls.Add(this.tbPrintScaler);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.btnPFrameRate);
            this.groupBox3.Controls.Add(this.tbPFrameRate);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.cbIsPrintInfo);
            this.groupBox3.Controls.Add(this.cbIsPrintClipExt);
            this.groupBox3.Location = new System.Drawing.Point(549, 52);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(188, 185);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "動作設定";
            // 
            // btnGo
            // 
            this.btnGo.Location = new System.Drawing.Point(137, 149);
            this.btnGo.Name = "btnGo";
            this.btnGo.Size = new System.Drawing.Size(45, 23);
            this.btnGo.TabIndex = 36;
            this.btnGo.Text = "再描";
            this.btnGo.UseVisualStyleBackColor = true;
            this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
            // 
            // cmbClearText
            // 
            this.cmbClearText.FormattingEnabled = true;
            this.cmbClearText.Location = new System.Drawing.Point(8, 152);
            this.cmbClearText.Name = "cmbClearText";
            this.cmbClearText.Size = new System.Drawing.Size(124, 20);
            this.cmbClearText.TabIndex = 10;
            // 
            // cbClearText
            // 
            this.cbClearText.AutoSize = true;
            this.cbClearText.Location = new System.Drawing.Point(6, 132);
            this.cbClearText.Name = "cbClearText";
            this.cbClearText.Size = new System.Drawing.Size(145, 16);
            this.cbClearText.TabIndex = 35;
            this.cbClearText.Text = "以下の文字は表示しない";
            this.cbClearText.UseVisualStyleBackColor = true;
            this.cbClearText.CheckedChanged += new System.EventHandler(this.cbClearText_CheckedChanged);
            // 
            // tbPrintScaler
            // 
            this.tbPrintScaler.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbPrintScaler.Location = new System.Drawing.Point(79, 54);
            this.tbPrintScaler.Name = "tbPrintScaler";
            this.tbPrintScaler.Size = new System.Drawing.Size(53, 23);
            this.tbPrintScaler.TabIndex = 34;
            this.tbPrintScaler.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.tbPrintScaler.ValueChanged += new System.EventHandler(this.tbPrintScaler_ValueChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 12);
            this.label11.TabIndex = 33;
            this.label11.Text = "印刷スケール";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnPFrameRate
            // 
            this.btnPFrameRate.Location = new System.Drawing.Point(153, 98);
            this.btnPFrameRate.Name = "btnPFrameRate";
            this.btnPFrameRate.Size = new System.Drawing.Size(29, 23);
            this.btnPFrameRate.TabIndex = 32;
            this.btnPFrameRate.Text = "set";
            this.btnPFrameRate.UseVisualStyleBackColor = true;
            this.btnPFrameRate.Click += new System.EventHandler(this.btnPFrameRate_Click);
            // 
            // tbPFrameRate
            // 
            this.tbPFrameRate.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbPFrameRate.Location = new System.Drawing.Point(18, 100);
            this.tbPFrameRate.Name = "tbPFrameRate";
            this.tbPFrameRate.ReadOnly = true;
            this.tbPFrameRate.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbPFrameRate.Size = new System.Drawing.Size(129, 19);
            this.tbPFrameRate.TabIndex = 31;
            this.tbPFrameRate.Text = "24p(23.976fps)";
            this.tbPFrameRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 85);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(115, 12);
            this.label10.TabIndex = 30;
            this.label10.Text = "印刷時のフレームレート";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnOpenEDL,
            this.btnReload,
            this.toolStripSeparator3,
            this.btnPageSetup,
            this.btnPrintPreview,
            this.btnPrint,
            this.toolStripSeparator4});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(747, 25);
            this.toolStrip1.TabIndex = 18;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btnOpenEDL
            // 
            this.btnOpenEDL.Image = ((System.Drawing.Image)(resources.GetObject("btnOpenEDL.Image")));
            this.btnOpenEDL.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnOpenEDL.Name = "btnOpenEDL";
            this.btnOpenEDL.Size = new System.Drawing.Size(92, 22);
            this.btnOpenEDL.Text = "EDL読み込み";
            this.btnOpenEDL.Click += new System.EventHandler(this.MenuFileOpen_Click);
            // 
            // btnReload
            // 
            this.btnReload.Image = ((System.Drawing.Image)(resources.GetObject("btnReload.Image")));
            this.btnReload.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnReload.Name = "btnReload";
            this.btnReload.Size = new System.Drawing.Size(83, 22);
            this.btnReload.Text = "再読み込み";
            this.btnReload.Click += new System.EventHandler(this.btnReload_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // btnPageSetup
            // 
            this.btnPageSetup.Image = ((System.Drawing.Image)(resources.GetObject("btnPageSetup.Image")));
            this.btnPageSetup.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPageSetup.Name = "btnPageSetup";
            this.btnPageSetup.Size = new System.Drawing.Size(79, 22);
            this.btnPageSetup.Text = "ページ設定";
            this.btnPageSetup.Click += new System.EventHandler(this.btnPageSetup_Click);
            // 
            // btnPrintPreview
            // 
            this.btnPrintPreview.Image = ((System.Drawing.Image)(resources.GetObject("btnPrintPreview.Image")));
            this.btnPrintPreview.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrintPreview.Name = "btnPrintPreview";
            this.btnPrintPreview.Size = new System.Drawing.Size(102, 22);
            this.btnPrintPreview.Text = "プリントプレビュー";
            this.btnPrintPreview.Click += new System.EventHandler(this.btnPrintPreview_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Image = ((System.Drawing.Image)(resources.GetObject("btnPrint.Image")));
            this.btnPrint.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(58, 22);
            this.btnPrint.Text = "プリント";
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // btnDispModeChange
            // 
            this.btnDispModeChange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDispModeChange.Location = new System.Drawing.Point(8, 243);
            this.btnDispModeChange.Name = "btnDispModeChange";
            this.btnDispModeChange.Size = new System.Drawing.Size(132, 23);
            this.btnDispModeChange.TabIndex = 19;
            this.btnDispModeChange.Text = "表示切替";
            this.btnDispModeChange.UseVisualStyleBackColor = true;
            this.btnDispModeChange.Click += new System.EventHandler(this.btnDispModeChange_Click);
            // 
            // lbDispMode
            // 
            this.lbDispMode.AutoSize = true;
            this.lbDispMode.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbDispMode.Location = new System.Drawing.Point(146, 247);
            this.lbDispMode.Name = "lbDispMode";
            this.lbDispMode.Size = new System.Drawing.Size(68, 13);
            this.lbDispMode.TabIndex = 20;
            this.lbDispMode.Text = "DispMode";
            // 
            // pageSetupDialog1
            // 
            this.pageSetupDialog1.Document = this.printDocument1;
            this.pageSetupDialog1.EnableMetric = true;
            // 
            // printDialog1
            // 
            this.printDialog1.AllowCurrentPage = true;
            this.printDialog1.AllowSelection = true;
            this.printDialog1.AllowSomePages = true;
            this.printDialog1.Document = this.printDocument1;
            this.printDialog1.PrintToFile = true;
            this.printDialog1.UseEXDialog = true;
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.UseAntiAlias = true;
            this.printPreviewDialog1.Visible = false;
            // 
            // AsquaForm
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(747, 585);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.btnDispModeChange);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.grdPrint1);
            this.Controls.Add(this.grd1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.lbDispMode);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.groupBox3);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(4000, 2400);
            this.MinimumSize = new System.Drawing.Size(755, 400);
            this.Name = "AsquaForm";
            this.Text = "EDLPrint Asqua Beta01";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AsquaForm_FormClosed);
            this.Load += new System.EventHandler(this.AsquaForm_Load);
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.AsquaForm_DragDrop);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.AsquaForm_DragEnter);
            this.Resize += new System.EventHandler(this.AsquaForm_Resize);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grd1)).EndInit();
            this.cmBold.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdPrint1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbPrintScaler)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem MenuFileOpen;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
		private System.Windows.Forms.ToolStripMenuItem FilePrint;
		private System.Windows.Forms.ToolStripMenuItem FilePageSetup;
		private System.Windows.Forms.ToolStripMenuItem FilePrintPreview;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
		private System.Windows.Forms.ToolStripMenuItem quitToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem EditModeEDL;
		private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.StatusStrip statusStrip1;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnStartTime;
		private System.Windows.Forms.TextBox tbNew_TC;
		private System.Windows.Forms.TextBox tbStart_TC;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button btnData;
		private System.Windows.Forms.ComboBox cmbCampany;
		private System.Windows.Forms.ComboBox cmbDate;
		private System.Windows.Forms.ComboBox cmbMemo2;
		private System.Windows.Forms.ComboBox cmbMemo1;
		private System.Windows.Forms.ComboBox cmbTitle;
		private System.Windows.Forms.TextBox tbEDL_Title;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.ToolStripStatusLabel lbRollStatus;
		private System.Windows.Forms.CheckBox cbIsPrintClipExt;
        private System.Windows.Forms.DataGridView grd1;
        private System.Windows.Forms.CheckBox cbIsPrintInfo;
		private System.Windows.Forms.ContextMenuStrip cmBold;
		private System.Windows.Forms.ToolStripMenuItem cmBoldSetting;
		private System.Windows.Forms.TextBox tbFrameRate;
		private System.Windows.Forms.Button btnFrameRate;
		private System.Windows.Forms.Button btnBoldSec;
		private System.Windows.Forms.TextBox tbBoldSec;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.DataGridView grdPrint1;
        private System.Windows.Forms.ToolStripMenuItem FileReload;
        private System.Windows.Forms.ToolStripMenuItem EditModePrint;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btnOpenEDL;
        private System.Windows.Forms.ToolStripButton btnReload;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton btnPrintPreview;
        private System.Windows.Forms.ToolStripButton btnPageSetup;
        private System.Windows.Forms.ToolStripButton btnPrint;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.Button btnDispModeChange;
		private System.Windows.Forms.Label lbDispMode;
        private System.Windows.Forms.Button btnPFrameRate;
        private System.Windows.Forms.TextBox tbPFrameRate;
        private System.Windows.Forms.Label label10;
		private System.Windows.Forms.ToolStripMenuItem EditModeEdlPrint;
		private System.Windows.Forms.ToolStripMenuItem EditModeEdlTop;
		private System.Windows.Forms.DataGridViewTextBoxColumn pClipName;
		private System.Windows.Forms.DataGridViewTextBoxColumn pInPoint;
		private System.Windows.Forms.DataGridViewTextBoxColumn pInPoint2nd;
		private System.Windows.Forms.DataGridViewTextBoxColumn pOutPoint;
		private System.Windows.Forms.DataGridViewTextBoxColumn pDuration;
		private System.Windows.Forms.DataGridViewTextBoxColumn pComment;
		private System.Windows.Forms.PageSetupDialog pageSetupDialog1;
		private System.Drawing.Printing.PrintDocument printDocument1;
		private System.Windows.Forms.PrintDialog printDialog1;
		private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.NumericUpDown tbPrintScaler;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmClipName;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmInPoint;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmOutPoint;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmDuration;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmComment;
        private System.Windows.Forms.ComboBox cmbClearText;
        private System.Windows.Forms.CheckBox cbClearText;
        private System.Windows.Forms.Button btnGo;

		


	}
}

