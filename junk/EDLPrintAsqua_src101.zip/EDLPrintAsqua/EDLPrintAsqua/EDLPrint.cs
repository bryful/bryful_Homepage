﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Printing;
using System.Drawing.Drawing2D;

namespace EDLPrintAsqua
{
	public enum PrintText
	{
		title =0,
		memo1,
		memo2,
		date,
		campany,
		Count
	}
	public class EDLPrint
	{
		//###########################################################################
		public const string CapClipName = "ClipName";
		public const string CapInPointA = "in点";
		public const string CapInPointB = "画頭のin点";
		public const string CapOutPoint = "out点";
		public const string CapDuration = "Duration";
		//###########################################################################
		public const float pSizeSS = 0.03f;
		public const float pSizeS = 0.15f;
		public const float pSizeM = 0.4f;
		public const float pSizeL = 0.7f;
		public const float pSizeLL = 0.8f;

		public const float FontSize= 14;

		public const float PrintWidth = 190;

		public const float TitleTop = 10f;
		public const float TitleLeft = 0f;
		public const float TitleWidth = 160f;
		public const float TitleHeight = 11f;

		public const float PageTop = TitleTop - 5f;
		public const float PageLeft = TitleLeft + TitleWidth;
		public const float PageWidth = PrintWidth - TitleWidth;
		public const float PageHeight =TitleHeight + 5f;

		public const float MemoLeft = TitleLeft + 3f;
		public const float MemoWidth = PrintWidth - MemoLeft;
		public const float MemoHeight = 8f;
		public const float MemoTop1 = TitleTop + TitleHeight;
		public const float MemoTop2 = MemoTop1 + MemoHeight;

		public const float InfoLeft = 2f;
		public const float InfoTop = MemoTop2 + MemoHeight;
		public const float InfoWidth = 110f;
		public const float InfoHeight = MemoHeight;

		public const float DateLeft = InfoLeft + InfoWidth;
		public const float DateTop = InfoTop;
		public const float DateWidth = (PrintWidth - 2f) - InfoWidth;
		public const float DateHeight = InfoHeight;

		public const float CaptionLeft = 0f;
		public const float CaptionTop = InfoTop + InfoHeight;
		public const float CaptionWidth = PrintWidth;
		public const float CaptionHeight = 7f;

		public const float GridTop = CaptionTop + CaptionHeight;
		public const float GridLeft = CaptionLeft;
		public const float GridWidth = CaptionWidth;
		public const float GridHeight = 6.5f;
		public const int GridCount = 35;
		public const float GridAreaHeight = GridHeight * GridCount;
		public const float GridClipNameWidth = 45f;
		public const float GridTCWidth = 7f;
		public const float GridInPointAWidth = GridTCWidth * 4;
		public const float GridInPointBWidth = GridInPointAWidth;
		public const float GridOutPointWidth = GridInPointAWidth;
		public const float GridDurationWidth = 27f;
		public const float GridCommentWidth = GridWidth - (GridClipNameWidth + GridInPointAWidth + GridInPointBWidth + GridOutPointWidth + GridDurationWidth);

		public const float GridInPointALeft = GridLeft + GridClipNameWidth;
		public const float GridInPointBLeft = GridInPointALeft + GridInPointAWidth;
		public const float GridOuPointLeft = GridInPointBLeft + GridInPointBWidth;
		public const float GridDurationLeft = GridOuPointLeft + GridOutPointWidth;
		public const float GridCommentLeft = GridDurationLeft + GridDurationWidth;

		public const float CampanyTop = GridTop + GridAreaHeight;
		public const float CampanyWidth = PrintWidth;
		public const float CampanyLeft = 0;
		public const float CampanyHeight = 7f;

		public const float PrintHeight = CampanyTop + CampanyHeight;

		//###########################################################################
		private float _pSizeSS = pSizeSS;
		private float _pSizeS = pSizeS;
		private float _pSizeM = pSizeM;
		private float _pSizeL = pSizeL;
		private float _pSizeLL = pSizeLL;

		//private float _FontSize = FontSize;

		private float _TitleTop = TitleTop;
		private float _TitleLeft = TitleLeft;
		private float _TitleWidth = TitleWidth;
		private float _TitleHeight = TitleHeight;

		private float _PageTop = PageTop;
		private float _PageLeft = PageLeft;
		private float _PageWidth = PageWidth;
		private float _PageHeight = PageHeight;

		private float _MemoLeft = MemoLeft;
		private float _MemoWidth = MemoWidth;
		private float _MemoHeight = MemoHeight;
		private float _MemoTop1 = MemoTop1;
		private float _MemoTop2 = MemoTop2;

		private float _InfoLeft = InfoLeft;
		private float _InfoTop = InfoTop;
		private float _InfoWidth = InfoWidth;
		private float _InfoHeight = InfoHeight;

		private float _DateLeft = DateLeft;
		private float _DateTop = DateTop;
		private float _DateWidth = DateWidth;
		private float _DateHeight = DateHeight;

		private float _CaptionLeft = CaptionLeft;
		private float _CaptionTop = CaptionTop;
		private float _CaptionWidth = CaptionWidth;
		private float _CaptionHeight = CaptionHeight;

		private float _GridTop = GridTop;
		private float _GridLeft = GridLeft;
		private float _GridWidth = GridWidth;
		private float _GridHeight = GridHeight;
		private float _GridAreaHeight = GridAreaHeight;
		private float _GridClipNameWidth = GridClipNameWidth;
		private float _GridTCWidth = GridTCWidth;

		private float _GridInPointAWidth = GridInPointAWidth;
		private float _GridInPointBWidth = GridInPointBWidth;
		private float _GridOutPointWidth = GridOutPointWidth;
		private float _GridDurationWidth = GridDurationWidth;
		private float _GridCommentWidth = GridCommentWidth;

		private float _GridInPointALeft = GridInPointALeft;
		private float _GridInPointBLeft = GridInPointBLeft;
		private float _GridOuPointLeft = GridOuPointLeft;
		private float _GridDurationLeft = GridDurationLeft;
		private float _GridCommentLeft = GridCommentLeft;

		private float _CampanyTop = CampanyTop;
		private float _CampanyWidth = CampanyWidth;
		private float _CampanyLeft = CampanyLeft;
		private float _CampanyHeight = CampanyHeight;

		private float _PrintHeight = PrintHeight;
		private float _PrintWidth = PrintWidth;
		
		//###########################################################################

		private EDL edl;

		private PrintDocument pd;
		private PrintDialog pdlg;
		private PageSetupDialog psdlg;
		private PrintPreviewDialog　ppdlg;

		//文字表示フォーマット
		private Font m_Font = new Font("MS UI Gothic", 8);
		private StringFormat format = new StringFormat();

		private int m_PageCount = 0;
		private float m_mX = 0.0f;
		private float m_mY = 0.0f;
		private float m_Width = 0.0f;
		private float m_Height = 0.0f;

		private float m_Scale = 1f;
		private float m_FontScale = 1f;

		private int currentPage = 1;

		private string[] pText = new string[(int)PrintText.Count];

		//-------------------------------------------------------------
		public EDLPrint(EDL e, PrintDocument d)
		{
			this.PrintDocument = d;
			this.EDL = e;
			format.Alignment = StringAlignment.Center;
			format.LineAlignment = StringAlignment.Center;
		}
		//-------------------------------------------------------------
		private void ScaleSet()
		{
		_pSizeSS = pSizeSS * m_Scale;
		_pSizeS = pSizeS * m_Scale;
		_pSizeM = pSizeM * m_Scale;
		_pSizeL = pSizeL * m_Scale;
		_pSizeLL = pSizeLL * m_Scale;

		//_FontSize = FontSize * m_Scale *m_FontScale;

		_TitleTop = TitleTop * m_Scale;
		_TitleLeft = TitleLeft * m_Scale;
		_TitleWidth = TitleWidth * m_Scale;
		_TitleHeight = TitleHeight * m_Scale;

		_PageTop = PageTop * m_Scale;
		_PageLeft = PageLeft * m_Scale;
		_PageWidth = PageWidth * m_Scale;
		_PageHeight = PageHeight * m_Scale;

		_MemoLeft = MemoLeft * m_Scale;
		_MemoWidth = MemoWidth * m_Scale;
		_MemoHeight = MemoHeight * m_Scale;
		_MemoTop1 = MemoTop1 * m_Scale;
		_MemoTop2 = MemoTop2 * m_Scale;

		_InfoLeft = InfoLeft * m_Scale;
		_InfoTop = InfoTop * m_Scale;
		_InfoWidth = InfoWidth * m_Scale;
		_InfoHeight = InfoHeight * m_Scale;

		_DateLeft = DateLeft * m_Scale;
		_DateTop = DateTop * m_Scale;
		_DateWidth = DateWidth * m_Scale;
		_DateHeight = DateHeight * m_Scale;

		_CaptionLeft = CaptionLeft * m_Scale;
		_CaptionTop = CaptionTop * m_Scale;
		_CaptionWidth = CaptionWidth * m_Scale;
		_CaptionHeight = CaptionHeight * m_Scale;

		_GridTop = GridTop * m_Scale;
		_GridLeft = GridLeft * m_Scale;
		_GridWidth = GridWidth * m_Scale;
		_GridHeight = GridHeight * m_Scale;
		_GridAreaHeight = GridAreaHeight * m_Scale;
		_GridClipNameWidth = GridClipNameWidth * m_Scale;
		_GridTCWidth = GridTCWidth * m_Scale;
		_GridInPointAWidth = GridInPointAWidth * m_Scale;
		_GridInPointBWidth = GridInPointBWidth * m_Scale;
		_GridOutPointWidth = GridOutPointWidth * m_Scale;
		_GridDurationWidth = GridDurationWidth * m_Scale;
		_GridCommentWidth = GridCommentWidth * m_Scale;

		_GridInPointALeft = GridInPointALeft * m_Scale;
		_GridInPointBLeft = GridInPointBLeft * m_Scale;
		_GridOuPointLeft = GridOuPointLeft * m_Scale;
		_GridDurationLeft = GridDurationLeft * m_Scale;
		_GridCommentLeft = GridCommentLeft * m_Scale;

		_CampanyTop = CampanyTop * m_Scale;
		_CampanyWidth = CampanyWidth * m_Scale;
		_CampanyLeft = CampanyLeft * m_Scale;
		_CampanyHeight = CampanyHeight * m_Scale;

		_PrintHeight = PrintHeight * m_Scale;
		_PrintWidth = PrintWidth * m_Scale;

		}
		//******************************************************
		private void SetFontSize(float v)
		{
			if (m_FontScale == v) return;
			float sz = FontSize * m_Scale * v;
			if (sz <= 0) sz = 1.0f;
			FontFamily ff = m_Font.FontFamily;
			FontStyle fs = m_Font.Style;
			m_Font.Dispose();
			m_Font = new Font(ff, sz, fs | FontStyle.Bold);
			m_FontScale = v;
		}

		//*******************************************************************************************************
		private void GetPrintSize()
		{
			m_Width = (pd.DefaultPageSettings.PrintableArea.Width * 25.4f / 100f);
			m_Height = (pd.DefaultPageSettings.PrintableArea.Height * 25.4f / 100f);

            //先ず横幅を合わせる。
            m_Scale = m_Width / (PrintWidth + 5f);
            float w = PrintWidth * m_Scale;
            float h = PrintHeight * m_Scale;

            if (m_Height < h)
            {
                m_Scale = m_Height / (PrintHeight + 5f);
            }

            m_Scale = m_Scale * (float)edl.PrintScaler / 100f; 

			ScaleSet();

			m_mX = (m_Width - _PrintWidth) / 2f;
			m_mY = (m_Height - _PrintHeight) / 2f;

			SetFontSize(1.0f);
			if (edl != null)
			{
				m_PageCount = edl.PrintPageCount;
				currentPage = 1;
			}
			else
			{
				m_PageCount = 0;
				currentPage = 1;
			}
			/*
			string s =
				"m_width:" + m_Width.ToString() + " m_Height:" + m_Height.ToString() + "\n" +
				"PrintWidth:" + _PrintWidth.ToString() + " PrintHeight:" + _PrintHeight.ToString() + "\n" +
				"m_Scale:" + m_Scale.ToString() +"\n"+
				"m_mX:" + m_mX.ToString() + " m_mY:" + m_mY.ToString()+"\n";
			
			s +=
				"Left:" + pd.DefaultPageSettings.Margins.Left.ToString() + "\n" +
				"Right:" + pd.DefaultPageSettings.Margins.Right.ToString() + "\n" +
				"Top:" + pd.DefaultPageSettings.Margins.Top.ToString() + "\n" +
				"Bottom:" + pd.DefaultPageSettings.Margins.Bottom.ToString() + "\n";
			
			MessageBox.Show(s);
			*/
		}
		//-------------------------------------------------------------
		public EDL EDL
		{
			get { return edl; }
			set 
			{ 
				edl = value;
				if (edl != null)
				{
					m_PageCount = edl.PrintPageCount;
				}
				else
				{
					m_PageCount = 0;
				}
			}
		}
		//-------------------------------------------------------------
		public PrintDocument PrintDocument
		{
			get { return pd; }
			set 
			{ 
				pd = value;
				if (pd != null)
				{
					pd.PrintPage += new PrintPageEventHandler(pd_PrintPage);
					if (pdlg != null) pdlg.Document = pd;
					if (psdlg != null) psdlg.Document = pd;
					if (ppdlg != null) ppdlg.Document = pd;
				}
			}
		}
		//-------------------------------------------------------------
		public PrintDialog PrintDialog
		{
			get { return pdlg;}
			set 
			{ 
				pdlg = value;
				if (pd != null) pdlg.Document = pd;
			}
		}
		//-------------------------------------------------------------
		public PageSetupDialog PageSetupDialog
		{
			get { return psdlg; }
			set 
			{
				psdlg = value;
				if (pd != null) psdlg.Document = pd;
			}
		}
		//-------------------------------------------------------------
		public PrintPreviewDialog PrintPreviewDialog
		{
			get { return ppdlg; }
			set 
			{ 
				ppdlg = value;
				if (pd != null) ppdlg.Document = pd;
			}
		}
        //-------------------------------------------------------------
        public void TextSet(PrintText id, string s)
		{
			pText[(int)id] = s.Trim(); 
		}
		//-------------------------------------------------------------
		public void ShowPreviewtDialog()
		{
			if ((pd == null) || (ppdlg == null)) return;
			GetPrintSize();
			//はじめの表示位置を指定する
			ppdlg.StartPosition = FormStartPosition.WindowsDefaultLocation;

			ppdlg.Width = (int)Math.Round(m_Width * 3);
			ppdlg.Height = (int)Math.Round(m_Height * 3);
			//ppd.Width = 1024;
			//ppd.Height = 900;
			//ppd.PrintPreviewControl.Zoom = 1;
			ppdlg.ShowDialog();

		}
		//******************************************************
		public void ShowPageSetup()
		{
			if ((pd == null) || (psdlg == null)) return;
			GetPrintSize();
			if (psdlg.ShowDialog() == DialogResult.OK)
			{
				GetPrintSize();
			}

		}
        //******************************************************
        public void ShowPrint()
        {
            if ((pd == null) || (pdlg == null)) return;
            GetPrintSize();
            if (pdlg.ShowDialog() == DialogResult.OK)
            {
                GetPrintSize();
                pd.Print();
            }

        }
        //*******************************************************************************************************
		private void pd_PrintPage(object sender, PrintPageEventArgs e)
		{
			e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
			e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
			e.Graphics.PageUnit = GraphicsUnit.Millimeter;
			
			if (e.PageSettings.PrinterSettings.PrintRange == PrintRange.SomePages && currentPage == 1)
			{
				currentPage = e.PageSettings.PrinterSettings.FromPage;
			}
			//-----
			DrawTexts(e.Graphics);

            for (int i = 0; i < GridCount; i++)
            {
                int p = i + (currentPage-1) * GridCount;
                if (p < edl.KYPItems.Count)
                {
                    DrawClip(e.Graphics, p);
                }
            }

			DrawGrid(e.Graphics);
			//----
			//次のページがあるか調べる
			if (currentPage >= m_PageCount ||
				(e.PageSettings.PrinterSettings.PrintRange == PrintRange.SomePages &&
				e.PageSettings.PrinterSettings.ToPage <= currentPage))
			{
				//次のページがないことを通知する
				e.HasMorePages = false;
				currentPage = 1;
			}
			else
			{
				e.HasMorePages = true;
				currentPage++;
			}

		}
		//*******************************************************************************************************
		private void DrawGrid(Graphics g)
		{
			Pen p = new Pen(Color.Black);
			SolidBrush b = new SolidBrush(Color.Black);
			try
			{
				float x0 =  m_mX;
				float x1 = x0 + _PrintWidth;
				float y0 = _TitleTop + _TitleHeight + m_mY - ( 1f * m_Scale);
				float y1;
                p.Width = _pSizeM;
                g.DrawLine(p, x0, y0, x1, y0);

				//キャプション
				p.Width = _pSizeL;
				x0 = _CaptionLeft + m_mX;
				x1 = x0 + _GridWidth;
				y0 = _CaptionTop + m_mY;
				g.DrawRectangle(p, x0, y0, _CaptionWidth, _GridAreaHeight + _CaptionHeight);
				y0 += _CaptionHeight;
				g.DrawLine(p,x0,y0,x1,y0);

				//横線を描く
				for (int i = 1; i < GridCount; i++)
				{
					if ((i % 5) == 0)
					{
						p.Width = _pSizeL;
					}
					else
					{
						p.Width = _pSizeS;
					}

					y0 = m_mY + _GridTop + _GridHeight * i;
					g.DrawLine(p, x0, y0, x1, y0);

				}
				//縦線を描く
				Color gray = Color.Black;
				y0 = _CaptionTop + m_mY;
				y1 = y0 + _GridAreaHeight + _CaptionHeight;
				p.Width = _pSizeM;
				x0 = m_mX + _GridInPointALeft;
				g.DrawLine(p, x0, y0, x0, y1);
				float yy0 = _GridTop + m_mY;
				p.Width = _pSizeSS;
				p.Color = gray;
				for (int i = 0; i < 4; i++)
				{
					x0 += _GridTCWidth;
					g.DrawLine(p, x0, yy0, x0, y1);
				}
				p.Width = _pSizeM;
				p.Color = Color.Black;
				x0 = m_mX + _GridInPointBLeft;
				g.DrawLine(p, x0, y0, x0, y1);
				p.Width = _pSizeSS;
				p.Color = gray;
				for (int i = 0; i < 4; i++)
				{
					x0 += _GridTCWidth;
					g.DrawLine(p, x0, yy0, x0, y1);
				}
				p.Width = _pSizeM;
				p.Color = Color.Black;
				x0 = m_mX + _GridOuPointLeft;
				g.DrawLine(p, x0, y0, x0, y1);
				p.Width = _pSizeSS;
				p.Color = gray;
				for (int i = 0; i < 4; i++)
				{
					x0 += _GridTCWidth;
					g.DrawLine(p, x0, yy0, x0, y1);
				}

				p.Width = _pSizeM;
				p.Color = Color.Black;
				x0 = m_mX + _GridDurationLeft;
				g.DrawLine(p, x0, y0, x0, y1);
				x0 = m_mX + _GridCommentLeft;
				g.DrawLine(p, x0, y0, x0, y1);

				format.Alignment = StringAlignment.Center;
				format.LineAlignment = StringAlignment.Center;
				
				RectangleF rct = new RectangleF(_CaptionLeft + m_mX, _CaptionTop + m_mY + 2, _GridClipNameWidth, _CaptionHeight-2);
				SetFontSize(1.0f);
                strDraw(g, CapClipName, rct, b, format);
				rct = new RectangleF(_GridInPointALeft+ m_mX , _CaptionTop + m_mY + 2, _GridInPointAWidth, _CaptionHeight - 2);
                strDraw(g, CapInPointA, rct, b, format);
                rct = new RectangleF(_GridInPointBLeft + m_mX, _CaptionTop + m_mY + 2, _GridInPointBWidth, _CaptionHeight - 2);
	            strDraw(g, CapInPointB, rct, b, format);
                rct = new RectangleF(_GridOuPointLeft + m_mX, _CaptionTop + m_mY + 2, _GridOutPointWidth, _CaptionHeight - 2);
			    strDraw(g, CapOutPoint, rct, b, format);
                rct = new RectangleF(_GridDurationLeft + m_mX, _CaptionTop + m_mY + 2, _GridDurationWidth, _CaptionHeight - 2);
				SetFontSize(1f);
                strDraw(g, CapDuration, rct, b, format);

                format.Alignment = StringAlignment.Far;
                format.LineAlignment = StringAlignment.Far;
                SetFontSize(0.8f);
                for (int i = 1; i <= 7; i++)
                {
                    rct = new RectangleF(_GridLeft - 50f + m_mX, _GridTop + _GridHeight * (i*5 - 1) + m_mY, 50f, _GridHeight);
                    strDraw(g, (i*5).ToString(), rct, b, format);
                 
                }
            }
			finally
			{
				p.Dispose();
				b.Dispose();
			}

		}
		//*******************************************************************************************************
		private string Info()
		{
			if (edl == null) return "";
			string s = "";

			s += "Rec:" + ((int)edl.FrameRate).ToString() + "Fps";
			if (edl.FrameRate != edl.PrintFrameRate)
			{
				s += " Disp:" + ((int)edl.PrintFrameRate).ToString() + "Fps";
			}
			s += " 収録秒数:" + edl.KPYlastTime.SecFrame;
			s += " Clip:" + edl.ClipCount.ToString() + ", " + edl.ClipTime.SecFrame.ToString() + " (bold:" + edl.BoldTime.SecFrame + ")";
			s += " RollBold:" + edl.RollCount.ToString() + ", " + edl.RollTime.SecFrame.ToString();
			return s;
		}
        //*******************************************************************************************************
        private void strDraw(Graphics g, string s, RectangleF rct,SolidBrush b,StringFormat fmt)
        {
            float bak = m_FontScale;

            float ss = 1.0f;
            //縦幅
            SizeF sz = g.MeasureString(s, m_Font);
            if (sz.Height > rct.Height)
            {
                ss = m_FontScale * rct.Height / sz.Height;
                SetFontSize(ss);
            }
            sz = g.MeasureString(s, m_Font);
            if (sz.Width > rct.Width)
            {
                ss = m_FontScale * rct.Width / sz.Width;
                SetFontSize(ss);
                g.DrawString(s, m_Font, b, rct, fmt);
            }
            else
            {
                g.DrawString(s, m_Font, b, rct, format);
            }
            SetFontSize(bak);
        }
        //*******************************************************************************************************
        private void DrawClip(Graphics g, int idx)
        {
            if (edl == null) return;
            SolidBrush b = new SolidBrush(Color.Black);
            try
            {
                int p = idx % GridCount;
                float y = _GridTop + _GridHeight * p + m_mY;
                float l = _GridLeft + m_mX + 2f * m_Scale;
                float t = y + 1.5f * m_Scale;
                float h = _GridHeight - 1.5f * m_Scale;
                float w = _GridClipNameWidth - 2f * m_Scale;

                format.Alignment = StringAlignment.Near;
                format.LineAlignment = StringAlignment.Far;
                //ClipName
                RectangleF rct = new RectangleF(l, t, w, h);

                SetFontSize(0.9f);
                strDraw(g,edl.KYPClipName(idx),rct,b,format);

                float offX = 0.5f * m_Scale;
                float offY = 0.7f * m_Scale;
                //inPoint
                SetFontSize(0.9f);
                format.Alignment = StringAlignment.Center;
                format.LineAlignment = StringAlignment.Center;
                Timecode tc;
                tc = edl.KYPItems[idx].inPoint;
                t = y + offY;
                l = _GridInPointALeft + m_mX + offX;
                w = _GridTCWidth - offX;
                h = _GridHeight - offY;
                rct = new RectangleF(l, t, w, h);
                g.DrawString(tc.HourS, m_Font, b, rct, format);
                rct = new RectangleF(l + _GridTCWidth * 1, t, w, h);
                g.DrawString(tc.MinS, m_Font, b, rct,format);
                rct = new RectangleF(l + _GridTCWidth * 2, t, w, h);
                g.DrawString(tc.SecS, m_Font, b, rct, format);
                rct = new RectangleF(l + _GridTCWidth * 3, t, w, h);
                g.DrawString(tc.FrameS, m_Font, b, rct, format);


                if (edl.KYPItems[idx].WithBold == true)
                {
                    l = _GridInPointBLeft + m_mX + offX;
                    tc = edl.KYPItems[idx].BoldOutPoint;
                    rct = new RectangleF(l + _GridTCWidth * 0, t, w, h);
                    g.DrawString(tc.HourS, m_Font, b, rct, format);
                    rct = new RectangleF(l + _GridTCWidth * 1, t, w, h);
                    g.DrawString(tc.MinS, m_Font, b, rct, format);
                    rct = new RectangleF(l + _GridTCWidth * 2, t, w, h);
                    g.DrawString(tc.SecS, m_Font, b, rct, format);
                    rct = new RectangleF(l + _GridTCWidth * 3, t, w, h);
                    g.DrawString(tc.FrameS, m_Font, b, rct, format);
                }
                l = _GridOuPointLeft + m_mX + offX;
                tc = edl.KYPItems[idx].outPoint;
                rct = new RectangleF(l , t, w, h);
                g.DrawString(tc.HourS, m_Font, b, rct, format);
                rct = new RectangleF(l + _GridTCWidth * 1, t, w, h);
                g.DrawString(tc.MinS, m_Font, b, rct, format);
                rct = new RectangleF(l + _GridTCWidth * 2, t, w, h);
                g.DrawString(tc.SecS, m_Font, b, rct, format);
                rct = new RectangleF(l + _GridTCWidth * 3, t, w, h);
                g.DrawString(tc.FrameS, m_Font, b, rct, format);

                tc.TotalDuration = edl.KYPItems[idx].Duration;
                string s = tc.TotalFrame.ToString() + "(" + tc.SecFrame + ")";
                rct = new RectangleF(_GridDurationLeft + m_mX, _GridTop +(_GridHeight *p) + m_mY, _GridDurationWidth, _GridHeight);
                //SetFontSize(0.6f);
                format.Alignment = StringAlignment.Far;
                format.LineAlignment = StringAlignment.Far;
                g.DrawString(s, m_Font, b, rct, format);

            }
            finally
            {
                b.Dispose();
            }
        }
        //*******************************************************************************************************
		private void DrawTexts(Graphics g)
		{
			SolidBrush b = new SolidBrush(Color.Black);
			try
			{
				format.Alignment = StringAlignment.Near;
				format.LineAlignment = StringAlignment.Far;
				RectangleF rct;
				//Title
				if (pText[(int)PrintText.title] != "")
				{
					rct = new RectangleF(_TitleLeft + m_mX, _TitleTop + m_mY, _TitleWidth, _TitleHeight);
					SetFontSize(1.8f);
                    strDraw(g, pText[(int)PrintText.title], rct, b, format);
				}
				if (pText[(int)PrintText.memo1] != "")
				{
					rct = new RectangleF(_MemoLeft + m_mX, _MemoTop1 + m_mY, _MemoWidth, _MemoHeight);
					SetFontSize(1.4f);
                    strDraw(g, pText[(int)PrintText.memo1], rct, b, format);
				}
				if (pText[(int)PrintText.memo2] != "")
				{
					rct = new RectangleF(_MemoLeft + m_mX, _MemoTop2 + m_mY, _MemoWidth, _MemoHeight);
					SetFontSize(1.4f);
                    strDraw(g, pText[(int)PrintText.memo2], rct, b, format);
                }
				if (pText[(int)PrintText.date] != "")
				{
					format.Alignment = StringAlignment.Far;
					rct = new RectangleF(_DateLeft + m_mX, _DateTop + m_mY, _DateWidth, _DateHeight);
					SetFontSize(1.2f);
                    strDraw(g, pText[(int)PrintText.date], rct, b, format);
                    format.Alignment = StringAlignment.Near;

				}
                if (edl.IsPrintInfo == true)
                {
                    string infoStr = Info();
                    if (infoStr != "")
                    {
                        format.Alignment = StringAlignment.Near;
                        rct = new RectangleF(_InfoLeft + m_mX, _InfoTop + m_mY + 2, _InfoWidth, _InfoHeight - 2);
                        SetFontSize(0.7f);
                        strDraw(g, infoStr, rct, b, format);
                        format.Alignment = StringAlignment.Near;
                    }
                }

				if (pText[(int)PrintText.campany] != "")
				{
					format.Alignment = StringAlignment.Far;
					format.LineAlignment = StringAlignment.Near;
					rct = new RectangleF(_CampanyLeft + m_mX, _CampanyTop + m_mY, _CampanyWidth, _CampanyHeight);
					SetFontSize(1.3f);
                    strDraw(g, pText[(int)PrintText.campany], rct, b, format);
					format.Alignment = StringAlignment.Near;
					format.LineAlignment = StringAlignment.Far;
				}
                if (m_PageCount > 1)
                {
                    string s = "(" + currentPage.ToString() + "/" + m_PageCount.ToString() + ")";
                    format.Alignment = StringAlignment.Far;
                    rct = new RectangleF(_PageLeft + m_mX, _PageTop + m_mY, _PageWidth, _PageHeight);
                    SetFontSize(2f);
                    strDraw(g, s, rct, b, format);
                }
			}
			finally
			{
				b.Dispose();

			}
		}
	}
}
