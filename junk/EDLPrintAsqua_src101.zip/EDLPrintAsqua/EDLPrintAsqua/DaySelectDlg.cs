﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EDLPrintAsqua
{
    public partial class DaySelectDlg : Form
    {
        private string[] weeks = new string[]
        {
            "(日)",
            "(月)",
            "(火)",
            "(水)",
            "(木)",
            "(金)",
            "(土)"
        };
        //-----------------------------------------------------
        public DaySelectDlg()
        {
            InitializeComponent();
            tbText.Text = MakeDay();
        }
        //-----------------------------------------------------
        private string MakeDay()
        {
            DateTime now = DateTime.Now;
            if (rbDayYestaday.Checked == true)
            {
                now = now.AddDays(-1);
            }
            else if (rbDay4.Checked == true)
            {
                if (now.Hour <= 7)
                {
                    now = now.AddDays(-1);
                }
            }
            string s = "";
            s += now.Year.ToString() + "年";
            s += now.Month.ToString() + "月";
            s += now.Day.ToString() + "日";
            if (cbAddWeek.Checked == true)
            {
                s += weeks[(int)now.DayOfWeek];
            }
            return s;
        }
        //-----------------------------------------------------
        private void rbDay_Click(object sender, EventArgs e)
        {
            tbText.Text = MakeDay();
        }
        //-----------------------------------------------------
        private void cbAddWeek_Click(object sender, EventArgs e)
        {
            tbText.Text = MakeDay();
        }
        //-----------------------------------------------------
        public string DayStr
        {
            get { return tbText.Text; }
        }
        //-----------------------------------------------------
    }
}
