﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EDLPrintAsqua
{
	public partial class TimecodeEdit : UserControl
	{
		private Timecode tc = new Timecode(FrameRates.fr24);

		private bool refFlag = false;
		private TextBox[] tb = new TextBox[4];
        private bool _err = false;

        public event EventHandler TimeCodeChanged;
		public TimecodeEdit()
		{
			InitializeComponent();
			tb[0] = tbH; tbH.Tag = 0;
			tb[1] = tbM; tbM.Tag = 1;
			tb[2] = tbS; tbS.Tag = 2;
			tb[3] = tbF; tbF.Tag = 3;
			

		}
        //----------------------------------------------------------------
        protected virtual void OnTimeCodeChanged(EventArgs e)
        {
            if (TimeCodeChanged != null)
            {
                TimeCodeChanged(this, e);
            }
        }
 
		//-----------------------------------------------
		public Timecode Timecode
		{
			get { return tc; }
			set { ToTB(value); }
		}
		//-----------------------------------------------
		public void ToTB(Timecode t)
		{
			bool b = refFlag;
			refFlag = true;
			tc.Assign(t);
			tbH.Text = tc.HourS;
			tbM.Text = tc.MinS;
			tbS.Text = tc.SecS;
			tbF.Text = tc.FrameS;
			refFlag = b;
		}
        //-----------------------------------------------
        public void IncFrame()
        {
            if (chkTimeCode() == true)
            {
                tc.TotalFrame += 1;
                bool b = refFlag;
                refFlag = true;
                tbH.Text = tc.HourS;
                tbM.Text = tc.MinS;
                tbS.Text = tc.SecS;
                tbF.Text = tc.FrameS;
                refFlag = b;
            }
        }
        //-----------------------------------------------
        public void DecFrame()
        {
            if (chkTimeCode() == true)
            {
                if (tc.TotalFrame > 0)
                {
                    tc.TotalFrame -= 1;
                    bool b = refFlag;
                    refFlag = true;
                    tbH.Text = tc.HourS;
                    tbM.Text = tc.MinS;
                    tbS.Text = tc.SecS;
                    tbF.Text = tc.FrameS;
                    refFlag = b;
                }
            }
        }

		//-----------------------------------------------
		private void tbH_KeyPress(object sender, KeyPressEventArgs e)
		{
			if ((e.KeyChar < '0' || e.KeyChar > '9') && (e.KeyChar != '\b'))
			{
				e.Handled = true;
				//e.KeyChar = (char)Keys.None;
			}
			else if (e.KeyChar == '\b')
			{
			}
        }

		//-----------------------------------------------
        private int ChkValue(string value,int maxvalue)
        {
            int t = -1;
            if (int.TryParse(value, out t) == true)
            {
                if ((t < maxvalue) && (t >= 0))
                {
                    return t;
                }
            }
            return -1;
        }
        //-----------------------------------------------
        public bool chkTimeCode()
        {
            _err = false;
            int v = 0;
            v = ChkValue(tb[0].Text, 24);
            if (v>=0)
            {
                tc.Hour = v;
            }
            else
            {
                _err = true;
            }
            v = ChkValue(tb[1].Text, 60);
            if (v >= 0)
            {
                tc.Min = v;
            }
            else
            {
                _err = true;
            }
            v = ChkValue(tb[2].Text, 60);
            if (v >= 0)
            {
                tc.Sec = v;
            }
            else
            {
                _err = true;
            }
            v = ChkValue(tb[3].Text, (int)tc.FrameRate);
            if (v >= 0)
            {
                tc.Frame = v;
            }
            else
            {
                _err = true;
            }
            return !_err;
        }
		//-----------------------------------------------
		public bool ReadOnly
		{
			get { return tb[0].ReadOnly; }
			set
			{
				tb[0].ReadOnly =
				tb[1].ReadOnly =
				tb[2].ReadOnly =
				tb[3].ReadOnly = value;
			}
		}
		//-----------------------------------------------
        public bool Err
        {
            get { return !chkTimeCode(); }
        }
        //-----------------------------------------------
        private void tbH_TextChanged(object sender, EventArgs e)
        {
            if (refFlag == true) return;
            OnTimeCodeChanged(new EventArgs());
        }
        //-----------------------------------------------
    }
}
