﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EDLPrintAsqua
{
    public partial class StartTimeDlg : Form
    {
        public StartTimeDlg()
        {
            InitializeComponent();
            chk();
        }
        //--------------------------------------------------------
        public Timecode StartTime
        {
            get { return tcNew.Timecode; }
            set 
            { 
                tcNew.Timecode = tcNow.Timecode = value;
                chk();
            }
        }
        //--------------------------------------------------------
        public Timecode StartTimeOrg
        {
            get { return tcOrg.Timecode; }
            set { tcOrg.Timecode = value; }
        }
        //--------------------------------------------------------
        private void tcNew_TimeCodeChanged(object sender, EventArgs e)
        {
           chk();
        }
        //--------------------------------------------------------
        private void chk()
        {
            btnInc.Enabled =
                btnDec.Enabled =
                    btnOK.Enabled = !tcNew.Err;
        }
        //--------------------------------------------------------
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (btnOK.Enabled == true)
           tcNew.IncFrame();
        }

        private void btnDec_Click(object sender, EventArgs e)
        {
            if (btnOK.Enabled == true)
                tcNew.DecFrame();

        }
        //--------------------------------------------------------
    }
}
