﻿namespace EDLPrintAsqua
{
    partial class FrameRateDlg
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rb30 = new System.Windows.Forms.RadioButton();
            this.rb24 = new System.Windows.Forms.RadioButton();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancrl = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rb30);
            this.groupBox1.Controls.Add(this.rb24);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(196, 68);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "FrameRate";
            // 
            // rb30
            // 
            this.rb30.AutoSize = true;
            this.rb30.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.rb30.Location = new System.Drawing.Point(27, 40);
            this.rb30.Name = "rb30";
            this.rb30.Size = new System.Drawing.Size(121, 16);
            this.rb30.TabIndex = 1;
            this.rb30.Text = "60i ( 29.97 fps )";
            this.rb30.UseVisualStyleBackColor = true;
            // 
            // rb24
            // 
            this.rb24.AutoSize = true;
            this.rb24.Checked = true;
            this.rb24.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.rb24.Location = new System.Drawing.Point(27, 18);
            this.rb24.Name = "rb24";
            this.rb24.Size = new System.Drawing.Size(131, 16);
            this.rb24.TabIndex = 0;
            this.rb24.TabStop = true;
            this.rb24.Text = "24p ( 23.976 fps )";
            this.rb24.UseVisualStyleBackColor = true;
            // 
            // btnOK
            // 
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnOK.Location = new System.Drawing.Point(39, 88);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 1;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            // 
            // btnCancrl
            // 
            this.btnCancrl.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancrl.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancrl.Location = new System.Drawing.Point(131, 88);
            this.btnCancrl.Name = "btnCancrl";
            this.btnCancrl.Size = new System.Drawing.Size(75, 23);
            this.btnCancrl.TabIndex = 2;
            this.btnCancrl.Text = "Cancel";
            this.btnCancrl.UseVisualStyleBackColor = true;
            // 
            // FrameRateDlg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(218, 123);
            this.ControlBox = false;
            this.Controls.Add(this.btnCancrl);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrameRateDlg";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FrameRateDlg";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rb30;
        private System.Windows.Forms.RadioButton rb24;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancrl;
    }
}