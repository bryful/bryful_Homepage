﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace EDLPrintAsqua
{
    //*************************************************************************
    public class E
    {
        public const long HMS = 60;
        public const char COLON = ':';
        public const char SP = ' ';

        public const double defBoldDuration = (double)8 / (double)24;

        public const string TitleTag = "TITLE:";
        public const string FCM = "FCM:";
        public const string FCM24Head = "*FCM";
		public const string FCM24_24P = "24P";

		public const string PR_RELL = "REEL";
		public const string PR_CLIP = "CLIP";

		public const string FCP_CLIP = "* FROM CLIP NAME:";
        public const string FCP_STILL = "* FROM CLIP IS A STILL";

    }
    //*************************************************************************
    public enum EDLTarget
    {
        FCP = 0,
        PrCs3,
        PrCS5
    }
    //*************************************************************************
    public class EDL
    {
		//private List<ClipEDL> EDLItems_Bak = new List<ClipEDL>();
		public List<ClipEDL> EDLItems = new List<ClipEDL>();
		public List<ClipKYP> KYPItems = new List<ClipKYP>();
        private FrameRates _FrameRate = FrameRates.fr24;

        private FrameRates _PrintFrameRate = FrameRates.fr24;

		private double _BoldDuration = 8f/24f;
        public String Title = "";

		private Timecode _StartTime = new Timecode(FrameRates.fr24);
        
        private bool _IsPrintCLipExt = true;
        public bool IsPrintInfo = false;
        public int PrintScaler = 100;
        public bool IsClearText = false;
        public string ClearText = "";

        private int _RollCount = 0;
        private int _ClipCount = 0;
        private Timecode _ClipTime = new Timecode(FrameRates.fr24);
        private Timecode _BoldTime = new Timecode(FrameRates.fr24);
        private Timecode _RollTime = new Timecode(FrameRates.fr24);

        //---------------------------------------------------
        public EDL()
        {
        }
        //---------------------------------------------------
        public int EDLCount
        {
            get { return EDLItems.Count; }
        }
		//---------------------------------------------------
		public int PrintCount
		{
			get{return KYPItems.Count;}
		}
		//---------------------------------------------------
		public int PrintPageCount
		{
			get {
				if (KYPItems.Count <= 0) return 0;
				int pc = KYPItems.Count / EDLPrint.GridCount;
				if ((KYPItems.Count % EDLPrint.GridCount) != 0) pc++;
				return pc;
			}
		}
		//---------------------------------------------------
		public void EDLClear()
		{
			EDLItems.Clear();
			Title = "";
			_FrameRate = FrameRates.fr24;
			_BoldDuration = 8 / 24;

		}
		//---------------------------------------------------
		public string DispClipInfo(int idx)
		{
			if ((idx < 0) || (idx >= EDLItems.Count)) return string.Empty;
			string s = EDLItems[idx].ClipName + "\t";
			//s += Items[idx].ClipIn.Code + " / " + Items[idx].ClipOut.Code + "\t";
			s += EDLItems[idx].TimeIn.Code + " / " + EDLItems[idx].TimeOut.Code + "\t";
			s += EDLItems[idx].ClipFrame.ToString() + "\t";
			s += EDLItems[idx].ClipStatusInfo + "\t";

			return s;
		}
		//---------------------------------------------------
		public string[] ClipInfo(int idx)
		{
			if ((idx < 0) || (idx >= EDLItems.Count)) return null;
			string[] ret = new string[6];
			ret[0] = EDLItems[idx].ClipName;
			ret[1] = EDLItems[idx].TimeIn.Code;
			ret[2] = EDLItems[idx].TimeOut.Code;
			ret[3] = EDLItems[idx].ClipFrame.ToString();
			ret[4] = EDLItems[idx].ClipStatusInfo;
			ret[5] = "";
			return ret;
		}
		//---------------------------------------------------
        public FrameRates FrameRate
        {
            get { return _FrameRate; }
			set
			{
                if (_FrameRate == value) return;
				_FrameRate = value;
				if (EDLItems.Count > 0)
				{
					for (int i = 0; i < EDLItems.Count; i++)
					{
						EDLItems[i].FrameRate = value;
					}
				}
				_StartTime.FrameRate = value;
			}
        }
        //---------------------------------------------------
        public FrameRates PrintFrameRate
        {
            get { return _PrintFrameRate; }
            set
            {
                if (_PrintFrameRate == value) return;
                _PrintFrameRate = value;
                if (KYPItems.Count > 0)
                {
                    for (int i = 0; i < KYPItems.Count; i++)
                    {
                        KYPItems[i].FrameRate = value;
                    }
                }
            }
        }
        //---------------------------------------------------
		public int BoldFrame
		{
			get { return (int)Math.Round( _BoldDuration * (int)_FrameRate); }

			set
			{
                double bd = value / (int)_FrameRate;
                if (_BoldDuration == bd) return;
				_BoldDuration = bd;
				if (EDLItems.Count > 0)
				{
					for (int i = 0; i < EDLItems.Count; i++)
					{
						EDLItems[i].BoldDuration = _BoldDuration;
					}
				}
			}
		}
		//---------------------------------------------------
		public double BoldDuration
		{
			get { return _BoldDuration; }

			set
			{
                if (_BoldDuration == value) return;
				_BoldDuration = value;
				if (EDLItems.Count > 0)
				{
					for (int i = 0; i < EDLItems.Count; i++)
					{
						EDLItems[i].BoldDuration = _BoldDuration;
					}
				}
			}
		}
		//---------------------------------------------------
		public void setBoldDurationAndFrameRate(FrameRates fps, double bd)
		{
				_FrameRate = fps;
				_BoldDuration = bd;
				if (EDLItems.Count > 0)
				{
					for (int i = 0; i < EDLItems.Count; i++)
					{
						EDLItems[i].FrameRate = fps;
						EDLItems[i].BoldDuration = bd;
					}
				}

		}
		//---------------------------------------------------
		public Timecode StartTime
		{
            get { return _StartTime;}
            set { _StartTime = value;}
		}
        //---------------------------------------------------
        public Timecode StartTimeOrg
        {
            get 
            {
                if (EDLItems.Count > 0)
                {
                    return EDLItems[0].TimeIn;
                }
                else
                {
                    return new Timecode(_FrameRate);
                }
            }
        }
        //---------------------------------------------------
        public bool IsPrintClipExt
        {
            get { return _IsPrintCLipExt; }
            set
            {
                _IsPrintCLipExt = value;
             
            }
        }
        //---------------------------------------------------
        //数字文字列か識別
        public bool IsNumber(string s, ref long value)
        {
            value = -1;
            if ((s == null) || (s == string.Empty)) return false;
            string ss = s.Trim();
            int l = ss.Length;
            if (l <= 0) return false;
            for (int i = 0; i < l; i++)
            {
                char c = ss[i];
                if ((c < '0') || (c > '9'))
                {
                    return false;
                }
            }
            value = long.Parse(ss);
            return true;
        }
  
        //---------------------------------------------------
        /*
         * タイトルを獲得
         */
        private string getTitle(string[] lines)
        {
            int l = lines.Length;
            if (l <= 0) return string.Empty;
            foreach (string s in lines)
            {
                string ss = s.Trim();
                if (ss == string.Empty) continue;
                if (ss.IndexOf(E.TitleTag, 0) == 0)
                {
                    //1個見つかったら終わり
                    return ss.Substring(E.TitleTag.Length).Trim();
                }
            }
            return string.Empty;
        }
        //---------------------------------------------------
        // FCMがあればFinalCutとする
        private bool IsFCP(string [] lines)
        {
            int l = lines.Length;
            if (l <= 0) return false;
            foreach (string s in lines)
            {
                string ss = s.Trim();
                if (ss == string.Empty) continue;
				int idx = ss.IndexOf(E.FCM, 0); 
                if ( (idx>=0) &&(idx<=1)  )
                {
                    return true;
                }
            }
            return false;
        }
		//---------------------------------------------------
		private FrameRates GetFrameRateFromFCP(string[] lines)
		{
			int l = lines.Length;
			if (l <= 0) return FrameRates.fr30;
			foreach (string s in lines)
			{
				string ss = s.Trim();
				if (ss == string.Empty) continue;
				if (ss.IndexOf(E.FCM24Head, 0) == 0)
				{
					if (ss.IndexOf(E.FCM24_24P, 0) > 0) return FrameRates.fr24;
				}
			}
			return FrameRates.fr30;
		}
		//---------------------------------------------------
        private bool IsTimeline(string s)
        {
            string ss = s.Trim();
            if (ss.Length < 3) return false;
            for (int i = 0; i < 3; i++)
            {
                if ((ss[i] < '0') || (ss[i] > '9')) return false;
            }
            return true;
        }
        //---------------------------------------------------
        private string TrimSpace(string s)
        {
            string ss = s.Trim();
            if (ss == string.Empty) return string.Empty;
            int l = ss.Length;
            if (l <= 3) return ss;
            string ret = ss[0].ToString();

            for (int i = 1; i < l; i++)
            {
                if ( !((ss[i] == E.SP)&&(ss[i] == ss[i-1])) )
                {
                    ret += ss[i].ToString();
                }
            }
            return ret;
        }
		//---------------------------------------------------
		private string GetClipName(string[] lines, int StartIdx)
		{
			int l = lines.Length;
			if ( (l <= 0)||(StartIdx<0)||(StartIdx>=l)) return string.Empty;

			for (int i = StartIdx; i < l; i++)
			{
				string ln = lines[i];
                //次のクリップがきたら終了
				if (IsTimeline(ln) == true) return string.Empty;
                //REEL AX IS CLIP BS3_13_131_v1_0001.png
				if ( ln.IndexOf(E.PR_RELL) == 0) // REEL
				{
					int c = ln.IndexOf(E.PR_CLIP); //CLIP
					if (c < 0) return string.Empty;
					c += E.PR_CLIP.Length;

					return ln.Substring(c).Trim();

                }
                else if (ln.IndexOf(E.FCP_CLIP) == 0)
                {
                    return ln.Substring(E.FCP_CLIP.Length).Trim();
                }

			}
			return string.Empty;
		}
        //---------------------------------------------------
        private bool GetIsStill(string[] lines, int StartIdx)
        {
            int l = lines.Length;
            if ((l <= 0) || (StartIdx < 0) || (StartIdx >= l)) return false;

            for (int i = StartIdx; i < l; i++)
            {
                string ln = lines[i];
                //次のクリップがきたら終了
                if (IsTimeline(ln) == true) return false;
                if (ln.IndexOf(E.FCP_STILL) == 0)
                {
                    return true;
                }

            }
            return false;
        }
		//---------------------------------------------------
		private List<ClipEDL> GetTimeLinesPr(string[] lines, FrameRates fps)
        {
			List<ClipEDL> cl = new List<ClipEDL>();
			int l = lines.Length;
			if (l <= 0) return cl;

			int i = 0;
			while (i < l)
			{
				string line = TrimSpace(lines[i]); i++;
				if (IsTimeline(line) == false) continue;

				string[] sa = line.Split(E.SP);
				int cnt = sa.Length;
				if (cnt < 5) continue;

				ClipEDL clp = new ClipEDL(fps);
				clp.BoldDuration = _BoldDuration;
				clp.NumS = sa[0];
				clp.ClipIn.Code = sa[cnt - 4];
				clp.ClipOut.Code = sa[cnt - 3];
				clp.TimeIn.Code = sa[cnt - 2];
				clp.TimeOut.Code = sa[cnt - 1];
				clp._ClipName = GetClipName(lines, i); i++;
                clp.SetIsStill(GetIsStill(lines, i));
                if (clp._ClipName != string.Empty) cl.Add(clp);
			}

			return cl;
        }
  	//---------------------------------------------------
		public bool LoadFromFile(string path,FrameRates fr, double bd)
        {
			//初期化
            EDLItems.Clear();
            Title = "";
           
			//読み込み
            if (File.Exists(path) == false) return false;   
            string[] linesS = File.ReadAllLines(path, Encoding.GetEncoding(932));
            int SL = linesS.Length;
			if (SL <= 0) return false;

			//空行を削除
			string [] lines = new string[SL];
			int p = 0;
			for (int i = 0; i < SL; i++)
			{
				string ss = linesS[i].Trim();
				if (ss != string.Empty)
				{
					lines[p] = ss;
					p++;
				}
			}
			if (p != SL) Array.Resize(ref lines, p);


            //EDLタイトル
            string t = getTitle(lines);
            if (t == string.Empty) return false;
 
            //FinalCutか？
            List<ClipEDL> cs;
			FrameRates fps = FrameRates.fr24;

			if (IsFCP(lines))
            {
				fps = GetFrameRateFromFCP(lines);
            }
            else
            {
				fps = fr;
            }
            _BoldDuration = bd;
            cs = GetTimeLinesPr(lines, fps);

            if (cs.Count > 0)
            {
				EDLClear();
                foreach (ClipEDL c in cs)
                {
					c.ChkIsStill();
                    EDLItems.Add(c);
                }
                _FrameRate = fps;
                _PrintFrameRate = fps;
                _BoldDuration = bd;
                Title = t;
				_StartTime.Assign(EDLItems[0].TimeIn);
				ChkStatus();
				PrintListup();

                return true;
            }
            else
            {
                return false;
            }


        }
		//-------------------------------------
		public void ChkStatus()
		{
			if (EDLItems.Count <= 0) return;
			int Len = EDLItems.Count; 
			//最初はロールボールドか？
			if (EDLItems[0].IsStill == true)
			{
				//登録が1個だけ
				if (Len == 1)
				{
					EDLItems[0].ClipStatus = ClipStatus.Still;
					return;
				}
				else
				{
					//ボールド秒数より長ければロール
					if (EDLItems[0].ClipDuration > _BoldDuration)
					{
						EDLItems[0].ClipStatus = ClipStatus.RollBold;
					}
					else
					{
						EDLItems[0].ClipStatus = ClipStatus.CutBold;
					}
				}
			}
			int idx = 1;
			if (EDLItems[0].ClipStatus != ClipStatus.RollBold)
			{
				idx = 0;
			}
			while (idx < Len)
			{
				if (EDLItems[idx].IsStill == true)
				{
					EDLItems[idx].ClipStatus = ClipStatus.Still;

					if (idx < (Len - 1))
					{
						if (EDLItems[idx].ClipDuration == _BoldDuration) 						{
							EDLItems[idx].ClipStatus = ClipStatus.CutBold;
						}
					}
				}
				else
				{
					EDLItems[idx].ClipStatus = ClipStatus.MoveWithBold;
					if (idx > 0)
					{
						if (EDLItems[idx - 1].ClipStatus == ClipStatus.CutBold)
						{
							EDLItems[idx].ClipStatus = ClipStatus.Mov;
						}
					}
				}
				idx++;
			}
		}
		//-------------------------------------
		public void AppendKYP(ClipKYP ck)
		{
			KYPItems.Add(ck);
		}
        //-------------------------------------
        public void PrintListup()
		{
			KYPItems.Clear();
            _RollCount = 0;
            _ClipCount = 0;
            _ClipTime.TotalDuration = 0;
            _BoldTime.TotalDuration = 0;
            _RollTime.TotalDuration = 0;

            double ct = 0; //clipDuration
            double bt = 0; //bold
            double rt = 0; //roll
            int rc = 0; 
            int cc = 0;

			if ( EDLItems.Count <= 0) return;
			
			int idx =0;
			int cnt = EDLItems.Count;
			while (idx < cnt)
			{
				ClipKYP kp;
				switch (EDLItems[idx].ClipStatus)
				{
					case ClipStatus.RollBold:
						kp = new ClipKYP(_FrameRate);
                        kp.BoldDuration = EDLItems[idx].ClipDuration;
                        kp.Duration = 0;
                        kp.ClipName = EDLItems[idx].ClipName;
						KYPItems.Add(kp);
                        rc += 1;
                        rt += kp.TotalDuration;
						idx++;
						break;
					case ClipStatus.CutBold:
						if (idx < (cnt - 1))
						{
							ClipStatus cs = EDLItems[idx+1].ClipStatus;
							if ((cs == ClipStatus.Mov) || (cs == ClipStatus.Still) )
							{
								kp = new ClipKYP(_FrameRate);
                                kp.BoldDuration = EDLItems[idx].ClipDuration;
                                kp.Duration = EDLItems[idx + 1].ClipDuration;
                                kp.ClipName = EDLItems[idx + 1].ClipName;
                                KYPItems.Add(kp);
								idx += 2;

                                cc += 1;
                                ct += kp.Duration;
                                bt += kp.BoldDuration;
							}
							else
							{
								kp = new ClipKYP(_FrameRate, 0,EDLItems[idx].ClipDuration);
                                kp.BoldDuration = 0;
                                kp.Duration = EDLItems[idx].ClipDuration;
                                kp.ClipName = EDLItems[idx].ClipName;
                                KYPItems.Add(kp);
								idx += 1;
                                cc += 1;
                                ct += kp.Duration;
							}

						}
						else
						{
							kp = new ClipKYP(_FrameRate);
                            kp.BoldDuration = 0;
                            kp.Duration = EDLItems[idx].ClipDuration;
                            kp.ClipName = EDLItems[idx].ClipName;
                            KYPItems.Add(kp);
							idx += 1;
                            cc += 1;
                            ct += kp.Duration;
                        }
						break;
					case ClipStatus.Mov:
							kp = new ClipKYP(_FrameRate);
                            kp.BoldDuration = 0;
                            kp.Duration = EDLItems[idx].ClipDuration;
                            kp.ClipName = EDLItems[idx].ClipName;
							KYPItems.Add(kp);
							idx += 1;
                            cc += 1;
                            ct += kp.Duration;
							break;
					case ClipStatus.MoveWithBold:
							kp = new ClipKYP(_FrameRate);
                            kp.BoldDuration = _BoldDuration;
                            kp.Duration = EDLItems[idx].ClipDuration - _BoldDuration;
 	                        kp.ClipName = EDLItems[idx].ClipName;
    						KYPItems.Add(kp);
							idx += 1;
                            cc += 1;
                            ct += kp.Duration;
                            bt += kp.BoldDuration;
							break;

                    case ClipStatus.Still:
                         kp = new ClipKYP(_FrameRate);
                        kp.BoldDuration = 0;
                        kp.Duration = EDLItems[idx].ClipDuration;
                        kp.ClipName = EDLItems[idx].ClipName;
						KYPItems.Add(kp);
						idx += 1;
                        cc += 1;
                        ct += kp.Duration;
						break;
					case ClipStatus.None:
						//なにもしない
							idx++;
						break;
				}
			}//while

			if (KYPItems.Count > 0)
			{
				KYPItems[0].SetInPoint(_StartTime);
				for (int i = 1; i < KYPItems.Count; i++)
				{
					KYPItems[i].inPointDuration = KYPItems[i-1].outPointDuration;
                }

                _ClipCount = cc;
                _RollCount = rc;
                _RollTime.TotalDuration = rt;
                _BoldTime.TotalDuration = bt;
                _ClipTime.TotalDuration = ct;
			}
		}
        //-------------------------------------
        public int ClipCount
        {
            get { return _ClipCount; }
        }
        //-------------------------------------
        public int RollCount
        {
            get { return _RollCount; }
        }
        //-------------------------------------
        public Timecode RollTime
        {
            get { return _RollTime; }
        }
        //-------------------------------------
        public Timecode BoldTime
        {
            get { return _BoldTime; }
        }
        //-------------------------------------
        public Timecode ClipTime
        {
            get { return _ClipTime; }
        }
        //-------------------------------------
        public Timecode KPYlastTime
        {
            get
            {
                if (KYPItems.Count > 0)
                {
                    double ln = KYPItems[KYPItems.Count - 1].outPointDuration - KYPItems[0].inPointDuration;
                    Timecode t = new Timecode(_FrameRate);
                    t.TotalDuration = ln;
                    return t;
                }
                else
                {
                    return new Timecode(_FrameRate);
                }
            }
        }
        //*************************************************************************
        private string ClipNameTrim(string s)
        {
            string ret = s;
            if (_IsPrintCLipExt == false)
            {
                ret = GetNameWithoutExt(ret);
            }
            if (IsClearText == true)
            {
                if (ClearText != string.Empty)
                {
                    ret = ret.Replace(ClearText, "").Trim();
                }
            }
         
            return ret;
        }
        //*************************************************************************
        public string KYPClipName(int idx)
        {
            if ((idx < 0) || (idx >= KYPItems.Count)) return "";
            return ClipNameTrim(KYPItems[idx].ClipName);
        }
        //*************************************************************************
        //-------------------------------------
        private string GetNameWithoutExt(string s)
        {
            int idx = -1;
            if (s == string.Empty) return "";
            for (int i = s.Length - 1; i >= 0; i--)
            {
                if (s[i] == '.')
                {
                    idx = i;
                    break;
                }
            }
            if (idx < 0) return s;
            return s.Substring(0,idx);
        }
        //*************************************************************************
        public string[] KYPInfo(int idx)
        {
            string[] s = new string[6] { "", "", "", "", "", "" };
            if ((idx < 0) || (idx >= KYPItems.Count)) return s;
            s = KYPItems[idx].Info;
            s[0] = ClipNameTrim(s[0]);
            return s;
        }
    }
    //*************************************************************************
}