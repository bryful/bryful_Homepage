﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EDLPrintAsqua
{
	public partial class BoldDurationDlg : Form
	{
		private FrameRates _FrameRate = FrameRates.fr24;
        private const double v1_3 = (double)1 / (double)3;
        private const double v1_2 = (double)1 / (double)2;
        private const double v2_3 = (double)2 / (double)3;
        private const double v1Sec = (double)1;

        RadioButton[] rb = new RadioButton[5];
		//******************************************************************
		public BoldDurationDlg(FrameRates fr)
		{
			InitializeComponent();

            rb_1_3.Tag = 0;
            rb_1_2.Tag = 1;
            rb_2_3.Tag = 2;
            rb1Sec.Tag = 3;
            rbCust.Tag = 4;
            rb[0] = rb_1_3;
            rb[1] = rb_1_2;
            rb[2] = rb_2_3;
            rb[3] = rb1Sec;
            rb[4] = rbCust;

			SetFrameRate(fr);
		}
		
		//******************************************************************
		public double Duration
		{
			get { return GetDuration(); }
			set { SetDuration(value); }
		}
		//******************************************************************
		public FrameRates FrameRate
		{
			get { return _FrameRate; }
			set { SetFrameRate(value); }
		}
		//******************************************************************
		private double GetDuration()
		{
			double ret =0;
			if (rb_1_2.Checked == true)
			{
                ret = v1_2;
			}
            else if (rb_1_3.Checked == true)
			{
                ret = v1_3;
			}
            else if (rb_2_3.Checked == true)
			{
                ret = v2_3;
			}
            else if (rb1Sec.Checked == true)
			{
                ret = v1Sec;
			}
            else if (rbCust.Checked == true)
			{
				ret = (double)tbSec.Value + (double)tbKoma.Value / (double)_FrameRate;  
			}
			return ret;
		}
		//******************************************************************
		public void SetFrameRate(FrameRates fr)
		{
			_FrameRate = fr;
			string s = "";
			if (fr == FrameRates.fr24)
			{
				s = "24p ( 24/23.976 fps )";
			}
			else
			{
				s = "60i ( 30/29.97 fps )";
			}
			tbFrameRate.Text = s;

		}
		//******************************************************************
		private void SetDuration(double d)
		{
			if (d <= v1_3)
			{
                rb_1_3.Checked = true;
				tbSec.Value = 0;
				tbKoma.Value = (int)Math.Round( (double)_FrameRate / 3);
			}
			else if (d == v1_2)
			{
                rb_1_2.Checked = true;
			}
			else if (d == v2_3)
			{
                rb_2_3.Checked = true;
			}
			else if (d == v1Sec)
			{
                rb1Sec.Checked = true;
			}
			else
			{
                rbCust.Checked = true;
			}
			tbSec.Value = (int)Math.Floor(d);
            tbKoma.Value = (int)Math.Round((d -Math.Floor(d)) * (double)_FrameRate);
		}

        //******************************************************************
        private void rbCust_VisibleChanged(object sender, EventArgs e)
        {
            
        }

        private void rb_1_3_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton r = (RadioButton)sender;
            tbSec.Enabled = tbKoma.Enabled = ((int)r.Tag == 4);

        }
		//******************************************************************
	}
}
