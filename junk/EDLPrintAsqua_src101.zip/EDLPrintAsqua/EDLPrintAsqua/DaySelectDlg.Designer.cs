﻿namespace EDLPrintAsqua
{
    partial class DaySelectDlg
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.tbText = new System.Windows.Forms.TextBox();
            this.rbDay = new System.Windows.Forms.RadioButton();
            this.rbDay4 = new System.Windows.Forms.RadioButton();
            this.rbDayYestaday = new System.Windows.Forms.RadioButton();
            this.cbAddWeek = new System.Windows.Forms.CheckBox();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbText
            // 
            this.tbText.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbText.Location = new System.Drawing.Point(27, 22);
            this.tbText.Name = "tbText";
            this.tbText.Size = new System.Drawing.Size(187, 23);
            this.tbText.TabIndex = 0;
            // 
            // rbDay
            // 
            this.rbDay.AutoSize = true;
            this.rbDay.Location = new System.Drawing.Point(27, 63);
            this.rbDay.Name = "rbDay";
            this.rbDay.Size = new System.Drawing.Size(94, 16);
            this.rbDay.TabIndex = 1;
            this.rbDay.Text = "日付（そのまま)";
            this.rbDay.UseVisualStyleBackColor = true;
            this.rbDay.Click += new System.EventHandler(this.rbDay_Click);
            // 
            // rbDay4
            // 
            this.rbDay4.AutoSize = true;
            this.rbDay4.Checked = true;
            this.rbDay4.Location = new System.Drawing.Point(27, 85);
            this.rbDay4.Name = "rbDay4";
            this.rbDay4.Size = new System.Drawing.Size(175, 16);
            this.rbDay4.TabIndex = 2;
            this.rbDay4.Text = "日付（AM07:00までは前日扱い)";
            this.rbDay4.UseVisualStyleBackColor = true;
            this.rbDay4.Click += new System.EventHandler(this.rbDay_Click);
            // 
            // rbDayYestaday
            // 
            this.rbDayYestaday.AutoSize = true;
            this.rbDayYestaday.Location = new System.Drawing.Point(27, 107);
            this.rbDayYestaday.Name = "rbDayYestaday";
            this.rbDayYestaday.Size = new System.Drawing.Size(109, 16);
            this.rbDayYestaday.TabIndex = 3;
            this.rbDayYestaday.Text = "日付（前日にする)";
            this.rbDayYestaday.UseVisualStyleBackColor = true;
            this.rbDayYestaday.Click += new System.EventHandler(this.rbDay_Click);
            // 
            // cbAddWeek
            // 
            this.cbAddWeek.AutoSize = true;
            this.cbAddWeek.Checked = true;
            this.cbAddWeek.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbAddWeek.Location = new System.Drawing.Point(27, 139);
            this.cbAddWeek.Name = "cbAddWeek";
            this.cbAddWeek.Size = new System.Drawing.Size(87, 16);
            this.cbAddWeek.TabIndex = 4;
            this.cbAddWeek.Text = "曜日も加える";
            this.cbAddWeek.UseVisualStyleBackColor = true;
            this.cbAddWeek.Click += new System.EventHandler(this.cbAddWeek_Click);
            // 
            // btnOK
            // 
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Location = new System.Drawing.Point(71, 171);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 5;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(152, 171);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // DaySelectDlg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(248, 208);
            this.ControlBox = false;
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.cbAddWeek);
            this.Controls.Add(this.rbDayYestaday);
            this.Controls.Add(this.rbDay4);
            this.Controls.Add(this.rbDay);
            this.Controls.Add(this.tbText);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DaySelectDlg";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "日付の入力";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbText;
        private System.Windows.Forms.RadioButton rbDay;
        private System.Windows.Forms.RadioButton rbDay4;
        private System.Windows.Forms.RadioButton rbDayYestaday;
        private System.Windows.Forms.CheckBox cbAddWeek;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
    }
}